// ----------------------------------------------------------------------------
// BatchProcessing_byHrast 1.4.2
//
// The row selects the filter. An empty row is skipped.
// Settings are a dialog inside the script, separate for each filter.
// Names are the full process names. ScreenTransferFunction is last.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    BatchProcessing_byHrast : Batch Processing > BatchProcessing_byHrast
#feature-icon  BatchProcessing_byHrast.svg

#feature-info  BatchProcessing_byHrast. One row per filter: SII, Ha, OIII, L, R, G, B and RGB. \
               Settings stay inside the script and apply only to that filter.

#define BP_VERSION "1.4.2"

#define USE_SOLVER_LIBRARY
#define SETTINGS_MODULE "BatchProcessing_byHrast"

#define SETTINGS_PREFIX "BatchProcessing_byHrast/"
#define SETTINGS_PREFIX_LEGACY "Faza1/"

#include "../ImageSolver/ImageSolver.js"
#include "EarlyCalibrationCurves.jsh"
#include "BatchProcessing_PrePost.jsh"

#iflt __PI_BUILD__ 1707
// BlindSolverEngine requires PixInsight 1.9.6 / build 1707+.
#else
#ifdef TITLE
#undef TITLE
#endif
#ifdef VERSION
#undef VERSION
#endif
#define TITLE   "BlindSolver"
#define VERSION "1.0.0"
#include "../BlindSolver/BlindSolverEngine.js"
#endif

#include "../Toolbox/GraXpertLib.jsh"

// ----------------------------------------------------------------------------

var F1_SLOTS = [ "SII", "Ha", "OIII", "SHO", "L", "R", "G", "B", "RGB" ];

var F1_FILTER_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "blurless", title: "BlurlessAI", kind: "blurless" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "graxpert", title: "GraXpert", kind: "graxpert" },
   { id: "blindsolver", title: "BlindSolver", kind: "blindsolver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "blurx2", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

// SHO_Default channel chain. Stretch stays in the list and starts off.
var F1_SHO_CHANNEL_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator, Correct Only", kind: "blurx", mode: "correct" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];
var F1_SHO_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "blurless", title: "BlurlessAI", kind: "blurless" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "graxpert", title: "GraXpert", kind: "graxpert" },
   { id: "blindsolver", title: "BlindSolver", kind: "blindsolver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "spcc", title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { id: "blurx2", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_RGB_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "blurless", title: "BlurlessAI", kind: "blurless" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "graxpert", title: "GraXpert", kind: "graxpert" },
   { id: "blindsolver", title: "BlindSolver", kind: "blindsolver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "spcc", title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { id: "blurx", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_WAVE = { Ha: 656.3, OIII: 500.7, SII: 671.6 };
var F1_BAND = { Ha: 3.0, OIII: 3.0, SII: 3.0 };

// Built-in presets. LRGB_Default keeps the LRGB Post chain.
// SHO_Default is the narrowband chain. The older Trunk SHO Default is gone.
// ClearAll leaves Pre, Post and every filter row empty.
var F1_LRGB_PRESET = "LRGB_Default";
var F1_SHO_PRESET = "SHO_Default";
var F1_CLEAR_PRESET = "ClearAll";
var F1_BUILTIN_PRESET = F1_LRGB_PRESET;
var F1_ADDABLE_STEPS = [
   { title: "SpikeLessAI", kind: "spikeless" },
   { title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { title: "BlurXTerminator, Correct Only", kind: "blurx", mode: "correct" },
   { title: "BlurlessAI", kind: "blurless" },
   { title: "GraXpert", kind: "graxpert" },
   { title: "BlindSolver", kind: "blindsolver" },
   { title: "ImageSolver", kind: "solver" },
   { title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { title: "MultiscaleGradientCorrection", kind: "mgc" },
   { title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { title: "NoiseXTerminator", kind: "noisex" },
   { title: "StarXTerminator", kind: "starx" },
   { title: "HistogramTransformation", kind: "histo" },
   { title: "PixelMath", kind: "pm" },
   { title: "ScreenTransferFunction", kind: "screen" },
   { title: "MultiscaleAdaptiveStretch", kind: "stretch" },
   { title: "AutoLinearFit", kind: "autolinear" },
   { title: "Invert", kind: "invert" },
   { title: "SCNR", kind: "scnr" },
   { title: "LocalHistogramEqualization", kind: "lhe" },
   { title: "CurvesTransformation", kind: "curves" },
   { title: "Rotation", kind: "rotate" },
   { title: "Resample", kind: "resample" },
   { title: "HDRMultiscaleTransform", kind: "hdrmt" },
   { title: "LRGBCombination", kind: "sholrgb" },
   { title: "Star Stretch", kind: "starstretch" },
   { title: "NB to RGB Stars", kind: "nbtorgb" },
   { title: "PixelMath (screen stars)", kind: "putstars" }
];

var f1 = {
   views: { SII: "", Ha: "", OIII: "", SHO: "", L: "", R: "", G: "", B: "", RGB: "" },
   steps: {},
   order: {},
   extra: {},
   adopted: {},
   removed: {},
   pre: { steps: {}, order: [], extra: [], removed: {} },
   post: { steps: {}, order: [], extra: [], removed: {} },
   solverKeep: {},
   processSeed: null,
   activePreset: "LRGB_Default",
   suppressViewSync: false,
   db: { L: [], R: [], G: [], B: [], Q: [] },
   curveByName: {}
};

function f1PreferBlindSolver()
{
   return typeof BlindSolverEngine == "function";
}

function f1GraXpertAvailable()
{
   if ( typeof GraXpertLib != "function" )
      return false;
   try
   {
      let gxp = new GraXpertLib;
      return gxp.hasGraXpertPath() ? true : false;
   }
   catch ( e )
   {
      return false;
   }
}

function f1FactoryStepOn( step )
{
   // Correct Only BlurX off; BlindSolver preferred over ImageSolver.
   if ( step.kind == "blurx" && step.mode == "correct" )
      return false;
   if ( step.kind == "solver" )
      return !f1PreferBlindSolver();
   if ( step.kind == "blindsolver" )
      return f1PreferBlindSolver();
   if ( step.kind == "graxpert" )
      return f1GraXpertAvailable();
   return true;
}

function f1SeparatesNarrowband( )
{
   return f1.activePreset == F1_SHO_PRESET;
}

function f1QuietSlot( slot )
{
   if ( f1SeparatesNarrowband() )
      return slot == "R" || slot == "G" || slot == "B" || slot == "RGB" || slot == "SHO";
   if ( f1.activePreset == F1_LRGB_PRESET )
      return slot == "SII" || slot == "Ha" || slot == "OIII" || slot == "SHO";
   return false;
}

function f1DefaultStepOn( slot, step )
{
   if ( f1QuietSlot( slot ) )
      return false;
   if ( f1.activePreset == F1_SHO_PRESET && ( slot == "SII" || slot == "Ha" || slot == "OIII" ) )
   {
      if ( step.kind == "stretch" )
         return false;
      return true;
   }
   return f1FactoryStepOn( step );
}

function f1CopyTargetsFor( slot )
{
   let out = [];
   for ( let i = 0; i < F1_SLOTS.length; ++i )
      if ( F1_SLOTS[i] != slot )
         out.push( F1_SLOTS[i] );
   return out;
}

function f1ApplyBuiltinSlotPolicy()
{
   // Saved checkboxes stay until the user clicks Load. That is what restores a preset recipe.
}

function f1IsBuiltinPreset( name )
{
   name = f1NormalizePresetName( name );
   return name == F1_LRGB_PRESET || name == F1_SHO_PRESET || name == F1_CLEAR_PRESET;
}

function f1UserAbort()
{
   try
   {
      return console.abortRequested ? true : false;
   }
   catch ( e )
   {
      return false;
   }
}

function f1Confirm( text )
{
   let ask = new MessageBox( text, "BatchProcessing_byHrast",
                             StdIcon.Question, StdButton.Yes, StdButton.No );
   return ask.execute() == StdButton.Yes;
}

function f1ErrorText( e )
{
   return e && e.message ? e.message : ( e ? e.toString() : "Unknown error" );
}

function f1Format( value, digits )
{
   if ( value == null || !isFinite( value ) )
      return "";
   return format( "%." + digits + "f", value );
}

function f1Parse( text )
{
   let trimmed = String( text == null ? "" : text ).trim().replace( ",", "." );
   if ( trimmed.length == 0 )
      return null;
   let value = Number( trimmed );
   return isFinite( value ) ? value : null;
}

function f1ReadBool( key, fallback )
{
   // 0/1 survives a reload. A stored Boolean false can come back as "missing", and the fallback is checked.
   let number = Settings.read( SETTINGS_PREFIX + key, DataType.Int32 );
   if ( Settings.lastReadOK && typeof number == "number" )
      return number != 0;
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.Boolean );
   if ( Settings.lastReadOK )
      return value ? true : false;
   value = Settings.read( SETTINGS_PREFIX_LEGACY + key, DataType.Boolean );
   if ( Settings.lastReadOK )
      return value ? true : false;
   return fallback;
}

function f1ReadString( key, fallback )
{
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.String );
   if ( Settings.lastReadOK && typeof value == "string" )
      return value;
   value = Settings.read( SETTINGS_PREFIX_LEGACY + key, DataType.String );
   if ( Settings.lastReadOK && typeof value == "string" )
      return value;
   return fallback;
}

function f1DetectMarsFiles()
{
   let found = [];
   let appData = System.getEnvironmentVariable( "APPDATA" );
   if ( !appData )
      return found;
   let files = [];
   try
   {
      files = File.searchDirectory( appData.replace( /\\/g, "/" ) + "/Pleiades/*.settings", false );
   }
   catch ( e )
   {
      return found;
   }
   let re = /k="MARSDatabaseFilePath\d+" t="s">([^<]+)</g;
   for ( let i = 0; i < files.length; ++i )
   {
      let text = "";
      try
      {
         text = File.readTextFile( files[i] );
      }
      catch ( e )
      {
         continue;
      }
      for ( let match = re.exec( text ); match; match = re.exec( text ) )
         if ( found.indexOf( match[1] ) < 0 && File.exists( match[1] ) )
            found.push( match[1] );
   }
   return found;
}

function f1MarsFiles()
{
   let raw = f1ReadString( "marsFiles", "" );
   if ( raw )
   {
      try
      {
         let list = JSON.parse( raw );
         if ( Array.isArray( list ) )
            return list;
      }
      catch ( e )
      {
      }
   }
   return f1DetectMarsFiles();
}

function f1WriteMarsFiles( list )
{
   Settings.write( SETTINGS_PREFIX + "marsFiles", DataType.String, JSON.stringify( list ) );
}

function f1ColorSlot( slot )
{
   return slot == "RGB";
}

function f1ExportsStars( slot )
{
   return slot == "RGB" || slot == "SHO" || slot == "SII" || slot == "Ha" || slot == "OIII";
}

function f1StepsFor( slot )
{
   if ( f1.activePreset == F1_CLEAR_PRESET )
      return [];
   if ( slot == "RGB" )
      return F1_RGB_STEPS;
   if ( slot == "SHO" )
   {
      // SHO presets do not process a combined row. SII, Ha and OIII run, then Post builds SHO.
      if ( f1SeparatesNarrowband() )
         return [];
      return F1_SHO_STEPS;
   }
   if ( f1.activePreset == F1_SHO_PRESET && ( slot == "SII" || slot == "Ha" || slot == "OIII" ) )
      return F1_SHO_CHANNEL_STEPS;
   return F1_FILTER_STEPS;
}

function f1FindBuiltinStep( id )
{
   let lists = [ F1_FILTER_STEPS, F1_SHO_CHANNEL_STEPS, F1_SHO_STEPS, F1_RGB_STEPS ];
   for ( let n = 0; n < lists.length; ++n )
      for ( let i = 0; i < lists[n].length; ++i )
         if ( lists[n][i].id == id )
            return lists[n][i];
   return null;
}

function f1CopyStepDef( step )
{
   let copy = {
      id: step.id,
      title: step.title,
      kind: step.kind
   };
   if ( step.mode )
      copy.mode = step.mode;
   if ( step.processId )
      copy.processId = step.processId;
   if ( step.iconName )
      copy.iconName = step.iconName;
   return copy;
}

function f1AllSteps( slot )
{
   let list = [];
   let seen = {};
   let removed = f1.removed[slot] || {};
   let builtins = f1StepsFor( slot );
   for ( let i = 0; i < builtins.length; ++i )
   {
      let step = builtins[i];
      if ( removed[step.id] || seen[step.id] )
         continue;
      list.push( step );
      seen[step.id] = true;
   }
   let adopted = f1.adopted[slot] || [];
   for ( let i = 0; i < adopted.length; ++i )
   {
      let step = adopted[i];
      if ( !step || removed[step.id] || seen[step.id] )
         continue;
      list.push( step );
      seen[step.id] = true;
   }
   let extra = f1.extra[slot] || [];
   for ( let i = 0; i < extra.length; ++i )
   {
      let step = extra[i];
      if ( !step || seen[step.id] )
         continue;
      list.push( step );
      seen[step.id] = true;
   }
   return list;
}

function f1RemovedList( slot )
{
   let removed = f1.removed[slot] || {};
   let list = [];
   for ( let id in removed )
      if ( removed[id] )
         list.push( id );
   list.sort();
   return list;
}

function f1ApplyRemovedList( slot, ids )
{
   f1.removed[slot] = {};
   if ( !ids || !Array.isArray( ids ) )
      return;
   for ( let i = 0; i < ids.length; ++i )
      if ( ids[i] )
         f1.removed[slot][ids[i]] = true;
}

function f1LoadRemoved( slot )
{
   let raw = f1ReadString( "removed_" + slot, "" );
   if ( !raw )
   {
      f1.removed[slot] = {};
      return;
   }
   try
   {
      let ids = JSON.parse( raw );
      f1ApplyRemovedList( slot, ids );
   }
   catch ( e )
   {
      f1.removed[slot] = {};
   }
}

function f1AuthorCredit( kind )
{
   if ( kind == "starstretch" || kind == "nbtorgb" )
      return "Franklin Marek, SetiAstro";
   if ( kind == "blurx" || kind == "noisex" || kind == "starx" || kind == "starxmono" )
      return "Russell Croman, RC Astro";
   if ( kind == "spikeless" || kind == "blurless" )
      return "Neven Krčmarek";
   if ( kind == "graxpert" )
      return "Jürgen Terpe, The GraXpert Team";
   return "";
}

function f1OriginalName( step )
{
   if ( !step )
      return "";
   if ( step.kind == "blurx" && step.mode == "correct" )
      return "BlurXTerminator, Correct Only";
   if ( step.kind == "nbtorgb" )
      return "NB to RGB Star Combination";
   return step.title || "";
}

function f1StepLabel( step )
{
   let title = f1OriginalName( step );
   let credit = f1AuthorCredit( step.kind );
   if ( credit && title.indexOf( credit ) < 0 )
      title += " — " + credit;
   return title;
}

function f1StepTargetLabel( step, par )
{
   function clean( value )
   {
      return value == null ? "" : String( value ).replace( /^\s+|\s+$/g, "" );
   }
   function join( values )
   {
      let out = [];
      for ( let i = 0; i < values.length; ++i )
      {
         let text = clean( values[i] );
         if ( text )
            out.push( text );
      }
      return out.join( ", " );
   }
   if ( !step )
      return "";
   if ( step.kind == "composergb" )
      return "R, G, B";
   if ( step.kind == "composesho" || step.kind == "starxmono" )
      return "SII, Ha, OIII";
   if ( !par )
      return "";
   if ( f1ShowsOneTarget( step.kind ) )
      return clean( par.channel ) || clean( par.input );
   let rgb = join( [ par.inputR, par.inputG, par.inputB ] );
   if ( rgb )
      return rgb;
   let stars = join( [ par.sii, par.ha, par.oiii ] );
   if ( stars )
      return stars;
   let screen = join( [ par.inputStars, par.inputTarget ] );
   if ( screen )
      return screen;
   return join( [ par.inputL, par.inputRGB ] );
}

function f1StepTitle( step, par )
{
   let title = f1StepLabel( step );
   let channel = f1StepTargetLabel( step, par );
   if ( !channel )
      return title;
   if ( title.indexOf( "(" + channel + ")" ) >= 0 )
      return title;
   return title + " (" + channel + ")";
}

function f1RecipeStep( slot, step )
{
   let builtins = f1StepsFor( slot );
   for ( let i = 0; i < builtins.length; ++i )
      if ( builtins[i].id == step.id )
         return true;
   return false;
}

function f1DefaultOrder( slot )
{
   let steps = f1StepsFor( slot );
   let ids = [];
   for ( let i = 0; i < steps.length; ++i )
      ids.push( steps[i].id );
   return ids;
}

function f1NormalizeOrder( slot, ids )
{
   let steps = f1AllSteps( slot );
   let known = {};
   for ( let i = 0; i < steps.length; ++i )
      known[steps[i].id] = steps[i];
   let order = [];
   let seen = {};
   if ( ids && ids.length )
   {
      for ( let i = 0; i < ids.length; ++i )
      {
         let id = ids[i];
         if ( known[id] && !seen[id] )
         {
            order.push( id );
            seen[id] = true;
         }
      }
   }
   for ( let i = 0; i < steps.length; ++i )
   {
      let id = steps[i].id;
      if ( seen[id] )
         continue;
      let insertAt = order.length;
      for ( let p = i - 1; p >= 0; --p )
      {
         let at = order.indexOf( steps[p].id );
         if ( at >= 0 )
         {
            insertAt = at + 1;
            break;
         }
      }
      if ( insertAt == order.length )
      {
         for ( let n = i + 1; n < steps.length; ++n )
         {
            let at = order.indexOf( steps[n].id );
            if ( at >= 0 )
            {
               insertAt = at;
               break;
            }
         }
      }
      order.splice( insertAt, 0, id );
      seen[id] = true;
   }
   // An older saved SHO list has no SPCC, so a previous load appended it at the end.
   // Pull it back to sit directly after MultiscaleGradientCorrection.
   let spccAt = order.indexOf( "spcc" );
   let mgcAt = order.indexOf( "mgc" );
   if ( spccAt > mgcAt && mgcAt >= 0 )
   {
      let afterTail = true;
      for ( let n = 0; n < steps.length; ++n )
      {
         if ( steps[n].id == "spcc" )
         {
            for ( let k = n + 1; k < steps.length; ++k )
            {
               let at = order.indexOf( steps[k].id );
               if ( at >= 0 && at > spccAt )
                  afterTail = false;
            }
            break;
         }
      }
      if ( afterTail && spccAt != mgcAt + 1 )
      {
         order.splice( spccAt, 1 );
         order.splice( mgcAt + 1, 0, "spcc" );
      }
   }
   return order;
}

function f1OrderedSteps( slot )
{
   let steps = f1AllSteps( slot );
   let byId = {};
   for ( let i = 0; i < steps.length; ++i )
      byId[steps[i].id] = steps[i];
   let order = f1NormalizeOrder( slot, f1.order[slot] );
   f1.order[slot] = order;
   let list = [];
   for ( let i = 0; i < order.length; ++i )
      if ( byId[order[i]] )
         list.push( byId[order[i]] );
   return list;
}

function f1ReadOrder( slot )
{
   let raw = f1ReadString( "order_" + slot, "" );
   if ( !raw )
      return f1DefaultOrder( slot );
   try
   {
      let ids = JSON.parse( raw );
      if ( Array.isArray( ids ) )
         return f1NormalizeOrder( slot, ids );
   }
   catch ( e )
   {
   }
   return f1DefaultOrder( slot );
}

function f1GlobalIsFunction( name )
{
   if ( !name || !/^[A-Za-z_][A-Za-z0-9_]*$/.test( name ) )
      return false;
   try
   {
      return ( new Function( "return typeof " + name + " === 'function';" ) )();
   }
   catch ( e )
   {
      return false;
   }
}

function f1StepInstalled( step )
{
   switch ( step.kind )
   {
   case "spikeless": return typeof SpikeLessAI == "function";
   case "blurx":     return typeof BlurXTerminator == "function";
   case "blurless":  return typeof BlurlessAI == "function";
   case "solver":      return typeof ImageSolver == "function";
   case "graxpert":    return f1GraXpertAvailable();
   case "blindsolver": return typeof BlindSolverEngine == "function";
   case "spfc":      return typeof SpectrophotometricFluxCalibration == "function";
   case "mgc":       return typeof MultiscaleGradientCorrection == "function";
   case "spcc":      return typeof SpectrophotometricColorCalibration == "function";
   case "noisex":    return typeof NoiseXTerminator == "function";
   case "starx":     return typeof StarXTerminator == "function";
   case "screen":    return typeof ScreenTransferFunction == "function";
   case "stretch":   return typeof MultiscaleAdaptiveStretch == "function";
   case "histo":     return typeof HistogramTransformation == "function";
   case "pm":        return typeof PixelMath == "function";
   case "icon":      return f1GlobalIsFunction( step.processId );
   }
   return true;
}

function f1NewIconStepId()
{
   return "icon_" + Date.now().toString( 36 ) + "_" + Math.floor( Math.random() * 1000 );
}

function f1IconNameFromTitle( title )
{
   let text = String( title == null ? "" : title );
   let open = text.lastIndexOf( " (" );
   if ( open < 0 || text.charAt( text.length - 1 ) != ")" )
      return "";
   return text.substring( open + 2, text.length - 1 );
}

function f1EnsureIconSource( step, par )
{
   if ( par && par.source )
      return par.source;
   let iconName = "";
   if ( par && par.iconName )
      iconName = par.iconName;
   else if ( step && step.iconName )
      iconName = step.iconName;
   else
      iconName = f1IconNameFromTitle( step ? step.title : "" );
   if ( !iconName )
      throw new Error( ( step && step.title ? step.title : "Process icon" ) + " has no saved parameters." );
   let snap = f1SnapshotFromIcon( iconName );
   if ( par )
   {
      par.processId = snap.processId;
      par.iconName = snap.iconName;
      par.source = snap.source;
      par.title = snap.title;
   }
   if ( step )
   {
      step.processId = snap.processId;
      step.iconName = snap.iconName;
      step.title = snap.title;
   }
   return snap.source;
}

function f1SnapshotFromIcon( iconName )
{
   let instance = ProcessInstance.fromIcon( iconName );
   if ( !instance )
      throw new Error( "Process icon was not found: " + iconName );
   let processId = instance.processId();
   let flags = 0;
   try
   {
      flags = SourceCodeFlag.Minimal;
   }
   catch ( e )
   {
      flags = 15;
   }
   let source = instance.toSource( "JavaScript", "P", 0, flags );
   if ( !source || String( source ).trim().length == 0 )
      throw new Error( "Could not read parameters from process icon: " + iconName );
   return {
      processId: processId,
      iconName: iconName,
      source: String( source ).trim(),
      title: processId + " (" + iconName + ")"
   };
}

function f1BuildFromIconSource( source )
{
   // PixInsight icon source usually starts with "let P = new ...".
   // Evaluating that in a scope that already has P throws:
   // Identifier 'P' has already been declared.
   let code = String( source == null ? "" : source ).trim();
   if ( !code.length )
      throw new Error( "Could not recreate the process from the saved snapshot." );
   code = code.replace( /^\s*(?:var|let|const)\s+P\s*=/, "P =" );
   let process = null;
   try
   {
      process = ( new Function( "var P = null;\n" + code + ";\nreturn P;" ) )();
   }
   catch ( e )
   {
      throw new Error( e.message ? e.message : e.toString() );
   }
   if ( !process )
      throw new Error( "Could not recreate the process from the saved snapshot." );
   return process;
}

function f1Narrow( slot )
{
   return slot == "Ha" || slot == "OIII" || slot == "SII";
}

function f1DefaultParams( slot, step )
{
   if ( step.kind == "spikeless" )
   {
      let sho = f1.activePreset == F1_SHO_PRESET
                && ( slot == "SII" || slot == "Ha" || slot == "OIII" );
      return {
         model: sho ? "SpikeLessAI v1" : "SpikeLessAI v2",
         mode: sho ? "Stretched" : "Linear",
         strength: 1.00,
         stride: 128,
         starLayer: "None",
         generateSpikeImage: false,
         cleanLongTails: false
      };
   }
   if ( step.kind == "blurx" )
   {
      let sharpen = step.mode == "sharpen";
      return {
         correctOnly: !sharpen,
         sharpenStars: sharpen ? 0.10 : 0,
         starHalos: sharpen ? 0.05 : 0,
         sharpenNonstellar: sharpen ? 0.70 : 0,
         overlap: 0.20
      };
   }
   if ( step.kind == "blurless" )
      return {
         amount: 1.00,
         coresAbove: "Clip",
         colourMode: "Channels",
         alignChannels: true,
         crisperSpikes: false
      };
   if ( step.kind == "spfc" )
   {
      let narrow = f1Narrow( slot );
      let gray = f1GrayName( slot );
      return {
         narrowband: narrow,
         wavelength: narrow ? F1_WAVE[slot] : 656.3,
         bandwidth: narrow ? F1_BAND[slot] : 3.0,
         grayName: gray,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   }
   if ( step.kind == "mgc" )
      return {
         scale: 1024,
         separation: 3,
         smoothness: 1.0,
         grayFilter: ( f1ColorSlot( slot ) || slot == "SHO" ) ? "L" : slot,
         showModel: true
      };
   if ( step.kind == "spcc" )
   {
      // SHO starts in narrowband mode with the Ha / OIII / OIII values from the process window.
      // RGB stays broadband and keeps the measured filter curves.
      let sho = slot == "SHO";
      return {
         narrowband: sho,
         optimizeStars: false,
         redWavelength: 656.3,
         redBandwidth: 6.0,
         greenWavelength: 500.7,
         greenBandwidth: 6.0,
         blueWavelength: 500.7,
         blueBandwidth: 6.0,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName,
         whiteReference: "Average Spiral Galaxy",
         applyCalibration: true,
         neutralizeBackground: sho,
         backgroundLow: -2.8,
         backgroundHigh: 2.0
      };
   }
   if ( step.kind == "noisex" )
   {
      return { denoise: 0.70, detail: 0.15 };
   }
   if ( step.kind == "starx" )
      return {
         outputStars: slot == "SII" || slot == "Ha" || slot == "OIII" || slot == "SHO",
         unscreen: false,
         overlap: 0.20
      };
   if ( step.kind == "histo" )
   {
      if ( step.id == "histo2" )
         return { H: f1HistoCurve( 0.06075949, 0.59299192, 1.0 ) };
      return { H: f1HistoCurve( 0.00230000, 0.03037975, 0.38481013 ) };
   }
   if ( step.kind == "pm" )
      return { expression: "$T*2" };
   if ( step.kind == "screen" )
      return { linked: true, shadows: -2.8, target: 0.25 };
   if ( step.kind == "stretch" )
   {
      let sho = f1.activePreset == F1_SHO_PRESET
                && ( slot == "SII" || slot == "Ha" || slot == "OIII" );
      if ( sho )
         return {
            targetBackground: 0.05,
            aggressiveness: 0.20,
            dynamicRange: 0.60,
            contrastRecovery: true,
            scaleSeparation: 1024,
            intensity: 1.00,
            saturation: true,
            saturationAmount: 0.75,
            saturationBoost: 0.50
         };
      return {
         targetBackground: 0.15,
         aggressiveness: 0.70,
         dynamicRange: 0.40,
         contrastRecovery: true,
         scaleSeparation: 1024,
         intensity: 1.00,
         saturation: false,
         saturationAmount: 0.75,
         saturationBoost: 0.50
      };
   }
   if ( step.kind == "blindsolver" )
      return { timeLimit: 120 };
   if ( step.kind == "graxpert" )
      return {
         correction: 0,
         smoothing: 0.0
      };
   return {};
}

function f1ClonePar( par )
{
   try
   {
      return JSON.parse( JSON.stringify( par == null ? {} : par ) );
   }
   catch ( e )
   {
      return {};
   }
}

function f1IsFilterToken( text )
{
   return text == "SII" || text == "Ha" || text == "OIII" || text == "SHO"
       || text == "RGB" || text == "L" || text == "R" || text == "G" || text == "B";
}

function f1BroadbandCurveChannel( name )
{
   if ( !name || !f1.db )
      return "";
   let channels = [ "L", "R", "G", "B" ];
   for ( let c = 0; c < channels.length; ++c )
   {
      let list = f1.db[channels[c]] || [];
      for ( let i = 0; i < list.length; ++i )
         if ( list[i] == name )
            return channels[c];
   }
   return "";
}

// A value that is only a channel id, or only a broadband filter curve, follows the target filter.
function f1RetargetFilterString( toSlot, text )
{
   if ( f1IsFilterToken( text ) )
      return toSlot;
   if ( f1BroadbandCurveChannel( text ) && !f1Narrow( toSlot ) )
      return f1GrayName( toSlot );
   return text;
}

function f1RetargetFilterScalar( toSlot, key, value )
{
   let name = String( key || "" ).toLowerCase();
   if ( typeof value == "boolean" && name.indexOf( "narrowband" ) >= 0 )
      return f1Narrow( toSlot ) ? true : false;
   if ( typeof value == "number" && f1Narrow( toSlot ) )
   {
      if ( name.indexOf( "wavelength" ) >= 0 && F1_WAVE[toSlot] )
         return F1_WAVE[toSlot];
      if ( name.indexOf( "bandwidth" ) >= 0 && F1_BAND[toSlot] )
         return F1_BAND[toSlot];
   }
   return value;
}

function f1RetargetFilterMentions( toSlot, text )
{
   let out = String( text == null ? "" : text );
   let tokens = [ "OIII", "SII", "SHO", "RGB", "Ha", "L", "R", "G", "B" ];
   for ( let i = 0; i < tokens.length; ++i )
   {
      if ( tokens[i] == toSlot )
         continue;
      let re = new RegExp( "([\"'])" + tokens[i] + "\\1", "g" );
      out = out.replace( re, function( match, quote )
      {
         return quote + toSlot + quote;
      } );
   }
   if ( f1Narrow( toSlot ) )
      return out;
   let targetCurve = f1GrayName( toSlot );
   let channels = [ "L", "R", "G", "B" ];
   for ( let c = 0; c < channels.length; ++c )
   {
      let list = ( f1.db && f1.db[channels[c]] ) ? f1.db[channels[c]] : [];
      for ( let i = 0; i < list.length; ++i )
      {
         let curve = list[i];
         if ( curve && curve != targetCurve && out.indexOf( curve ) >= 0 )
            out = out.split( curve ).join( targetCurve );
      }
   }
   return out;
}

function f1RetargetIconSource( toSlot, source )
{
   let text = f1RetargetFilterMentions( toSlot, source );
   let narrow = f1Narrow( toSlot ) ? "true" : "false";
   text = text.replace( /narrowbandMode\s*=\s*(?:true|false)/g, "narrowbandMode = " + narrow );
   if ( !f1Narrow( toSlot ) || !F1_WAVE[toSlot] )
      return text;
   text = text.replace( /\b((?:red|green|blue|gray)FilterWavelength)\s*=\s*[-+0-9.eE]+/g,
                         function( match, name )
                         {
                            return name + " = " + F1_WAVE[toSlot];
                         } );
   text = text.replace( /\b((?:red|green|blue|gray)FilterBandwidth)\s*=\s*[-+0-9.eE]+/g,
                         function( match, name )
                         {
                            return name + " = " + F1_BAND[toSlot];
                         } );
   return text;
}

function f1RetargetParInPlace( toSlot, value, key )
{
   if ( !value || typeof value != "object" )
      return;
   if ( Array.isArray( value ) )
   {
      for ( let i = 0; i < value.length; ++i )
      {
         if ( value[i] && typeof value[i] == "object" )
            f1RetargetParInPlace( toSlot, value[i], key );
         else if ( typeof value[i] == "string" )
            value[i] = f1RetargetFilterString( toSlot, value[i] );
         else
            value[i] = f1RetargetFilterScalar( toSlot, key, value[i] );
      }
      return;
   }
   for ( let name in value )
   {
      if ( name == "source" || name == "title" || name == "processId" || name == "iconName" || name == "expression" )
         continue;
      let item = value[name];
      if ( item && typeof item == "object" )
         f1RetargetParInPlace( toSlot, item, name );
      else if ( typeof item == "string" )
         value[name] = f1RetargetFilterString( toSlot, item );
      else
         value[name] = f1RetargetFilterScalar( toSlot, name, item );
   }
}

function f1AdaptParForSlot( toSlot, step, par )
{
   let out = f1ClonePar( par );
   f1RetargetParInPlace( toSlot, out, "" );
   if ( typeof out.source == "string" && out.source.length )
      out.source = f1RetargetIconSource( toSlot, out.source );
   if ( typeof out.expression == "string" && out.expression.length )
      out.expression = f1RetargetFilterMentions( toSlot, out.expression );
   return out;
}

function f1CopySlotSetup( fromSlot, toSlot )
{
   if ( !fromSlot || !toSlot || fromSlot == toSlot )
      throw new Error( "Choose a different filter to copy to." );
   if ( !f1.steps[fromSlot] || !f1.steps[toSlot] )
      throw new Error( "Filter setup is not ready." );

   // The target shows this exact sequence. Its own default chain is not mixed in.
   let source = f1OrderedSteps( fromSlot );
   let wanted = {};
   for ( let i = 0; i < source.length; ++i )
      wanted[source[i].id] = true;

   f1.removed[toSlot] = {};
   let builtinIds = {};
   let builtins = f1StepsFor( toSlot );
   for ( let i = 0; i < builtins.length; ++i )
   {
      builtinIds[builtins[i].id] = true;
      if ( !wanted[builtins[i].id] )
         f1.removed[toSlot][builtins[i].id] = true;
   }

   f1.extra[toSlot] = [];
   f1.adopted[toSlot] = [];
   let order = [];
   for ( let i = 0; i < source.length; ++i )
   {
      let step = source[i];
      order.push( step.id );
      let dest = step;
      if ( step.kind == "icon" )
      {
         dest = f1CopyStepDef( step );
         f1.extra[toSlot].push( dest );
      }
      else if ( !builtinIds[step.id] )
      {
         dest = f1CopyStepDef( f1FindBuiltinStep( step.id ) || step );
         f1.adopted[toSlot].push( dest );
      }
      let srcState = f1.steps[fromSlot][step.id];
      f1.steps[toSlot][step.id] = {
         on: srcState && srcState.on ? true : false,
         par: f1AdaptParForSlot( toSlot, dest, srcState ? srcState.par : {} )
      };
      if ( dest.kind == "icon" )
      {
         dest.processId = f1.steps[toSlot][step.id].par.processId || dest.processId;
         dest.title = f1.steps[toSlot][step.id].par.title || dest.title;
         dest.iconName = f1.steps[toSlot][step.id].par.iconName || dest.iconName;
      }
   }
   f1.order[toSlot] = order;
}

function f1ApplySavedParams( slot, step, state )
{
   let raw = f1ReadString( "par_" + slot + "_" + step.id, "" );
   if ( !raw )
      return;
   try
   {
      let saved = JSON.parse( raw );
      if ( !saved || typeof saved != "object" )
         return;
      for ( let key in saved )
         if ( saved[key] != null )
            state.par[key] = saved[key];
   }
   catch ( e )
   {
   }
}

function f1GrayName( slot )
{
   if ( slot == "R" )
      return EC_redFilterName;
   if ( slot == "G" )
      return EC_greenFilterName;
   if ( slot == "B" )
      return EC_blueFilterName;
   return EC_grayFilterName;
}

function f1GrayChannel( slot )
{
   if ( slot == "R" || slot == "G" || slot == "B" )
      return slot;
   return "L";
}

function f1AddCurve( channel, name, data )
{
   if ( !f1.db[channel] || !name || !data || f1.curveByName[name] )
      return;
   f1.db[channel].push( name );
   f1.curveByName[name] = data;
}

function f1LoadDatabase()
{
   f1.db = { L: [], R: [], G: [], B: [], Q: [] };
   f1.curveByName = {};
   let path = "";
   let dirs = [ "PXI_DOCDIR", "PXI_BINDIR", "PXI_SRCDIR" ];
   for ( let i = 0; i < dirs.length && !path; ++i )
   {
      let dir = System.getEnvironmentVariable( dirs[i] );
      if ( dir )
      {
         let candidate = File.extractDrive( dir ) + File.extractDirectory( dir.replace( /[\/\\]+$/, "" ) ) + "/library/filters.xspd";
         if ( File.exists( candidate ) )
            path = candidate;
      }
   }
   if ( !path && File.exists( "C:/Program Files/PixInsight/library/filters.xspd" ) )
      path = "C:/Program Files/PixInsight/library/filters.xspd";
   if ( path )
   {
      let text = File.readTextFile( path );
      let re = /<Filter name="([^"]+)" channel="([^"]+)"[^>]*?\sdata="([^"]*)"/g;
      for ( let match = re.exec( text ); match; match = re.exec( text ) )
         f1AddCurve( match[2], match[1], match[3] );
   }
   f1AddCurve( "L", EC_grayFilterName, EC_grayFilterTrCurve );
   f1AddCurve( "R", EC_redFilterName, EC_redFilterTrCurve );
   f1AddCurve( "G", EC_greenFilterName, EC_greenFilterTrCurve );
   f1AddCurve( "B", EC_blueFilterName, EC_blueFilterTrCurve );
   f1AddCurve( "Q", EC_deviceQECurveName, EC_deviceQECurve );
   let channels = [ "L", "R", "G", "B", "Q" ];
   for ( let i = 0; i < channels.length; ++i )
      f1.db[channels[i]].sort();
}

function f1Curve( name, fallback )
{
   if ( name && f1.curveByName[name] )
      return f1.curveByName[name];
   return fallback;
}

function f1InitSteps( preset )
{
   if ( preset )
      f1.activePreset = f1NormalizePresetName( preset );
   if ( !f1.activePreset )
      f1.activePreset = F1_LRGB_PRESET;
   f1.steps = {};
   f1.order = {};
   f1.extra = {};
   f1.adopted = {};
   f1.removed = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.steps[slot] = {};
      f1.extra[slot] = [];
      f1.adopted[slot] = [];
      f1.removed[slot] = {};
      f1.order[slot] = f1DefaultOrder( slot );
      let steps = f1StepsFor( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let par = f1DefaultParams( slot, step );
         if ( f1ShowsOneTarget( step.kind ) )
            par.channel = slot;
         f1.steps[slot][step.id] = { on: f1DefaultStepOn( slot, step ), par: par };
      }
   }
   f1InitPrePost();
}

function f1LoadExtra( slot )
{
   let raw = f1ReadString( "extra_" + slot, "" );
   if ( !raw )
   {
      f1.extra[slot] = [];
      return;
   }
   try
   {
      let list = JSON.parse( raw );
      f1ApplyExtraList( slot, list );
   }
   catch ( e )
   {
      f1.extra[slot] = [];
   }
}

function f1ApplyAdoptedList( slot, list )
{
   f1.adopted[slot] = [];
   if ( !list || !Array.isArray( list ) )
      return;
   for ( let i = 0; i < list.length; ++i )
   {
      let item = list[i];
      if ( !item || !item.id || !item.kind || item.kind == "icon" )
         continue;
      let known = f1FindBuiltinStep( item.id );
      let step = f1CopyStepDef( known || item );
      f1.adopted[slot].push( step );
      if ( !f1.steps[slot][step.id] )
         f1.steps[slot][step.id] = { on: f1DefaultStepOn( slot, step ), par: f1DefaultParams( slot, step ) };
   }
}

function f1LoadAdopted( slot )
{
   let raw = f1ReadString( "adopted_" + slot, "" );
   if ( !raw )
   {
      f1.adopted[slot] = [];
      return;
   }
   try
   {
      f1ApplyAdoptedList( slot, JSON.parse( raw ) );
   }
   catch ( e )
   {
      f1.adopted[slot] = [];
   }
}

function f1AdoptedForWrite( slot )
{
   let out = [];
   let list = f1.adopted[slot] || [];
   for ( let i = 0; i < list.length; ++i )
   {
      let step = list[i];
      if ( !step || !step.id || step.kind == "icon" )
         continue;
      let item = { id: step.id, title: step.title, kind: step.kind };
      if ( step.mode )
         item.mode = step.mode;
      out.push( item );
   }
   return out;
}

function f1OrderText( order )
{
   if ( !order )
      return "";
   if ( typeof order == "string" )
      return order;
   if ( order.join )
      return order.join( "," );
   return "";
}

function f1InferBasePreset( profile )
{
   let text = "";
   if ( profile && profile.post )
      text = f1OrderText( profile.post.order );
   if ( !text )
      text = f1ReadString( "post_order", "" );
   if ( text.indexOf( "sho2blind" ) >= 0 || text.indexOf( "sho2starxsii" ) >= 0 || text.indexOf( "sho2alf" ) >= 0 )
      return F1_SHO_PRESET;
   if ( text.indexOf( "shorot" ) >= 0 || text.indexOf( "shocurves2" ) >= 0 )
      return F1_SHO_PRESET;
   return F1_LRGB_PRESET;
}

function f1BasePresetForStartup( last )
{
   if ( f1IsBuiltinPreset( last ) )
      return last;
   let saved = f1NormalizePresetName( f1ReadString( "basePreset", "" ) );
   if ( f1IsBuiltinPreset( saved ) )
      return saved;
   return f1InferBasePreset( null );
}

function f1LoadSettings()
{
   let last = f1NormalizePresetName( f1ReadString( "lastPreset", F1_LRGB_PRESET ) );
   f1.activePreset = f1BasePresetForStartup( last );
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.views[slot] = f1ReadString( "view" + slot, "" );
      f1LoadExtra( slot );
      f1LoadRemoved( slot );
      f1LoadAdopted( slot );
      f1.order[slot] = f1ReadOrder( slot );
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         state.on = f1ReadBool( "on_" + slot + "_" + step.id, f1DefaultStepOn( slot, step ) );
         f1ApplySavedParams( slot, step, state );
         if ( step.kind == "icon" )
         {
            step.processId = state.par.processId || step.processId;
            step.title = state.par.title || step.title;
         }
      }
   }
   f1LoadPhaseSettings( "pre" );
   f1LoadPhaseSettings( "post" );
   f1ApplyBuiltinSlotPolicy();
}

function f1ExtraForWrite( slot )
{
   let extraOut = [];
   let extra = f1.extra[slot] || [];
   for ( let i = 0; i < extra.length; ++i )
   {
      let step = extra[i];
      let par = f1.steps[slot][step.id] ? f1.steps[slot][step.id].par : {};
      extraOut.push( {
         id: step.id,
         kind: "icon",
         title: step.title,
         processId: step.processId || par.processId,
         iconName: par.iconName || step.iconName || f1IconNameFromTitle( step.title ),
         source: par.source || ""
      } );
   }
   return extraOut;
}

function f1WriteSettings()
{
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      Settings.write( SETTINGS_PREFIX + "view" + slot, DataType.String, f1.views[slot] );
      Settings.write( SETTINGS_PREFIX + "order_" + slot, DataType.String,
                      JSON.stringify( f1NormalizeOrder( slot, f1.order[slot] ) ) );
      Settings.write( SETTINGS_PREFIX + "extra_" + slot, DataType.String, JSON.stringify( f1ExtraForWrite( slot ) ) );
      Settings.write( SETTINGS_PREFIX + "adopted_" + slot, DataType.String, JSON.stringify( f1AdoptedForWrite( slot ) ) );
      Settings.write( SETTINGS_PREFIX + "removed_" + slot, DataType.String, JSON.stringify( f1RemovedList( slot ) ) );
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         Settings.write( SETTINGS_PREFIX + "on_" + slot + "_" + step.id, DataType.Int32, state.on ? 1 : 0 );
         Settings.write( SETTINGS_PREFIX + "par_" + slot + "_" + step.id, DataType.String, JSON.stringify( state.par ) );
      }
   }
   f1WritePhaseSettings( "pre" );
   f1WritePhaseSettings( "post" );
   Settings.write( SETTINGS_PREFIX + "basePreset", DataType.String, f1.activePreset || F1_LRGB_PRESET );
}

function f1CollectProfile()
{
   let slots = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      let stepMap = {};
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         stepMap[step.id] = {
            on: state.on ? true : false,
            par: state.par || {}
         };
      }
      slots[slot] = {
         order: f1NormalizeOrder( slot, f1.order[slot] ),
         extra: f1ExtraForWrite( slot ),
         adopted: f1AdoptedForWrite( slot ),
         removed: f1RemovedList( slot ),
         steps: stepMap
      };
   }
   return {
      format: "BatchProcessing_byHrast",
      version: 2,
      basePreset: f1.activePreset || F1_LRGB_PRESET,
      marsFiles: f1MarsFiles(),
      slots: slots,
      pre: f1CollectPhaseProfile( "pre" ),
      post: f1CollectPhaseProfile( "post" )
   };
}

function f1ApplyExtraList( slot, list )
{
   f1.extra[slot] = [];
   if ( !list || !Array.isArray( list ) )
      return;
   for ( let i = 0; i < list.length; ++i )
   {
      let item = list[i];
      if ( !item || !item.id || item.kind != "icon" || !item.processId )
         continue;
      let step = {
         id: item.id,
         title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
         kind: "icon",
         processId: item.processId,
         iconName: item.iconName || f1IconNameFromTitle( item.title )
      };
      f1.extra[slot].push( step );
      f1.steps[slot][step.id] = {
         on: true,
         par: {
            processId: item.processId,
            iconName: item.iconName || "",
            source: item.source || "",
            title: step.title
         }
      };
   }
}

function f1ApplyProfile( profile )
{
   if ( !profile || typeof profile != "object" )
      throw new Error( "Invalid settings file." );
   if ( profile.format != "BatchProcessing_byHrast" )
      throw new Error( "Not a BatchProcessing_byHrast settings file." );
   let base = f1NormalizePresetName( profile.basePreset || "" );
   f1.activePreset = f1IsBuiltinPreset( base ) ? base : f1InferBasePreset( profile );
   let viewsKeep = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      viewsKeep[F1_SLOTS[s]] = f1.views[F1_SLOTS[s]] || "";
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      f1.views[F1_SLOTS[s]] = viewsKeep[F1_SLOTS[s]];
   if ( Array.isArray( profile.marsFiles ) )
      f1WriteMarsFiles( profile.marsFiles );
   let slots = profile.slots || {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      let data = slots[slot] || {};
      f1ApplyExtraList( slot, data.extra );
      f1ApplyRemovedList( slot, data.removed );
      f1ApplyAdoptedList( slot, data.adopted );
      f1.order[slot] = f1NormalizeOrder( slot, data.order );
      let stepMap = data.steps || {};
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         let saved = stepMap[step.id];
         if ( !saved || typeof saved != "object" )
            continue;
         if ( saved.on != null )
            state.on = saved.on ? true : false;
         if ( saved.par && typeof saved.par == "object" )
         {
            for ( let key in saved.par )
               if ( saved.par[key] != null )
                  state.par[key] = saved.par[key];
         }
         if ( step.kind == "icon" )
         {
            step.processId = state.par.processId || step.processId;
            step.title = state.par.title || step.title;
         }
      }
   }
   f1ApplyPhaseProfile( "pre", profile.pre );
   f1ApplyPhaseProfile( "post", profile.post );
}

function f1ResetToDefaults( preset )
{
   let viewsKeep = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      viewsKeep[F1_SLOTS[s]] = f1.views[F1_SLOTS[s]] || "";
   f1InitSteps( preset || F1_LRGB_PRESET );
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      f1.views[F1_SLOTS[s]] = viewsKeep[F1_SLOTS[s]];
}

function f1WipeFlagPath()
{
   return File.systemTempDirectory + "/BatchProcessing_byHrast.wipe";
}

function f1FactoryResetAllSettings()
{
   // Drop named presets first (in case module remove is shallow).
   let list = [];
   try { list = f1ListPresets(); } catch ( e ) { list = []; }
   for ( let i = 0; i < list.length; ++i )
   {
      try
      {
         let key = SETTINGS_PREFIX + f1PresetStorageKey( list[i] );
         if ( typeof Settings.remove == "function" )
            Settings.remove( key );
         else
            Settings.write( key, DataType.String, "" );
      }
      catch ( e )
      {
      }
   }
   try
   {
      if ( typeof Settings.remove == "function" )
         Settings.remove( "BatchProcessing_byHrast" );
   }
   catch ( e )
   {
   }
   try
   {
      if ( typeof Settings.remove == "function" )
         Settings.remove( "Faza1" );
   }
   catch ( e )
   {
   }
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      f1.views[F1_SLOTS[s]] = "";
   f1.solverKeep = {};
   f1.processSeed = null;
   f1InitSteps();
   f1WriteSettings();
   try
   {
      Settings.write( SETTINGS_PREFIX + "presetList", DataType.String, "[]" );
      Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, F1_BUILTIN_PRESET );
   }
   catch ( e )
   {
   }
   console.noteln( "<end><cbr><br>* Factory reset: all BatchProcessing_byHrast presets/settings cleared; "
                   + F1_BUILTIN_PRESET + " loaded." );
}

function f1MaybeFactoryResetFromFlag()
{
   let path = f1WipeFlagPath();
   if ( !File.exists( path ) )
      return false;
   try
   {
      f1FactoryResetAllSettings();
   }
   finally
   {
      try { File.remove( path ); } catch ( e ) {}
   }
   return true;
}

function f1NormalizePresetName( name )
{
   name = ( name == null ? "" : name.toString() ).replace( /^\s+|\s+$/g, "" ).replace( /\s+/g, " " );
   if ( !name )
      return "";
   // Legacy "Default" and "LRGB Default" map to LRGB_Default.
   // "SHO Default", "SHO_Default" and "SHO2_Default" are the one narrowband preset.
   if ( /^sho2[_\s-]*default$/i.test( name ) )
      return F1_SHO_PRESET;
   if ( /^sho[_\s-]*default$/i.test( name ) )
      return F1_SHO_PRESET;
   if ( /^clear[\s_-]*all$/i.test( name ) )
      return F1_CLEAR_PRESET;
   if ( /^default$/i.test( name ) || /^lrgb[\s_-]*default$/i.test( name ) )
      return F1_LRGB_PRESET;
   name = name.replace( /[\/\\:*?"<>|]/g, "_" );
   if ( name.length > 64 )
      name = name.substring( 0, 64 );
   return name;
}

function f1PresetStorageKey( name )
{
   return "presetData_" + f1NormalizePresetName( name );
}

function f1ListPresets()
{
   let raw = f1ReadString( "presetList", "[]" );
   let list = [];
   try
   {
      list = JSON.parse( raw );
   }
   catch ( e )
   {
      list = [];
   }
   if ( !Array.isArray( list ) )
      list = [];
   let out = [];
   let seen = {};
   for ( let i = 0; i < list.length; ++i )
   {
      let name = f1NormalizePresetName( list[i] );
      if ( !name || f1IsBuiltinPreset( name ) || seen[name.toLowerCase()] )
         continue;
      seen[name.toLowerCase()] = true;
      out.push( name );
   }
   out.sort( function( a, b ) { return a.toLowerCase() < b.toLowerCase() ? -1 : ( a.toLowerCase() > b.toLowerCase() ? 1 : 0 ); } );
   return out;
}

function f1WritePresetList( list )
{
   Settings.write( SETTINGS_PREFIX + "presetList", DataType.String, JSON.stringify( list || [] ) );
}

function f1SaveNamedPreset( name, profile )
{
   name = f1NormalizePresetName( name );
   if ( !name || f1IsBuiltinPreset( name ) )
      throw new Error( "Choose a preset name other than " + F1_LRGB_PRESET + ", " + F1_SHO_PRESET + " or " + F1_CLEAR_PRESET + "." );
   if ( !profile )
      profile = f1CollectProfile();
   Settings.write( SETTINGS_PREFIX + f1PresetStorageKey( name ), DataType.String, JSON.stringify( profile ) );
   let list = f1ListPresets();
   let found = false;
   for ( let i = 0; i < list.length; ++i )
      if ( list[i].toLowerCase() == name.toLowerCase() )
      {
         list[i] = name;
         found = true;
         break;
      }
   if ( !found )
      list.push( name );
   list.sort( function( a, b ) { return a.toLowerCase() < b.toLowerCase() ? -1 : ( a.toLowerCase() > b.toLowerCase() ? 1 : 0 ); } );
   f1WritePresetList( list );
   Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, name );
   return name;
}

function f1LoadNamedPreset( name )
{
   name = f1NormalizePresetName( name );
   if ( !name || f1IsBuiltinPreset( name ) )
      return null;
   let raw = f1ReadString( f1PresetStorageKey( name ), "" );
   if ( !raw )
      throw new Error( "Preset not found: " + name );
   let profile = JSON.parse( raw );
   Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, name );
   return profile;
}

function f1DeleteNamedPreset( name )
{
   name = f1NormalizePresetName( name );
   if ( !name || f1IsBuiltinPreset( name ) )
      throw new Error( F1_LRGB_PRESET + ", " + F1_SHO_PRESET + " and " + F1_CLEAR_PRESET + " cannot be deleted." );
   let key = SETTINGS_PREFIX + f1PresetStorageKey( name );
   try
   {
      if ( typeof Settings.remove == "function" )
         Settings.remove( key );
      else
         Settings.write( key, DataType.String, "" );
   }
   catch ( e )
   {
      Settings.write( key, DataType.String, "" );
   }
   let list = f1ListPresets();
   let next = [];
   for ( let i = 0; i < list.length; ++i )
      if ( list[i].toLowerCase() != name.toLowerCase() )
         next.push( list[i] );
   f1WritePresetList( next );
   let last = f1ReadString( "lastPreset", F1_BUILTIN_PRESET );
   if ( f1NormalizePresetName( last ).toLowerCase() == name.toLowerCase() )
      Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, F1_BUILTIN_PRESET );
   return name;
}

function f1Message( text, info )
{
   ( new MessageBox( text, "BatchProcessing_byHrast", info ? StdIcon.Information : StdIcon.Warning, StdButton.Ok ) ).execute();
}

function f1Set( process, name, value )
{
   try
   {
      process[name] = value;
      return true;
   }
   catch ( e )
   {
      return false;
   }
}

function f1Need( process, name, value )
{
   if ( !f1Set( process, name, value ) )
      throw new Error( "Parameter was not accepted: " + name );
}

function f1ProcessEnum( ctor, name, numericFallback )
{
   try
   {
      if ( ctor && ctor.prototype && ctor.prototype[name] != null )
         return ctor.prototype[name];
   }
   catch ( e )
   {
   }
   return numericFallback;
}

function f1RequireModule( name, present )
{
   if ( !present )
      throw new Error( name + " is not installed." );
}

function f1BuildSpikeLess( par )
{
   f1RequireModule( "SpikeLessAI", typeof SpikeLessAI == "function" );
   let process = new SpikeLessAI;
   f1Set( process, "model", par.model );
   f1Set( process, "processingMode",
          par.mode == "Stretched" ? "Direct" : "LinearVirtualStretch" );
   f1Need( process, "strength", par.strength );
   f1Need( process, "stride", Math.round( par.stride ) );
   f1Set( process, "starSeparation", par.starLayer );
   f1Need( process, "generateSpikeImage", par.generateSpikeImage ? true : false );
   f1Set( process, "polishLeftovers", par.cleanLongTails ? true : false );
   f1Set( process, "farSpikePass", par.cleanLongTails ? true : false );
   f1Set( process, "removeAllSpikes", false );
   f1Set( process, "repairDarkLines", false );
   f1Set( process, "createSpikes", false );
   f1Set( process, "useGPU", true );
   return process;
}

function f1BuildBlurX( par )
{
   f1RequireModule( "BlurXTerminator", typeof BlurXTerminator == "function" );
   let process = new BlurXTerminator;
   let correct = par.correctOnly ? true : false;
   f1Set( process, "ml_version", 0 );
   f1Need( process, "correct_only", correct );
   f1Set( process, "sharpen_stars", correct ? 0 : par.sharpenStars );
   f1Set( process, "adjust_star_halos", correct ? 0 : par.starHalos );
   f1Set( process, "nonstellar_diameter", 0.0 );
   f1Set( process, "auto_nonstellar_psf", true );
   f1Set( process, "sharpen_nonstellar", correct ? 0 : par.sharpenNonstellar );
   f1Set( process, "lunar_planetary", false );
   f1Set( process, "overlap", par.overlap );
   return process;
}

function f1BuildBlurless( par )
{
   f1RequireModule( "BlurlessAI", typeof BlurlessAI == "function" );
   let process = new BlurlessAI;
   f1Need( process, "amount", par.amount );
   let coresName = ( typeof par.coresAbove == "string" && par.coresAbove.length ) ? par.coresAbove : "Clip";
   let coresIndex = { Clip: 0, Keep: 1, Rescale: 2 };
   let cores = ( typeof par.coresAbove == "number" ) ? par.coresAbove
             : f1ProcessEnum( BlurlessAI, coresName,
                              coresIndex[coresName] != null ? coresIndex[coresName] : 0 );
   f1Need( process, "coresAbove", cores );
   let colourName = ( par.colourMode == "Luminance" ) ? "Luminance" : "Channels";
   let colourIndex = { Channels: 0, Luminance: 1 };
   let colour = ( typeof par.colourMode == "number" ) ? par.colourMode
              : f1ProcessEnum( BlurlessAI, colourName, colourIndex[colourName] );
   f1Need( process, "colourMode", colour );
   f1Need( process, "alignChannels", par.alignChannels ? true : false );
   f1Need( process, "crisperSpikes", par.crisperSpikes ? true : false );
   f1Set( process, "useGPU", true );
   return process;
}

function f1FillFlux( process, par )
{
   let grayName = par.grayName || EC_grayFilterName;
   f1Need( process, "narrowbandMode", par.narrowband ? true : false );
   f1Need( process, "grayFilterTrCurve", f1Curve( grayName, EC_grayFilterTrCurve ) );
   f1Need( process, "grayFilterName", grayName );
   f1Need( process, "grayFilterWavelength", par.wavelength );
   f1Need( process, "grayFilterBandwidth", par.bandwidth );
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "redFilterWavelength", isFinite( par.redWavelength ) ? par.redWavelength : 656.3 );
   f1Set( process, "redFilterBandwidth", isFinite( par.redBandwidth ) ? par.redBandwidth : 3.0 );
   f1Set( process, "greenFilterWavelength", isFinite( par.greenWavelength ) ? par.greenWavelength : 500.7 );
   f1Set( process, "greenFilterBandwidth", isFinite( par.greenBandwidth ) ? par.greenBandwidth : 3.0 );
   f1Set( process, "blueFilterWavelength", isFinite( par.blueWavelength ) ? par.blueWavelength : 500.7 );
   f1Set( process, "blueFilterBandwidth", isFinite( par.blueBandwidth ) ? par.blueBandwidth : 3.0 );
   f1Set( process, "broadbandIntegrationStepSize", 0.5 );
   f1Set( process, "narrowbandIntegrationSteps", 10 );
   f1Set( process, "rejectionLimit", 0.3 );
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "minMagnitude", 0 );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "psfStructureLayers", 5 );
   f1Set( process, "saturationThreshold", 0.75 );
   f1Set( process, "saturationRelative", true );
   f1Set( process, "saturationShrinkFactor", 0.10 );
   f1Set( process, "psfNoiseLayers", 1 );
   f1Set( process, "psfHotPixelFilterRadius", 1 );
   f1Set( process, "psfNoiseReductionFilterRadius", 0 );
   f1Set( process, "psfMinStructureSize", 0 );
   f1Set( process, "psfMinSNR", 40 );
   f1Set( process, "psfAllowClusteredSources", false );
   f1Set( process, "psfGrowth", 1.75 );
   f1Set( process, "psfMaxStars", 24576 );
   f1Set( process, "psfSearchTolerance", 4 );
   f1Set( process, "psfChannelSearchTolerance", 2 );
   f1Set( process, "generateGraphs", par.generateGraphs === false ? false : true );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   try
   {
      process.psfType = SpectrophotometricFluxCalibration.PSFType_Auto;
   }
   catch ( e )
   {
   }
}

function f1BuildFlux( par )
{
   f1RequireModule( "SpectrophotometricFluxCalibration", typeof SpectrophotometricFluxCalibration == "function" );
   let process = new SpectrophotometricFluxCalibration;
   f1FillFlux( process, par );
   return process;
}

function f1BuildGradient( par )
{
   f1RequireModule( "MultiscaleGradientCorrection", typeof MultiscaleGradientCorrection == "function" );
   let process = new MultiscaleGradientCorrection;
   f1Need( process, "useMARSDatabase", true );
   f1Need( process, "grayMARSFilter", par.grayFilter );
   f1Need( process, "redMARSFilter", "R" );
   f1Need( process, "greenMARSFilter", "G" );
   f1Need( process, "blueMARSFilter", "B" );
   f1Set( process, "referenceImageId", "" );
   f1Need( process, "gradientScale", Math.round( par.scale ) );
   f1Need( process, "structureSeparation", Math.round( par.separation ) );
   f1Need( process, "modelSmoothness", par.smoothness );
   f1Set( process, "minFieldRatio", 0.017 );
   f1Set( process, "maxFieldRatio", 0.167 );
   f1Set( process, "enforceFieldLimits", true );
   f1Set( process, "scaleFactorRK", 1 );
   f1Set( process, "scaleFactorG", 1 );
   f1Set( process, "scaleFactorB", 1 );
   f1Set( process, "showGradientModel", par.showModel ? true : false );
   f1Set( process, "command", "" );
   let files = f1MarsFiles().filter( function( path ) { return File.exists( path ); } );
   if ( files.length == 0 )
      throw new Error( "No MARS database files. Add them in MultiscaleGradientCorrection Settings." );
   f1Need( process, "marsDatabaseFiles", files.map( function( path ) { return [ true, path ]; } ) );
   return process;
}

function f1BuildColor( par )
{
   f1RequireModule( "SpectrophotometricColorCalibration", typeof SpectrophotometricColorCalibration == "function" );
   let process = new SpectrophotometricColorCalibration;
   f1Set( process, "narrowbandMode", par.narrowband ? true : false );
   f1Set( process, "narrowbandOptimizeStars", par.optimizeStars ? true : false );
   if ( par.narrowband )
   {
      f1Need( process, "redFilterWavelength", par.redWavelength != null ? par.redWavelength : 656.3 );
      f1Need( process, "redFilterBandwidth", par.redBandwidth != null ? par.redBandwidth : 6.0 );
      f1Need( process, "greenFilterWavelength", par.greenWavelength != null ? par.greenWavelength : 500.7 );
      f1Need( process, "greenFilterBandwidth", par.greenBandwidth != null ? par.greenBandwidth : 6.0 );
      f1Need( process, "blueFilterWavelength", par.blueWavelength != null ? par.blueWavelength : 500.7 );
      f1Need( process, "blueFilterBandwidth", par.blueBandwidth != null ? par.blueBandwidth : 6.0 );
   }
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "whiteReferenceName", par.whiteReference || "Average Spiral Galaxy" );
   f1Set( process, "applyCalibration", par.applyCalibration !== false );
   if ( par.neutralizeBackground )
   {
      f1Set( process, "neutralizeBackground", true );
      f1Set( process, "backgroundLow", isFinite( par.backgroundLow ) ? par.backgroundLow : -2.8 );
      f1Set( process, "backgroundHigh", isFinite( par.backgroundHigh ) ? par.backgroundHigh : 2.0 );
      f1Set( process, "backgroundUseROI", false );
   }
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "generateGraphs", false );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   return process;
}

function f1BuildNoise( par )
{
   f1RequireModule( "NoiseXTerminator", typeof NoiseXTerminator == "function" );
   let process = new NoiseXTerminator;
   f1Need( process, "denoise", par.denoise );
   f1Need( process, "detail", par.detail );
   return process;
}

function f1BuildStars( par )
{
   f1RequireModule( "StarXTerminator", typeof StarXTerminator == "function" );
   let process = new StarXTerminator;
   f1Need( process, "output_stars", par.outputStars ? true : false );
   f1Set( process, "unscreen", par.outputStars && par.unscreen ? true : false );
   if ( par.overlap != null && isFinite( par.overlap ) )
      f1Set( process, "overlap", par.overlap );
   return process;
}

function f1CopyRow( row )
{
   return [ row[0], row[1], row[2], row[3], row[4] ];
}

function f1StretchRow( median, mad, channel, inverted, shadowsClipping, targetBackground )
{
   let med = median.at( channel );
   let dev = mad.at( channel );
   if ( !inverted )
   {
      let c0 = ( 1 + dev != 1 ) ? Math.range( med + shadowsClipping * dev, 0.0, 1.0 ) : 0.0;
      let midtone = Math.mtf( targetBackground, med - c0 );
      return [ c0, 1, midtone, 0, 1 ];
   }
   let c1 = ( 1 + dev != 1 ) ? Math.range( med - shadowsClipping * dev, 0.0, 1.0 ) : 1.0;
   let midtone = Math.mtf( c1 - med, targetBackground );
   return [ 0, c1, midtone, 0, 1 ];
}

function f1MakeScreen( view, par )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let linked = par.linked ? true : false;
   let shadowsClipping = isFinite( par.shadows ) ? par.shadows : -2.8;
   let targetBackground = isFinite( par.target ) ? par.target : 0.25;
   let process = new ScreenTransferFunction;
   let rows = [
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ]
   ];
   if ( view && view.image )
   {
      let color = view.image.isColor;
      let count = color ? 3 : 1;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );
      if ( linked || !color )
      {
         let inverted = 0;
         for ( let c = 0; c < count; ++c )
            if ( median.at( c ) > 0.5 )
               ++inverted;
         let row;
         if ( inverted < count )
         {
            let c0 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               if ( 1 + mad.at( c ) != 1 )
                  c0 += median.at( c ) + shadowsClipping * mad.at( c );
               mid += median.at( c );
            }
            c0 = Math.range( c0 / count, 0.0, 1.0 );
            row = [ c0, 1, Math.mtf( targetBackground, mid / count - c0 ), 0, 1 ];
         }
         else
         {
            let c1 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               mid += median.at( c );
               if ( 1 + mad.at( c ) != 1 )
                  c1 += median.at( c ) - shadowsClipping * mad.at( c );
               else
                  c1 += 1;
            }
            c1 = Math.range( c1 / count, 0.0, 1.0 );
            row = [ 0, c1, Math.mtf( c1 - mid / count, targetBackground ), 0, 1 ];
         }
         let limit = color ? 3 : 1;
         for ( let c = 0; c < limit; ++c )
            rows[c] = f1CopyRow( row );
      }
      else
      {
         for ( let c = 0; c < count; ++c )
            rows[c] = f1StretchRow( median, mad, c, median.at( c ) >= 0.5, shadowsClipping, targetBackground );
      }
   }
   process.STF = rows;
   return process;
}

function f1ResetScreen( view )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let process = new ScreenTransferFunction;
   let row = [ 0, 1, 0.5, 0, 1 ];
   process.STF = [ row.slice( 0 ), row.slice( 0 ), row.slice( 0 ), row.slice( 0 ) ];
   if ( process.executeOn( view, false ) === false )
      throw new Error( "ScreenTransferFunction failed." );
}

function f1BuildHisto( par )
{
   f1RequireModule( "HistogramTransformation", typeof HistogramTransformation == "function" );
   let process = new HistogramTransformation;
   process.H = f1CloneHistoH( par && par.H ? par.H : f1HistoCurve( 0.0023, 0.03037975, 0.38481013 ) );
   return process;
}

function f1BuildPixelMath( par )
{
   f1RequireModule( "PixelMath", typeof PixelMath == "function" );
   let process = new PixelMath;
   process.expression = ( par && par.expression ) ? String( par.expression ) : "$T*2";
   f1Set( process, "useSingleExpression", true );
   f1Set( process, "createNewImage", false );
   return process;
}

function f1BuildStretch( par )
{
   f1RequireModule( "MultiscaleAdaptiveStretch", typeof MultiscaleAdaptiveStretch == "function" );
   let process = new MultiscaleAdaptiveStretch;
   f1Need( process, "targetBackground", par.targetBackground );
   f1Need( process, "aggressiveness", par.aggressiveness );
   f1Need( process, "dynamicRangeCompression", par.dynamicRange );
   f1Need( process, "contrastRecovery", par.contrastRecovery ? true : false );
   f1Need( process, "scaleSeparation", Math.round( par.scaleSeparation ) );
   f1Need( process, "contrastRecoveryIntensity", par.intensity );
   f1Need( process, "saturationEnabled", par.saturation ? true : false );
   f1Need( process, "saturationAmount", par.saturationAmount );
   f1Need( process, "saturationBoost", par.saturationBoost );
   f1Set( process, "previewLargeScale", false );
   f1Set( process, "backgroundROIEnabled", false );
   return process;
}

function f1Build( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( step.kind == "spikeless" )
      return f1BuildSpikeLess( par );
   if ( step.kind == "blurx" )
      return f1BuildBlurX( par );
   if ( step.kind == "blurless" )
      return f1BuildBlurless( par );
   if ( step.kind == "spfc" )
      return f1BuildFlux( par );
   if ( step.kind == "mgc" )
      return f1BuildGradient( par );
   if ( step.kind == "spcc" )
      return f1BuildColor( par );
   if ( step.kind == "noisex" )
      return f1BuildNoise( par );
   if ( step.kind == "starx" )
      return f1BuildStars( par );
   if ( step.kind == "histo" )
      return f1BuildHisto( par );
   if ( step.kind == "pm" )
      return f1BuildPixelMath( par );
   if ( step.kind == "screen" )
      return f1MakeScreen( view, par );
   if ( step.kind == "stretch" )
      return f1BuildStretch( par );
   if ( step.kind == "icon" )
      return f1BuildFromIconSource( f1EnsureIconSource( step, par ) );
   return null;
}

function f1OpenSolver( slot, view )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   if ( typeof ImageSolverDialog != "function" )
      throw new Error( "ImageSolver dialog is not available." );
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      if ( view )
         solver.initialize( view.window, false /*prioritizeSettings*/ );
      solver.solverCfg.useActive = true;
   }
   let gui = new ImageSolverDialog( solver.solverCfg, solver.metadata, true /*showTargetImage*/ );
   if ( gui.execute() )
      f1.solverKeep[slot] = solver;
}

function f1OpenStep( slot, step, view )
{
   if ( step.kind == "solver" )
   {
      f1OpenSolver( slot, view );
      return false;
   }
   let gui = new FazaSetupDialog( slot, step, f1.steps[slot][step.id].par );
   return gui.execute() ? true : false;
}

function f1ApplyAstrometrySeed( solver, seed )
{
   if ( !solver || !solver.metadata || !seed )
      return;
   solver.metadata.ra = seed.ra;
   solver.metadata.dec = seed.dec;
   if ( seed.resolution != null && isFinite( seed.resolution ) && seed.resolution > 0 )
   {
      solver.metadata.resolution = seed.resolution;
      solver.metadata.useFocal = false;
   }
   if ( seed.focal != null && isFinite( seed.focal ) && seed.focal > 0 )
      solver.metadata.focal = seed.focal;
   if ( seed.xpixsz != null && isFinite( seed.xpixsz ) && seed.xpixsz > 0 )
      solver.metadata.xpixsz = seed.xpixsz;
}

function f1Solve( window, slot )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   console.writeln( "<end><cbr><br>ImageSolver" );
   console.flush();
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      solver.initialize( window, false /*prioritizeSettings*/ );
   }
   solver.solverCfg.useActive = true;
   if ( typeof solver.hasValidSeed == "function" && !solver.hasValidSeed() )
   {
      let seed = f1.processSeed;
      if ( !seed )
      {
         let dlg = new F1AstrometrySeedDialog( solver.metadata );
         if ( !dlg.execute() || !dlg.seed )
            throw new Error( "ImageSolver: cancelled (no coordinates)" );
         seed = dlg.seed;
         f1.processSeed = seed;
      }
      f1ApplyAstrometrySeed( solver, seed );
      if ( typeof solver.hasValidSeed == "function" && !solver.hasValidSeed() )
         throw new Error( "ImageSolver: invalid starting coordinates or scale" );
   }
   window.bringToFront();
   solver.solveImage( window );
   console.writeln( window.astrometricSolutionSummary().trim() );
}

function f1RunBlindSolve( window, slot, par )
{
   f1RequireModule( "BlindSolver", typeof BlindSolverEngine == "function" );
   console.writeln( "<end><cbr><br>BlindSolver" );
   console.flush();
   let config = new BlindSolverConfiguration( "BlindSolver" );
   config.LoadSettings();
   config.useActive = true;
   let timeLimit = par && par.timeLimit;
   if ( !( timeLimit > 0 ) && slot && f1.steps[slot] && f1.steps[slot].blindsolver && f1.steps[slot].blindsolver.par )
      timeLimit = f1.steps[slot].blindsolver.par.timeLimit;
   if ( timeLimit != null && isFinite( timeLimit ) && timeLimit > 0 )
      config.timeLimit = timeLimit;
   config.Validate();
   let engine = new BlindSolverEngine( config );
   engine.interactive = false;
   window.bringToFront();
   engine.solveWindow( window );
   try
   {
      console.writeln( window.astrometricSolutionSummary().trim() );
   }
   catch ( e )
   {
   }
}

function f1RunGraXpert( window, slot )
{
   f1RequireModule( "GraXpert", typeof GraXpertLib == "function" );
   let gxp = new GraXpertLib;
   if ( !gxp.hasGraXpertPath() )
      throw new Error( "GraXpert path is not configured (Script > Toolbox > GraXpert)." );
   console.writeln( "<end><cbr><br>GraXpert" );
   console.flush();
   let par = f1.steps[slot] && f1.steps[slot].graxpert ? f1.steps[slot].graxpert.par : {};
   gxp.graxpertParameters.targetView = window.mainView;
   gxp.graxpertParameters.correction = ( par.correction == 1 ) ? 1 : 0;
   gxp.graxpertParameters.smoothing = ( par.smoothing != null && isFinite( par.smoothing ) )
                                      ? Math.range( par.smoothing, 0, 1 ) : 0.0;
   // Batch chain must replace the working image and must not open background windows.
   gxp.graxpertParameters.replaceTarget = true;
   gxp.graxpertParameters.showBackground = false;
   window.bringToFront();
   gxp.process();
}

function f1Execute( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( !f1RecipeStep( slot, step ) )
   {
      let channel = par && par.channel != null ? String( par.channel ).replace( /^\s+|\s+$/g, "" ) : "";
      if ( !channel && par && par.input != null )
         channel = String( par.input ).replace( /^\s+|\s+$/g, "" );
      if ( !channel )
         throw new Error( step.title + ": set the channel." );
      view = f1RequireNamedView( channel, step.title );
   }
   if ( step.kind == "screen" )
   {
      console.writeln( "<end><cbr><br>ScreenTransferFunction  "
                       + ( par.linked ? "linked channels" : "channels separate" ) );
      console.flush();
      let process = f1MakeScreen( view, par );
      if ( process.executeOn( view, false ) === false )
         throw new Error( "ScreenTransferFunction failed." );
      return;
   }
   if ( step.kind == "spcc" && ( !view.image || !view.image.isColor ) )
      throw new Error( "SpectrophotometricColorCalibration needs a three-channel image." );
   console.writeln( "<end><cbr><br>" + step.title );
   console.flush();
   let beforeIds = null;
   let starSlot = slot;
   if ( !f1RecipeStep( slot, step ) && par && par.channel )
      starSlot = String( par.channel ).replace( /^\s+|\s+$/g, "" );
   if ( step.kind == "starx" && f1ExportsStars( starSlot ) && ( f1RecipeStep( slot, step ) || par.outputStars ) )
   {
      if ( f1RecipeStep( slot, step ) )
         par.outputStars = true;
      beforeIds = f1WindowIds();
   }
   let instance = f1Build( slot, step, view );
   if ( !instance )
      throw new Error( step.title + " is not ready." );
   if ( instance.executeOn( view ) === false )
      throw new Error( step.title + " failed." );
   if ( step.kind == "stretch" )
      f1ResetScreen( view );
   if ( beforeIds )
      f1RenameStarXResult( starSlot, beforeIds );
}

function f1EnglishList( names )
{
   if ( !names || !names.length )
      return "";
   if ( names.length == 1 )
      return names[0];
   if ( names.length == 2 )
      return names[0] + " and " + names[1];
   let copy = names.slice( 0 );
   let last = copy.pop();
   return copy.join( ", " ) + " and " + last;
}

function f1SlotFailureFrom( error )
{
   if ( error && error.slotFailure && error.slotFailure.slot )
      return error.slotFailure;
   if ( f1.lastSlotFailure && f1.lastSlotFailure.slot )
      return f1.lastSlotFailure;
   return null;
}

function f1ThrowSlotFailure( slot, step, index, error )
{
   let message = slot + " · " + step.title + ": " + f1ErrorText( error );
   let info = {
      slot: slot,
      stepId: step.id,
      stepTitle: step.title,
      stepIndex: index,
      message: message
   };
   f1.lastSlotFailure = info;
   let wrapped = new Error( message );
   wrapped.slotFailure = info;
   throw wrapped;
}

function f1RunSlot( slot, view, startIndex )
{
   f1.lastSlotFailure = null;
   let window = view.window;
   console.noteln( "<end><cbr><br>* " + slot + ": " + view.id );
   console.flush();
   let steps = f1OrderedSteps( slot );
   let ran = false;
   let begin = startIndex > 0 ? startIndex : 0;
   for ( let i = begin; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1.steps[slot][step.id];
      if ( !state.on )
         continue;
      if ( !f1StepInstalled( step ) )
      {
         console.warningln( "<end><cbr>** " + step.title + " is not installed. Step skipped." );
         continue;
      }
      ran = true;
      try
      {
         if ( step.kind == "solver" )
            f1Solve( window, slot );
         else if ( step.kind == "graxpert" )
            f1RunGraXpert( window, slot );
         else if ( step.kind == "blindsolver" )
            f1RunBlindSolve( window, slot );
         else
            f1Execute( slot, step, view );
      }
      catch ( e )
      {
         if ( f1UserAbort() )
            throw e;
         console.criticalln( "*** " + slot + " · " + step.title + ": " + f1ErrorText( e ) );
         f1ThrowSlotFailure( slot, step, i, e );
      }
      if ( f1UserAbort() )
         throw new Error( "Aborted by user." );
      CoreApplication.processEvents();
   }
   if ( !ran )
      console.writeln( "No enabled steps." );
   console.noteln( "<end><cbr>* " + slot + " done: " + view.id );
}

var F1FailureChoiceDialog = class extends Dialog
{
   constructor( failures )
   {
      super();
      this.choice = "stop";
      this.windowTitle = "BatchProcessing_byHrast";
      this.userResizable = true;
      let dialog = this;
      let lines = [];
      let slots = [];
      for ( let i = 0; i < failures.length; ++i )
      {
         lines.push( "Skip failed step " + failures[i].stepTitle
                     + " and continue other steps" );
         if ( slots.indexOf( failures[i].slot ) < 0 )
            slots.push( failures[i].slot );
      }
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "A step stopped before that channel was finished. "
                + "The other channels have already been processed as far as they can.";

      let cont = new PushButton( this );
      cont.text = failures.length == 1
         ? lines[0]
         : "Skip the failed steps and continue other steps";
      cont.toolTip = "<p>" + lines.join( "<br/>" ) + "</p>";
      cont.onClick = function()
      {
         dialog.choice = "continue";
         dialog.ok();
      };
      let stopText = "Stop the rest of script";
      let stop = new PushButton( this );
      stop.text = stopText;
      stop.onClick = function()
      {
         dialog.choice = "stop";
         dialog.ok();
      };

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add( note );
      for ( let i = 0; i < lines.length; ++i )
      {
         let line = new Label( this );
         line.wordWrapping = true;
         line.text = lines[i];
         this.sizer.add( line );
      }
      this.sizer.addSpacing( 6 );
      this.sizer.add( cont );
      this.sizer.add( stop );
      this.setScaledMinWidth( 720 );
   }
};

function f1IconToken( text )
{
   let token = String( text == null ? "" : text ).replace( /[^A-Za-z0-9_]/g, "" );
   return token.length ? token : "step";
}

function f1UniqueIconId( base )
{
   let icons = [];
   try
   {
      icons = ProcessInstance.icons();
   }
   catch ( e )
   {
      icons = [];
   }
   if ( icons.indexOf( base ) < 0 )
      return base;
   let n = 2;
   while ( icons.indexOf( base + "_" + n ) >= 0 )
      ++n;
   return base + "_" + n;
}

function f1CanSaveAsProcess( step )
{
   return step.kind != "solver" && step.kind != "blindsolver" && step.kind != "graxpert";
}

function f1InstallProcessIcon( iconId, pieces, y )
{
   let instanceId = iconId + "_instance";
   let xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
   xml += "<xpsm version=\"1.0\" xmlns=\"http://www.pixinsight.com/xpsm\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.pixinsight.com/xpsm http://pixinsight.com/xpsm/xpsm-1.0.xsd\">\n";
   xml += "<instance class=\"ProcessContainer\" id=\"" + instanceId + "\">\n";
   xml += pieces.join( "\n" ) + "\n";
   xml += "</instance>\n";
   xml += "<icon id=\"" + iconId + "\" instance=\"" + instanceId
        + "\" xpos=\"80\" ypos=\"" + y + "\" workspace=\"Workspace01\"/>\n";
   xml += "</xpsm>\n";
   let path = ( File.systemTempDirectory + "/" + iconId + ".xpsm" ).replace( /\\/g, "/" );
   File.writeTextFile( path, xml );
   ExternalProcess.startDetached( CoreApplication.filePath, [ "-y", path ] );
}

function f1BuildPhaseInstance( step, par )
{
   try
   {
      if ( step.kind == "spfc" )
         return f1BuildFlux( par );
      if ( step.kind == "spcc" )
         return f1BuildColor( par );
      if ( step.kind == "blurx" )
         return f1BuildBlurX( par );
      if ( step.kind == "noisex" )
         return f1BuildNoise( par );
      if ( step.kind == "starx" )
         return f1BuildStars( par );
      if ( step.kind == "histo" )
         return f1BuildHisto( par );
      if ( step.kind == "stretch" )
         return f1BuildStretch( par );
      if ( typeof f1BuildPostKind == "function" )
         return f1BuildPostKind( step, par );
   }
   catch ( e )
   {
      return null;
   }
   return null;
}

function f1PhaseRemainderPieces( name, startIndex )
{
   let steps = f1PhaseOrderedSteps( name );
   let pieces = [];
   let skipped = [];
   let begin = startIndex > 0 ? startIndex : 0;
   for ( let i = begin; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      if ( !state || !state.on || !f1PhaseStepInstalled( step ) )
         continue;
      let instance = f1BuildPhaseInstance( step, state.par );
      let source = "";
      if ( instance )
      {
         try { source = instance.toSource( "XPSM 1.0" ); } catch ( e ) { source = ""; }
         if ( source )
            source = source.replace( /^\s*<\?xml[^>]*>\s*/i, "" );
      }
      if ( !source )
      {
         skipped.push( f1StepTitle( step, state.par ) );
         continue;
      }
      pieces.push( source );
   }
   return { pieces: pieces, skipped: skipped };
}

function f1InstallPhasePieces( iconId, pack, y )
{
   if ( !pack.pieces.length )
   {
      console.warningln( "<end><cbr>** No remaining process could be saved for " + iconId + "." );
      if ( pack.skipped.length )
         console.warningln( "  not included: " + pack.skipped.join( ", " ) );
      return "";
   }
   f1InstallProcessIcon( iconId, pack.pieces, y );
   console.noteln( "<end><cbr>* Desktop icon: " + iconId );
   if ( pack.skipped.length )
      console.warningln( "  not included (not a normal process): " + pack.skipped.join( ", " ) );
   return iconId;
}

function f1OfferPhaseRemainder( info )
{
   let label = info.phase == "pre" ? "Pre" : "Post";
   if ( !f1Confirm( "Create the remaining " + label + " steps on the desktop as process icon? Run them after you complete "
                    + info.stepTitle + " by hand." ) )
      return;
   let pack = f1PhaseRemainderPieces( info.phase, info.stepIndex + 1 );
   let iconId = f1InstallPhasePieces( f1UniqueIconId( label + "_after_" + f1IconToken( info.stepTitle ) ), pack, 80 );
   if ( !iconId )
   {
      f1Message( "No remaining process could be placed on the desktop." );
      return;
   }
   f1Message( "Created " + iconId + ".\nApply it after you finish " + info.stepTitle + " by hand.", true );
}

function f1WriteRemainderIcon( failure, view, y )
{
   let steps = f1OrderedSteps( failure.slot );
   let pieces = [];
   let skipped = [];
   for ( let i = failure.stepIndex + 1; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1.steps[failure.slot][step.id];
      if ( !state || !state.on || !f1StepInstalled( step ) )
         continue;
      if ( !f1CanSaveAsProcess( step ) )
      {
         skipped.push( step.title );
         continue;
      }
      let instance = null;
      try
      {
         instance = f1Build( failure.slot, step, view );
      }
      catch ( e )
      {
         skipped.push( step.title );
         continue;
      }
      if ( !instance )
      {
         skipped.push( step.title );
         continue;
      }
      let source = "";
      try
      {
         source = instance.toSource( "XPSM 1.0" );
      }
      catch ( e )
      {
         source = "";
      }
      if ( source )
         source = source.replace( /^\s*<\?xml[^>]*>\s*/i, "" );
      if ( !source )
      {
         skipped.push( step.title );
         continue;
      }
      pieces.push( source );
   }
   if ( !pieces.length )
   {
      console.warningln( "<end><cbr>** No remaining process could be saved for " + failure.slot + "." );
      if ( skipped.length )
         console.warningln( "  not included: " + skipped.join( ", " ) );
      return "";
   }
   let iconId = f1UniqueIconId( failure.slot + "_after_" + f1IconToken( failure.stepTitle ) );
   f1InstallProcessIcon( iconId, pieces, y );
   console.noteln( "<end><cbr>* Desktop icon: " + iconId );
   console.writeln( "  Apply it to " + failure.slot + " after you complete "
                    + failure.stepTitle + " by hand." );
   if ( skipped.length )
      console.warningln( "  not included (not a normal process): " + skipped.join( ", " ) );
   return iconId;
}

function f1OfferRemainderIcons( failures, jobsBySlot )
{
   let lines = [];
   for ( let i = 0; i < failures.length; ++i )
      lines.push( failures[i].slot + ": run them after you complete "
                  + failures[i].stepTitle + " by hand." );
   let ask = failures.length == 1
      ? ( "Create the remaining " + failures[0].slot
          + " steps and the Post steps on the desktop as process icons? Run them after you complete "
          + failures[0].stepTitle + " by hand." )
      : ( "Create the remaining steps and the Post steps on the desktop as process icons?\n" + lines.join( "\n" ) );
   if ( !f1Confirm( ask ) )
      return;
   let created = [];
   for ( let i = 0; i < failures.length; ++i )
   {
      let job = jobsBySlot[failures[i].slot];
      if ( !job )
         continue;
      let iconId = f1WriteRemainderIcon( failures[i], job.view, 80 + i * 140 );
      if ( iconId )
         created.push( iconId );
   }
   let postId = f1InstallPhasePieces( f1UniqueIconId( "Post" ), f1PhaseRemainderPieces( "post", 0 ), 80 + failures.length * 140 );
   if ( postId )
      created.push( postId );
   if ( created.length )
   {
      let text = "Created " + created.join( ", " ) + ".";
      if ( postId && created.length > 1 )
         text += "\nApply the filter icon after you finish the failed step by hand, then apply the Post icon.";
      else if ( postId )
         text += "\nApply the Post icon after you finish the failed step by hand.";
      else
         text += "\nApply each icon to its image after you finish the failed step by hand.";
      f1Message( text, true );
   }
   else
      f1Message( "No remaining process could be placed on the desktop." );
}

// ----------------------------------------------------------------------------

var F1IconPickDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.windowTitle = "Process icon";
      this.iconName = "";
      this.userResizable = true;

      let icons = [];
      try
      {
         icons = ProcessInstance.icons();
      }
      catch ( e )
      {
         icons = [];
      }
      icons.sort( function( a, b ) { return a.toLowerCase().localeCompare( b.toLowerCase() ); } );

      let help = new Label( this );
      help.wordWrapping = true;
      help.text = "Choose a process icon from the PixInsight workspace. "
                + "Its parameters are copied into this script.";

      this.icon_Combo = new ComboBox( this );
      for ( let i = 0; i < icons.length; ++i )
         this.icon_Combo.addItem( icons[i] );
      this.icon_Combo.setScaledMinWidth( 320 );

      let empty = new Label( this );
      empty.wordWrapping = true;
      empty.text = icons.length ? "" : "No process icons are on the workspace.";

      let dialog = this;
      let ok = new PushButton( this );
      ok.text = "OK";
      ok.defaultButton = true;
      ok.enabled = icons.length > 0;
      ok.onClick = function()
      {
         if ( dialog.icon_Combo.numberOfItems <= 0 )
            return;
         dialog.iconName = dialog.icon_Combo.itemText( dialog.icon_Combo.currentItem );
         dialog.ok();
      };
      let cancel = new PushButton( this );
      cancel.text = "Cancel";
      cancel.onClick = function() { dialog.cancel(); };

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( ok );
      buttons.add( cancel );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( help );
      this.sizer.add( this.icon_Combo );
      if ( !icons.length )
         this.sizer.add( empty );
      this.sizer.add( buttons );
      this.setScaledMinWidth( 420 );
   }
};

// ----------------------------------------------------------------------------

var F1AstrometrySeedDialog = class extends Dialog
{
   constructor( metadata )
   {
      super();
      this.windowTitle = "ImageSolver — starting coordinates";
      this.userResizable = false;
      this.seed = null;
      this.metadata = metadata || {};
      let dialog = this;
      let labelWidth = this.font.width( "Right Ascension:" ) + 16;
      let spinWidth = this.font.width( "888888" );

      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "This image has no usable RA/Dec/scale seed for ImageSolver. "
                + "Enter coordinates (and scale if needed). Values confirmed here "
                + "are reused for other filters in this Process run.";

      let ra0 = ( this.metadata.ra != null && isFinite( this.metadata.ra ) ) ? this.metadata.ra : 0;
      let dec0 = ( this.metadata.dec != null && isFinite( this.metadata.dec ) ) ? this.metadata.dec : 0;
      this.coords_Editor = new CoordinatesEditor( this, new Point( ra0, dec0 ), labelWidth, spinWidth,
         "Approximate image center. Must lie inside the field." );

      this.search_Button = new PushButton( this );
      this.search_Button.text = "Search";
      this.search_Button.icon = this.scaledResource( ":/icons/find.png" );
      this.search_Button.onClick = function()
      {
         let search = new SearchCoordinatesDialog( null, true, false );
         search.windowTitle = "Online Coordinate Search";
         if ( search.execute() )
         {
            let object = search.object;
            if ( object )
               dialog.coords_Editor.SetCoords( object.posEq );
         }
      };

      this.coords_Sizer = new HorizontalSizer;
      this.coords_Sizer.spacing = 8;
      this.coords_Sizer.add( this.coords_Editor );
      this.coords_Sizer.addStretch();
      this.coords_Sizer.add( this.search_Button );

      this.scale_Edit = new NumericEdit( this );
      this.scale_Edit.label.text = "Scale:";
      this.scale_Edit.label.setFixedWidth( labelWidth );
      this.scale_Edit.setReal( true );
      this.scale_Edit.setPrecision( 3 );
      this.scale_Edit.setRange( 0.001, 1800 );
      this.scale_Edit.enableFixedPrecision( true );
      this.scale_Edit.toolTip = "<p>Image scale in arcseconds per pixel. Prefills from FITS when available.</p>";
      let scaleAsp = ( this.metadata.resolution != null && isFinite( this.metadata.resolution ) && this.metadata.resolution > 0 )
                     ? this.metadata.resolution * 3600 : 0;
      this.scale_Edit.setValue( scaleAsp );

      this.scale_Unit = new Label( this );
      this.scale_Unit.text = "\"/px";
      this.scale_Unit.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

      this.scale_Sizer = new HorizontalSizer;
      this.scale_Sizer.spacing = 4;
      this.scale_Sizer.add( this.scale_Edit );
      this.scale_Sizer.add( this.scale_Unit );
      this.scale_Sizer.addStretch();

      this.focal_Edit = new NumericEdit( this );
      this.focal_Edit.label.text = "Focal length:";
      this.focal_Edit.label.setFixedWidth( labelWidth );
      this.focal_Edit.setReal( true );
      this.focal_Edit.setPrecision( 2 );
      this.focal_Edit.setRange( 0, 1e6 );
      this.focal_Edit.enableFixedPrecision( true );
      this.focal_Edit.toolTip = "<p>Optional focal length in mm (used with pixel size from FITS when scale is empty).</p>";
      this.focal_Edit.setValue( ( this.metadata.focal != null && isFinite( this.metadata.focal ) ) ? this.metadata.focal : 0 );

      this.focal_Unit = new Label( this );
      this.focal_Unit.text = "mm";
      this.focal_Unit.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

      this.focal_Sizer = new HorizontalSizer;
      this.focal_Sizer.spacing = 4;
      this.focal_Sizer.add( this.focal_Edit );
      this.focal_Sizer.add( this.focal_Unit );
      this.focal_Sizer.addStretch();

      let okButton = new PushButton( this );
      okButton.text = "OK";
      okButton.defaultButton = true;
      okButton.onClick = function()
      {
         if ( dialog.readBack() )
            dialog.ok();
      };
      let cancelButton = new PushButton( this );
      cancelButton.text = "Cancel";
      cancelButton.onClick = function()
      {
         dialog.cancel();
      };
      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( okButton );
      buttons.add( cancelButton );

      let body = new VerticalSizer;
      body.margin = 8;
      body.spacing = 8;
      body.add( note );
      body.add( this.coords_Sizer );
      body.add( this.scale_Sizer );
      body.add( this.focal_Sizer );
      body.addSpacing( 4 );
      body.add( buttons );
      this.sizer = body;
      this.setScaledMinWidth( 520 );
   }

   readBack()
   {
      let coords = this.coords_Editor.GetCoords( false );
      if ( !coords || !isFinite( coords.x ) || !isFinite( coords.y )
           || coords.x < 0 || coords.x > 360 || coords.y < -90 || coords.y > 90 )
      {
         f1Message( "Enter a valid right ascension and declination." );
         return false;
      }
      let scaleAsp = this.scale_Edit.value;
      let focal = this.focal_Edit.value;
      let resolution = null;
      if ( isFinite( scaleAsp ) && scaleAsp > 0 )
         resolution = scaleAsp / 3600;
      else if ( isFinite( focal ) && focal > 0
                && this.metadata.xpixsz != null && isFinite( this.metadata.xpixsz ) && this.metadata.xpixsz > 0 )
         resolution = this.metadata.xpixsz / focal * 0.18 / Math.PI;
      if ( resolution == null || !( resolution > 0 ) || resolution > 1800 / 3600 )
      {
         f1Message( "Enter image scale in \"/px (or a valid focal length when pixel size is in the FITS header)." );
         return false;
      }
      this.seed = {
         ra: coords.x,
         dec: coords.y,
         resolution: resolution,
         focal: ( isFinite( focal ) && focal > 0 ) ? focal : null,
         xpixsz: ( this.metadata.xpixsz != null && isFinite( this.metadata.xpixsz ) && this.metadata.xpixsz > 0 )
                 ? this.metadata.xpixsz : null
      };
      return true;
   }
};

var FazaSetupDialog = class extends Dialog
{
   constructor( slot, step, par )
   {
      super();
      this.slot = slot;
      this.step = step;
      this.par = par;
      this.windowTitle = slot + "  " + step.title;
      this.userResizable = true;
      let dialog = this;
      let body = new VerticalSizer;
      body.spacing = 6;
      body.margin = 8;
      this.channel_Edit = null;
      if ( this.wantsChannelField() )
         this.buildChannel( body );

      if ( step.kind == "spikeless" )
         this.buildSpikeLess( body );
      else if ( step.kind == "blurx" )
         this.buildBlurX( body );
      else if ( step.kind == "blurless" )
         this.buildBlurless( body );
      else if ( step.kind == "graxpert" )
         this.buildGraXpert( body );
      else if ( step.kind == "blindsolver" )
         this.buildBlindSolver( body );
      else if ( step.kind == "spfc" )
         this.buildFlux( body );
      else if ( step.kind == "mgc" )
         this.buildGradient( body );
      else if ( step.kind == "spcc" )
         this.buildColor( body );
      else if ( step.kind == "noisex" )
         this.buildNoise( body );
      else if ( step.kind == "starx" )
         this.buildStars( body );
      else if ( step.kind == "starxmono" )
      {
      }
      else if ( step.kind == "autolinear" )
         this.buildAutoLinear( body );
      else if ( step.kind == "histo" )
         this.buildHisto( body );
      else if ( step.kind == "pm" )
         this.buildPixelMath( body );
      else if ( step.kind == "screen" )
         this.buildScreen( body );
      else if ( step.kind == "stretch" )
         this.buildStretch( body );
      else if ( step.kind == "nbtorgb" )
         this.buildNBtoRGB( body );
      else if ( step.kind == "shocombine" || step.kind == "sholrgb" )
         this.buildSHOCombine( body );
      else if ( step.kind == "lhe" )
         this.buildLHE( body );
      else if ( step.kind == "curves" )
         this.buildCurves( body );
      else if ( step.kind == "rotate" )
         this.buildRotation( body );
      else if ( step.kind == "resample" )
         this.buildResample( body );
      else if ( step.kind == "rename" )
         this.buildRename( body );
      else if ( step.kind == "invert" )
         this.buildInvert( body );
      else if ( step.kind == "scnr" )
         this.buildSCNR( body );
      else if ( step.kind == "icon" )
         this.buildIcon( body );
      else if ( step.kind == "autoassign" )
         this.buildAutoAssign( body );
      else if ( step.kind == "composergb" )
         this.buildComposeRGB( body );
      else if ( step.kind == "composesho" )
         this.buildComposeSHO( body );
      else if ( step.kind == "hdrmt" )
         this.buildHDRMT( body );
      else if ( step.kind == "lrgbcomb" )
         this.buildLRGBComb( body );
      else if ( step.kind == "starstretch" )
         this.buildStarStretch( body );
      else if ( step.kind == "histo" )
         this.buildHisto( body );
      else if ( step.kind == "putstars" )
         this.buildPutStars( body );

      let okButton = new PushButton( this );
      okButton.text = "OK";
      okButton.defaultButton = true;
      okButton.onClick = function()
      {
         if ( dialog.readBack() )
            dialog.ok();
      };
      let cancelButton = new PushButton( this );
      cancelButton.text = "Cancel";
      cancelButton.onClick = function()
      {
         dialog.cancel();
      };
      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( okButton );
      buttons.add( cancelButton );
      body.addSpacing( 8 );
      body.add( buttons );
      this.sizer = body;
      this.setScaledMinWidth( 560 );
   }

   label( text, width )
   {
      let item = new Label( this );
      item.text = text;
      item.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      item.setScaledFixedWidth( width || 230 );
      return item;
   }

   edit( value, digits )
   {
      let item = new Edit( this );
      item.text = f1Format( value, digits );
      item.setScaledFixedWidth( 90 );
      return item;
   }

   channelEdit( value )
   {
      let item = new Edit( this );
      item.text = value == null ? "" : String( value );
      item.setScaledMinWidth( 160 );
      item.setScaledFixedWidth( 180 );
      return item;
   }

   readChannel( edit, fallback )
   {
      let text = edit && edit.text != null ? String( edit.text ).replace( /^\s+|\s+$/g, "" ) : "";
      return text || fallback || "";
   }

   row( caption, control )
   {
      let line = new HorizontalSizer;
      line.spacing = 6;
      line.add( this.label( caption ) );
      line.add( control );
      line.addStretch();
      let box = new Control( this );
      box.sizer = line;
      return box;
   }

   addChannelIO( body, fields )
   {
      if ( fields.input != null )
      {
         this.in_Edit = this.channelEdit( fields.input );
         body.add( this.row( "Input view", this.in_Edit ) );
      }
      if ( fields.inputL != null )
      {
         this.inL_Edit = this.channelEdit( fields.inputL );
         body.add( this.row( "Input L", this.inL_Edit ) );
      }
      if ( fields.inputRGB != null )
      {
         this.inRGB_Edit = this.channelEdit( fields.inputRGB );
         body.add( this.row( "Input RGB", this.inRGB_Edit ) );
      }
      if ( fields.inputStars != null )
      {
         this.inStars_Edit = this.channelEdit( fields.inputStars );
         body.add( this.row( "Input stars", this.inStars_Edit ) );
      }
      if ( fields.inputTarget != null )
      {
         this.inTarget_Edit = this.channelEdit( fields.inputTarget );
         body.add( this.row( "Input target", this.inTarget_Edit ) );
      }
      if ( fields.output != null )
      {
         this.out_Edit = this.channelEdit( fields.output );
         body.add( this.row( "Output view", this.out_Edit ) );
      }
   }

   namesFor( channel, selected )
   {
      let items = f1.db[channel] ? f1.db[channel].slice( 0 ) : [];
      if ( selected && items.indexOf( selected ) < 0 )
         items.unshift( selected );
      if ( items.length == 0 && selected )
         items.push( selected );
      return items;
   }

   combo( channel, selected )
   {
      let box = new ComboBox( this );
      let items = this.namesFor( channel, selected );
      for ( let i = 0; i < items.length; ++i )
         box.addItem( items[i] );
      let index = 0;
      for ( let i = 0; i < items.length; ++i )
         if ( items[i] == selected )
            index = i;
      if ( box.numberOfItems > 0 )
         box.currentItem = index;
      box.setScaledMinWidth( 280 );
      return box;
   }

   listCombo( items, selected, width )
   {
      let box = new ComboBox( this );
      let list = items.slice( 0 );
      if ( selected && list.indexOf( selected ) < 0 )
         list.unshift( selected );
      for ( let i = 0; i < list.length; ++i )
         box.addItem( list[i] );
      let index = 0;
      for ( let i = 0; i < list.length; ++i )
         if ( list[i] == selected )
            index = i;
      if ( box.numberOfItems > 0 )
         box.currentItem = index;
      box.setScaledMinWidth( width || 220 );
      return box;
   }

   chosen( box )
   {
      if ( !box || box.numberOfItems < 1 || box.currentItem < 0 )
         return "";
      return box.itemText( box.currentItem );
   }

   buildIcon( body )
   {
      let dialog = this;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Parameters were copied from a process icon. "
                + "They are stored in this script. Changing or deleting the icon later does not change this step.";
      body.add( note );
      this.process_Label = new Label( this );
      this.process_Label.text = this.par.processId || "";
      body.add( this.row( "Process", this.process_Label ) );
      this.icon_Label = new Label( this );
      this.icon_Label.text = this.par.iconName || "";
      body.add( this.row( "Copied from icon", this.icon_Label ) );

      let replace = new PushButton( this );
      replace.text = "Replace from process icon";
      replace.onClick = function()
      {
         let pick = new F1IconPickDialog();
         if ( !pick.execute() || !pick.iconName )
            return;
         try
         {
            let snap = f1SnapshotFromIcon( pick.iconName );
            dialog.par.processId = snap.processId;
            dialog.par.iconName = snap.iconName;
            dialog.par.source = snap.source;
            dialog.par.title = snap.title;
            dialog.process_Label.text = snap.processId;
            dialog.icon_Label.text = snap.iconName;
            dialog.step.title = snap.title;
            dialog.step.processId = snap.processId;
            dialog.windowTitle = dialog.slot + "  " + snap.title;
         }
         catch ( e )
         {
            f1Message( e.message ? e.message : e.toString() );
         }
      };
      body.add( replace );
   }

   creditNote( body )
   {
      let credit = f1AuthorCredit( this.step.kind );
      if ( !credit )
         return;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = f1OriginalName( this.step ) + " — " + credit;
      if ( this.step.kind == "starstretch" || this.step.kind == "nbtorgb" )
         note.text += " (www.setiastro.com)";
      note.text += ".";
      body.add( note );
   }

   buildSpikeLess( body )
   {
      this.creditNote( body );
      this.model_Combo = this.listCombo( [ "SpikeLessAI v2", "SpikeLessAI v1" ], this.par.model );
      this.mode_Combo = this.listCombo( [ "Linear", "Stretched" ], this.par.mode );
      this.strength_Edit = this.edit( this.par.strength, 2 );
      this.stride_Edit = this.edit( this.par.stride, 0 );
      this.starLayer_Combo = this.listCombo( [ "None", "Auto" ], this.par.starLayer );
      this.spikeImage_Check = new CheckBox( this );
      this.spikeImage_Check.text = "Generate spike image";
      this.spikeImage_Check.checked = this.par.generateSpikeImage ? true : false;
      this.tails_Check = new CheckBox( this );
      this.tails_Check.text = "Clean long spike tails";
      this.tails_Check.checked = this.par.cleanLongTails ? true : false;
      body.add( this.row( "Model", this.model_Combo ) );
      body.add( this.row( "Mode", this.mode_Combo ) );
      body.add( this.row( "Strength", this.strength_Edit ) );
      body.add( this.row( "Tile stride", this.stride_Edit ) );
      body.add( this.row( "Star layer", this.starLayer_Combo ) );
      body.add( this.spikeImage_Check );
      body.add( this.tails_Check );
   }

   buildBlurX( body )
   {
      this.creditNote( body );
      this.correct_Check = new CheckBox( this );
      this.correct_Check.text = "Correct Only";
      this.correct_Check.checked = this.par.correctOnly ? true : false;
      this.stars_Edit = this.edit( this.par.sharpenStars, 2 );
      this.halos_Edit = this.edit( this.par.starHalos, 2 );
      this.nonstellar_Edit = this.edit( this.par.sharpenNonstellar, 2 );
      this.overlap_Edit = this.edit( this.par.overlap, 2 );
      let dialog = this;
      let apply = function()
      {
         let on = dialog.correct_Check.checked;
         dialog.stars_Edit.enabled = !on;
         dialog.halos_Edit.enabled = !on;
         dialog.nonstellar_Edit.enabled = !on;
      };
      this.correct_Check.onCheck = apply;
      apply();
      body.add( this.correct_Check );
      body.add( this.row( "Sharpen Stars", this.stars_Edit ) );
      body.add( this.row( "Adjust Star Halos", this.halos_Edit ) );
      body.add( this.row( "Sharpen Nonstellar", this.nonstellar_Edit ) );
      body.add( this.row( "Overlap", this.overlap_Edit ) );
   }

   buildBlurless( body )
   {
      this.creditNote( body );
      this.amount_Edit = this.edit( this.par.amount, 2 );
      this.cores_Combo = this.listCombo( [ "Clip", "Keep", "Rescale" ], this.par.coresAbove );
      this.colourLabels = [ "Each channel", "Luminance" ];
      this.colourValues = [ "Channels", "Luminance" ];
      this.colour_Combo = this.listCombo( this.colourLabels,
                                         this.par.colourMode == "Luminance" ? "Luminance" : "Each channel" );
      this.align_Check = new CheckBox( this );
      this.align_Check.text = "Align channels";
      this.align_Check.checked = this.par.alignChannels ? true : false;
      this.crisper_Check = new CheckBox( this );
      this.crisper_Check.text = "Crisper spikes";
      this.crisper_Check.checked = this.par.crisperSpikes ? true : false;
      body.add( this.row( "Amount", this.amount_Edit ) );
      body.add( this.row( "Cores above 1.0", this.cores_Combo ) );
      body.add( this.row( "Color", this.colour_Combo ) );
      body.add( this.align_Check );
      body.add( this.crisper_Check );
   }

   buildBlindSolver( body )
   {
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "BlindSolver uses its own saved preferences (Scripts > Astrometry > BlindSolver) "
                + "for field/scale limits. Optionally override the time limit below.";
      this.timeLimit_Edit = this.edit( this.par.timeLimit != null ? this.par.timeLimit : 120, 0 );
      body.add( note );
      body.add( this.row( "Time limit (seconds)", this.timeLimit_Edit ) );
   }

   buildGraXpert( body )
   {
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "GraXpert — Jürgen Terpe, The GraXpert Team. "
                + "Runs the external GraXpert app (path from Script > Toolbox > GraXpert). "
                + "The working image is replaced. Background preview windows are not opened in batch.";
      this.correction_Combo = this.listCombo( [ "Subtraction", "Division" ],
         this.par.correction == 1 ? "Division" : "Subtraction" );
      this.smoothing_Edit = this.edit( this.par.smoothing != null ? this.par.smoothing : 0, 3 );
      body.add( note );
      body.add( this.row( "Correction", this.correction_Combo ) );
      body.add( this.row( "Smoothing", this.smoothing_Edit ) );
   }

   buildFlux( body )
   {
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = this.par.narrowband ? true : false;
      this.wave_Edit = this.edit( this.par.wavelength, 1 );
      this.band_Edit = this.edit( this.par.bandwidth, 1 );
      this.sensor_Combo = this.combo( "Q", this.par.sensorName );
      this.gray_Combo = null;
      this.red_Combo = null;
      this.green_Combo = null;
      this.blue_Combo = null;
      this.waveRow = this.row( "Wavelength", this.wave_Edit );
      this.bandRow = this.row( "Bandwidth", this.band_Edit );
      this.filterRows = [];
      if ( f1ColorSlot( this.slot ) )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else if ( this.slot == "R" )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
      }
      else if ( this.slot == "G" )
      {
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
      }
      else if ( this.slot == "B" )
      {
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else
      {
         this.gray_Combo = this.combo( f1GrayChannel( this.slot ), this.par.grayName );
         this.filterRows.push( this.row( "Gray filter", this.gray_Combo ) );
      }
      let dialog = this;
      let apply = function( resize )
      {
         let on = dialog.narrow_Check.checked;
         if ( on )
         {
            dialog.waveRow.show();
            dialog.bandRow.show();
         }
         else
         {
            dialog.waveRow.hide();
            dialog.bandRow.hide();
         }
         for ( let i = 0; i < dialog.filterRows.length; ++i )
         {
            if ( on )
               dialog.filterRows[i].hide();
            else
               dialog.filterRows[i].show();
         }
         if ( resize )
            dialog.adjustToContents();
      };
      this.narrow_Check.onCheck = function()
      {
         apply( true );
      };
      body.add( this.narrow_Check );
      body.add( this.waveRow );
      body.add( this.bandRow );
      for ( let i = 0; i < this.filterRows.length; ++i )
         body.add( this.filterRows[i] );
      body.add( this.row( "QE curve", this.sensor_Combo ) );
      apply( false );
   }

   buildGradient( body )
   {
      this.scale_Edit = this.edit( this.par.scale, 0 );
      this.separation_Edit = this.edit( this.par.separation, 0 );
      this.smooth_Edit = this.edit( this.par.smoothness, 2 );
      this.mars_Combo = new ComboBox( this );
      let mars = [ "Ha", "OIII", "SII", "L", "R", "G", "B" ];
      if ( mars.indexOf( this.par.grayFilter ) < 0 )
         mars.unshift( this.par.grayFilter );
      for ( let i = 0; i < mars.length; ++i )
         this.mars_Combo.addItem( mars[i] );
      let index = 0;
      for ( let i = 0; i < mars.length; ++i )
         if ( mars[i] == this.par.grayFilter )
            index = i;
      this.mars_Combo.currentItem = index;
      this.show_Check = new CheckBox( this );
      this.show_Check.text = "Show gradient model";
      this.show_Check.checked = this.par.showModel ? true : false;
      body.add( this.row( "Gradient scale", this.scale_Edit ) );
      body.add( this.row( "Structure separation", this.separation_Edit ) );
      body.add( this.row( "Model smoothness", this.smooth_Edit ) );
      body.add( this.row( "Gray filter", this.mars_Combo ) );
      if ( f1ColorSlot( this.slot ) )
      {
         let note = new Label( this );
         note.wordWrapping = true;
         note.text = "Red, Green and Blue use the Red filter, Green filter and Blue filter. Gray filter above is the gray reference.";
         body.add( note );
      }
      body.add( this.show_Check );
      this.buildMarsFiles( body );
   }

   buildMarsFiles( body )
   {
      let dialog = this;
      this.marsFiles = f1MarsFiles().slice( 0 );

      let title = new Label( this );
      title.text = "MARS database files";
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Shared by every filter.";

      this.mars_Tree = new TreeBox( this );
      this.mars_Tree.numberOfColumns = 1;
      this.mars_Tree.headerVisible = false;
      this.mars_Tree.rootDecoration = false;
      this.mars_Tree.multipleSelection = true;
      this.mars_Tree.setScaledMinHeight( 90 );

      let fill = function()
      {
         dialog.mars_Tree.clear();
         for ( let i = 0; i < dialog.marsFiles.length; ++i )
         {
            let node = new TreeBoxNode( dialog.mars_Tree );
            node.setText( 0, dialog.marsFiles[i] );
            if ( !File.exists( dialog.marsFiles[i] ) )
               node.setToolTip( 0, "File not found." );
         }
      };
      fill();

      let add = new PushButton( this );
      add.text = "Add";
      add.onClick = function()
      {
         let fd = new OpenFileDialog;
         fd.caption = "MARS database files";
         fd.multipleSelections = true;
         fd.filters = [ [ "MARS database files", "*.xmars" ], [ "All files", "*" ] ];
         if ( fd.execute() )
         {
            for ( let i = 0; i < fd.filePaths.length; ++i )
               if ( dialog.marsFiles.indexOf( fd.filePaths[i] ) < 0 )
                  dialog.marsFiles.push( fd.filePaths[i] );
            fill();
         }
      };

      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.onClick = function()
      {
         let keep = [];
         for ( let i = 0; i < dialog.mars_Tree.numberOfChildren; ++i )
            if ( !dialog.mars_Tree.child( i ).selected )
               keep.push( dialog.marsFiles[i] );
         dialog.marsFiles = keep;
         fill();
      };

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( add );
      buttons.add( remove );

      body.addSpacing( 6 );
      body.add( title );
      body.add( note );
      body.add( this.mars_Tree, 100 );
      body.add( buttons );
   }

   buildColor( body )
   {
      let par = this.par;
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = par.narrowband ? true : false;
      this.optimize_Check = new CheckBox( this );
      this.optimize_Check.text = "Optimize for stars";
      this.optimize_Check.checked = par.optimizeStars ? true : false;
      this.redWave_Edit = this.edit( par.redWavelength != null ? par.redWavelength : 656.3, 2 );
      this.redBand_Edit = this.edit( par.redBandwidth != null ? par.redBandwidth : 6.0, 2 );
      this.greenWave_Edit = this.edit( par.greenWavelength != null ? par.greenWavelength : 500.7, 2 );
      this.greenBand_Edit = this.edit( par.greenBandwidth != null ? par.greenBandwidth : 6.0, 2 );
      this.blueWave_Edit = this.edit( par.blueWavelength != null ? par.blueWavelength : 500.7, 2 );
      this.blueBand_Edit = this.edit( par.blueBandwidth != null ? par.blueBandwidth : 6.0, 2 );
      this.red_Combo = this.combo( "R", par.redName );
      this.green_Combo = this.combo( "G", par.greenName );
      this.blue_Combo = this.combo( "B", par.blueName );
      this.sensor_Combo = this.combo( "Q", par.sensorName );
      let dialog = this;
      let apply = function()
      {
         let narrow = dialog.narrow_Check.checked;
         dialog.optimize_Check.enabled = narrow;
         dialog.redWave_Edit.enabled = narrow;
         dialog.redBand_Edit.enabled = narrow;
         dialog.greenWave_Edit.enabled = narrow;
         dialog.greenBand_Edit.enabled = narrow;
         dialog.blueWave_Edit.enabled = narrow;
         dialog.blueBand_Edit.enabled = narrow;
         dialog.red_Combo.enabled = !narrow;
         dialog.green_Combo.enabled = !narrow;
         dialog.blue_Combo.enabled = !narrow;
      };
      this.narrow_Check.onCheck = apply;
      apply();
      body.add( this.narrow_Check );
      body.add( this.optimize_Check );
      body.add( this.row( "Red wavelength", this.redWave_Edit ) );
      body.add( this.row( "Red bandwidth", this.redBand_Edit ) );
      body.add( this.row( "Green wavelength", this.greenWave_Edit ) );
      body.add( this.row( "Green bandwidth", this.greenBand_Edit ) );
      body.add( this.row( "Blue wavelength", this.blueWave_Edit ) );
      body.add( this.row( "Blue bandwidth", this.blueBand_Edit ) );
      body.add( this.row( "Red filter", this.red_Combo ) );
      body.add( this.row( "Green filter", this.green_Combo ) );
      body.add( this.row( "Blue filter", this.blue_Combo ) );
      body.add( this.row( "Camera", this.sensor_Combo ) );
   }

   buildNoise( body )
   {
      this.creditNote( body );
      this.denoise_Edit = this.edit( this.par.denoise, 2 );
      this.detail_Edit = this.edit( this.par.detail, 2 );
      body.add( this.row( "Denoise", this.denoise_Edit ) );
      body.add( this.row( "Detail", this.detail_Edit ) );
   }

   buildStars( body )
   {
      this.creditNote( body );
      this.stars_Check = new CheckBox( this );
      this.stars_Check.text = "Star image";
      this.stars_Check.checked = this.par.outputStars ? true : false;
      this.stars_Check.toolTip = "<p>When checked, a stars window stays open as well. Otherwise the image stays starless.</p>";
      this.unscreen_Check = new CheckBox( this );
      this.unscreen_Check.text = "Unscreen";
      this.unscreen_Check.checked = this.par.unscreen ? true : false;
      let dialog = this;
      let apply = function()
      {
         dialog.unscreen_Check.enabled = dialog.stars_Check.checked;
      };
      this.stars_Check.onCheck = apply;
      apply();
      body.add( this.stars_Check );
      body.add( this.unscreen_Check );
   }

   buildScreen( body )
   {
      this.linked_Check = new CheckBox( this );
      this.linked_Check.text = "Link RGB Channels";
      this.linked_Check.checked = this.par.linked ? true : false;
      this.shadows_Edit = this.edit( this.par.shadows, 1 );
      this.target_Edit = this.edit( this.par.target, 2 );
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Only the display changes. Pixels stay linear.";
      body.add( note );
      body.add( this.linked_Check );
      body.add( this.row( "Shadows clipping", this.shadows_Edit ) );
      body.add( this.row( "Target background", this.target_Edit ) );
   }

   buildStretch( body )
   {
      if ( this.par && this.par.input != null )
         this.addChannelIO( body, {
            input: this.par.input,
            output: this.par.output || this.par.input
         } );
      this.target_Edit = this.edit( this.par.targetBackground, 2 );
      this.aggressive_Edit = this.edit( this.par.aggressiveness, 2 );
      this.range_Edit = this.edit( this.par.dynamicRange, 2 );
      this.recovery_Check = new CheckBox( this );
      this.recovery_Check.text = "Contrast Recovery";
      this.recovery_Check.checked = this.par.contrastRecovery ? true : false;
      this.separation_Edit = this.edit( this.par.scaleSeparation, 0 );
      this.intensity_Edit = this.edit( this.par.intensity, 2 );
      this.saturation_Check = new CheckBox( this );
      this.saturation_Check.text = "Color Saturation";
      this.saturation_Check.checked = this.par.saturation ? true : false;
      this.amount_Edit = this.edit( this.par.saturationAmount, 2 );
      this.boost_Edit = this.edit( this.par.saturationBoost, 2 );
      let dialog = this;
      let apply = function()
      {
         let recovery = dialog.recovery_Check.checked;
         dialog.separation_Edit.enabled = recovery;
         dialog.intensity_Edit.enabled = recovery;
         let color = dialog.saturation_Check.checked;
         dialog.amount_Edit.enabled = color;
         dialog.boost_Edit.enabled = color;
      };
      this.recovery_Check.onCheck = apply;
      this.saturation_Check.onCheck = apply;
      apply();
      body.add( this.row( "Target background", this.target_Edit ) );
      body.add( this.row( "Aggressiveness", this.aggressive_Edit ) );
      body.add( this.row( "Dynamic range compression", this.range_Edit ) );
      body.add( this.recovery_Check );
      body.add( this.row( "Scale separation", this.separation_Edit ) );
      body.add( this.row( "Intensity", this.intensity_Edit ) );
      body.add( this.saturation_Check );
      body.add( this.row( "Amount", this.amount_Edit ) );
      body.add( this.row( "Boost", this.boost_Edit ) );
   }

   needNumber( edit, label, allowNegative )
   {
      let value = f1Parse( edit.text );
      if ( value == null || ( !allowNegative && !( value > 0 ) ) || ( allowNegative && !isFinite( value ) ) )
      {
         f1Message( label + " is not a number." );
         return null;
      }
      return value;
   }

   wantsChannelField()
   {
      if ( !f1ShowsOneTarget( this.step.kind ) )
         return false;
      let own = {
         autolinear: true, invert: true, scnr: true, lhe: true, curves: true,
         rotate: true, resample: true, rename: true, hdrmt: true, starstretch: true,
         putstars: true
      };
      if ( own[this.step.kind] )
         return false;
      if ( ( this.step.kind == "stretch" || this.step.kind == "histo" ) && this.par && this.par.input )
         return false;
      return true;
   }

   buildChannel( body )
   {
      this.channel_Edit = new Edit( this );
      this.channel_Edit.text = this.par && this.par.channel != null ? String( this.par.channel ) : "";
      this.channel_Edit.toolTip = "<p>The view this step applies to. Example: Ha</p>";
      body.add( this.row( "Channel", this.channel_Edit ) );
   }

   readBack()
   {
      let par = this.par;
      if ( this.channel_Edit )
         par.channel = String( this.channel_Edit.text || "" ).replace( /^\s+|\s+$/g, "" );
      if ( this.step.kind == "spikeless" )
      {
         let strength = this.needNumber( this.strength_Edit, "Strength", true );
         let stride = this.needNumber( this.stride_Edit, "Tile stride", false );
         if ( strength == null || stride == null || strength < 0 || strength > 1 )
         {
            if ( strength != null && ( strength < 0 || strength > 1 ) )
               f1Message( "Strength must be between 0 and 1." );
            return false;
         }
         par.model = this.chosen( this.model_Combo );
         par.mode = this.chosen( this.mode_Combo );
         par.strength = strength;
         par.stride = stride;
         par.starLayer = this.chosen( this.starLayer_Combo );
         par.generateSpikeImage = this.spikeImage_Check.checked;
         par.cleanLongTails = this.tails_Check.checked;
         return true;
      }
      if ( this.step.kind == "blurx" )
      {
         let overlap = this.needNumber( this.overlap_Edit, "Overlap", false );
         let stars = this.needNumber( this.stars_Edit, "Sharpen Stars", true );
         let halos = this.needNumber( this.halos_Edit, "Adjust Star Halos", true );
         let nonstellar = this.needNumber( this.nonstellar_Edit, "Sharpen Nonstellar", true );
         if ( overlap == null || stars == null || halos == null || nonstellar == null )
            return false;
         par.correctOnly = this.correct_Check.checked;
         par.overlap = overlap;
         par.sharpenStars = stars;
         par.starHalos = halos;
         par.sharpenNonstellar = nonstellar;
         return true;
      }
      if ( this.step.kind == "icon" )
         return true;
      if ( this.step.kind == "blurless" )
      {
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         if ( amount == null || amount < 0 || amount > 1 )
         {
            if ( amount != null )
               f1Message( "Amount must be between 0 and 1." );
            return false;
         }
         par.amount = amount;
         par.coresAbove = this.chosen( this.cores_Combo );
         let colourIndex = this.colour_Combo.currentItem;
         if ( colourIndex < 0 )
            colourIndex = 0;
         par.colourMode = this.colourValues[colourIndex];
         par.alignChannels = this.align_Check.checked;
         par.crisperSpikes = this.crisper_Check.checked;
         return true;
      }
      if ( this.step.kind == "blindsolver" )
      {
         let timeLimit = this.needNumber( this.timeLimit_Edit, "Time limit", false );
         if ( timeLimit == null || timeLimit < 1 || timeLimit > 3600 )
         {
            if ( timeLimit != null )
               f1Message( "Time limit must be between 1 and 3600 seconds." );
            return false;
         }
         par.timeLimit = timeLimit;
         return true;
      }
      if ( this.step.kind == "graxpert" )
      {
         let smoothing = this.needNumber( this.smoothing_Edit, "Smoothing", true );
         if ( smoothing == null || smoothing < 0 || smoothing > 1 )
         {
            if ( smoothing != null )
               f1Message( "Smoothing must be between 0 and 1." );
            return false;
         }
         par.correction = this.chosen( this.correction_Combo ) == "Division" ? 1 : 0;
         par.smoothing = smoothing;
         return true;
      }
      if ( this.step.kind == "spfc" )
      {
         let wave = this.needNumber( this.wave_Edit, "Wavelength", false );
         let band = this.needNumber( this.band_Edit, "Bandwidth", false );
         if ( wave == null || band == null )
            return false;
         par.narrowband = this.narrow_Check.checked;
         par.wavelength = wave;
         par.bandwidth = band;
         if ( this.gray_Combo )
            par.grayName = this.chosen( this.gray_Combo );
         if ( this.red_Combo )
            par.redName = this.chosen( this.red_Combo );
         if ( this.green_Combo )
            par.greenName = this.chosen( this.green_Combo );
         if ( this.blue_Combo )
            par.blueName = this.chosen( this.blue_Combo );
         if ( this.slot == "R" && this.red_Combo )
            par.grayName = par.redName;
         else if ( this.slot == "G" && this.green_Combo )
            par.grayName = par.greenName;
         else if ( this.slot == "B" && this.blue_Combo )
            par.grayName = par.blueName;
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "mgc" )
      {
         let scale = this.needNumber( this.scale_Edit, "Gradient scale", false );
         let separation = this.needNumber( this.separation_Edit, "Structure separation", false );
         let smoothness = this.needNumber( this.smooth_Edit, "Model smoothness", false );
         if ( scale == null || separation == null || smoothness == null )
            return false;
         par.scale = scale;
         par.separation = separation;
         par.smoothness = smoothness;
         par.grayFilter = this.chosen( this.mars_Combo );
         par.showModel = this.show_Check.checked;
         f1WriteMarsFiles( this.marsFiles );
         return true;
      }
      if ( this.step.kind == "spcc" )
      {
         let redWave = this.needNumber( this.redWave_Edit, "Red wavelength", false );
         let redBand = this.needNumber( this.redBand_Edit, "Red bandwidth", false );
         let greenWave = this.needNumber( this.greenWave_Edit, "Green wavelength", false );
         let greenBand = this.needNumber( this.greenBand_Edit, "Green bandwidth", false );
         let blueWave = this.needNumber( this.blueWave_Edit, "Blue wavelength", false );
         let blueBand = this.needNumber( this.blueBand_Edit, "Blue bandwidth", false );
         if ( redWave == null || redBand == null || greenWave == null || greenBand == null
              || blueWave == null || blueBand == null )
            return false;
         par.narrowband = this.narrow_Check.checked;
         par.optimizeStars = this.optimize_Check.checked;
         par.redWavelength = redWave;
         par.redBandwidth = redBand;
         par.greenWavelength = greenWave;
         par.greenBandwidth = greenBand;
         par.blueWavelength = blueWave;
         par.blueBandwidth = blueBand;
         par.redName = this.chosen( this.red_Combo );
         par.greenName = this.chosen( this.green_Combo );
         par.blueName = this.chosen( this.blue_Combo );
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "noisex" )
      {
         let denoise = this.needNumber( this.denoise_Edit, "Denoise", true );
         let detail = this.needNumber( this.detail_Edit, "Detail", true );
         if ( denoise == null || detail == null )
            return false;
         par.denoise = denoise;
         par.detail = detail;
         return true;
      }
      if ( this.step.kind == "starx" )
      {
         par.outputStars = this.stars_Check.checked;
         par.unscreen = this.unscreen_Check.checked;
         return true;
      }
      if ( this.step.kind == "starxmono" )
         return true;
      if ( this.step.kind == "autolinear" )
      {
         par.referenceMethod = this.chosen( this.method_Combo );
         if ( this.in_Edit )
            par.input = this.readChannel( this.in_Edit, this.par.input || "SHO" );
         return true;
      }
      if ( this.step.kind == "screen" )
      {
         let shadows = this.needNumber( this.shadows_Edit, "Shadows clipping", true );
         let target = this.needNumber( this.target_Edit, "Target background", false );
         if ( shadows == null || target == null )
            return false;
         par.linked = this.linked_Check.checked;
         par.shadows = shadows;
         par.target = target;
         return true;
      }
      if ( this.step.kind == "stretch" )
      {
         let target = this.needNumber( this.target_Edit, "Target background", false );
         let aggressive = this.needNumber( this.aggressive_Edit, "Aggressiveness", true );
         let range = this.needNumber( this.range_Edit, "Dynamic range compression", true );
         let separation = this.needNumber( this.separation_Edit, "Scale separation", false );
         let intensity = this.needNumber( this.intensity_Edit, "Intensity", true );
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         let boost = this.needNumber( this.boost_Edit, "Boost", true );
         if ( target == null || aggressive == null || range == null || separation == null
              || intensity == null || amount == null || boost == null )
            return false;
         par.targetBackground = target;
         par.aggressiveness = aggressive;
         par.dynamicRange = range;
         par.contrastRecovery = this.recovery_Check.checked;
         par.scaleSeparation = separation;
         par.intensity = intensity;
         par.saturation = this.saturation_Check.checked;
         par.saturationAmount = amount;
         par.saturationBoost = boost;
         if ( this.in_Edit )
         {
            par.input = this.readChannel( this.in_Edit, this.par.input || "" );
            par.output = this.readChannel( this.out_Edit, par.input );
         }
         return true;
      }
      if ( this.step.kind == "nbtorgb" )
      {
         let ratio = this.needNumber( this.ratio_Edit, "Ha to OIII ratio", true );
         if ( ratio == null )
            return false;
         par.sii = this.readChannel( this.sii_Edit, "SII_stars" );
         par.ha = this.readChannel( this.ha_Edit, "Ha_stars" );
         par.oiii = this.readChannel( this.oiii_Edit, "OIII_stars" );
         par.output = this.readChannel( this.out_Edit, "NBtoRGB_stars" );
         par.haToOiiRatio = ratio;
         let stretch = this.needNumber( this.stretch_Edit, "Stretch factor", false );
         let boost = this.needNumber( this.boost_Edit, "Color boost", true );
         if ( stretch == null || boost == null )
            return false;
         par.applyStarStretch = this.stretch_Check.checked;
         par.stretchFactor = stretch;
         par.colorBoost = boost;
         return true;
      }
      if ( this.step.kind == "shocombine" || this.step.kind == "sholrgb" )
      {
         par.inputR = this.readChannel( this.r_Edit, "SII" );
         par.inputG = this.readChannel( this.g_Edit, "Ha" );
         par.inputB = this.readChannel( this.b_Edit, "OIII" );
         par.output = this.readChannel( this.out_Edit, "SHO" );
         return true;
      }
      if ( this.step.kind == "rename" )
      {
         par.input = this.readChannel( this.in_Edit, "SHO" );
         par.output = this.readChannel( this.out_Edit, "SHO" );
         return true;
      }
      if ( this.step.kind == "invert" )
      {
         par.input = this.readChannel( this.in_Edit, "SHO" );
         return true;
      }
      if ( this.step.kind == "scnr" )
      {
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         if ( amount == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "SHO" );
         par.amount = amount;
         return true;
      }
      if ( this.step.kind == "lhe" )
      {
         let radius = this.needNumber( this.radius_Edit, "Radius", false );
         let slope = this.needNumber( this.slope_Edit, "Slope limit", false );
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         if ( radius == null || slope == null || amount == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "SHO" );
         par.radius = radius;
         par.slopeLimit = slope;
         par.amount = amount;
         return true;
      }
      if ( this.step.kind == "curves" )
      {
         par.input = this.readChannel( this.in_Edit, "SHO" );
         return true;
      }
      if ( this.step.kind == "rotate" )
      {
         let angle = this.needNumber( this.angle_Edit, "Angle", true );
         if ( angle == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "SHO" );
         par.angleDeg = angle;
         return true;
      }
      if ( this.step.kind == "resample" )
      {
         let scale = this.needNumber( this.scale_Edit, "Scale", false );
         if ( scale == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "SHO" );
         par.scale = scale;
         return true;
      }
      if ( this.step.kind == "autoassign" )
      {
         par.preferFits = this.preferFits_Check.checked;
         return true;
      }
      if ( this.step.kind == "composergb" || this.step.kind == "composesho" )
         return true;
      if ( this.step.kind == "hdrmt" )
      {
         let layers = this.needNumber( this.layers_Edit, "Number of layers", false );
         let iterations = this.needNumber( this.iterations_Edit, "Number of iterations", false );
         let overdrive = this.needNumber( this.overdrive_Edit, "Overdrive", true );
         if ( layers == null || iterations == null || overdrive == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "RGB" );
         par.output = this.readChannel( this.out_Edit, par.input );
         par.numberOfLayers = Math.round( layers );
         par.numberOfIterations = Math.round( iterations );
         par.invertedIterations = this.inverted_Check.checked;
         par.overdrive = overdrive;
         par.medianTransform = this.median_Check.checked;
         par.toIntensity = this.toIntensity_Check.checked;
         par.toLightness = this.toLightness_Check.checked;
         par.preserveHue = this.preserveHue_Check.checked;
         par.luminanceMask = this.luminanceMask_Check.checked;
         return true;
      }
      if ( this.step.kind == "lrgbcomb" )
      {
         let mL = this.needNumber( this.mL_Edit, "Lightness", true );
         let mc = this.needNumber( this.mc_Edit, "Saturation", true );
         if ( mL == null || mc == null )
            return false;
         par.inputL = this.readChannel( this.inL_Edit, "L" );
         par.inputRGB = this.readChannel( this.inRGB_Edit, "RGB" );
         par.output = this.readChannel( this.out_Edit, "LRGB" );
         par.mL = mL;
         par.mc = mc;
         par.clipHighlights = this.clip_Check.checked;
         return true;
      }
      if ( this.step.kind == "starstretch" )
      {
         let amount = this.needNumber( this.ssAmount_Edit, "Stretch amount", false );
         let sat = this.needNumber( this.ssSat_Edit, "Color boost", true );
         if ( amount == null || sat == null )
            return false;
         par.input = this.readChannel( this.in_Edit, this.par.input || "RGB_stars" );
         par.output = this.readChannel( this.out_Edit, this.par.output || par.input );
         par.amount = amount;
         par.satAmount = sat;
         par.removeGreen = this.ssGreen_Check.checked;
         return true;
      }
      if ( this.step.kind == "histo" )
      {
         if ( this.resetHisto_Check )
         {
            par.input = this.readChannel( this.in_Edit, "LRGB" );
            par.output = this.readChannel( this.out_Edit, par.input );
            if ( this.resetHisto_Check.checked )
               par.H = f1CloneHistoH( F1_DEFAULT_HISTO_H );
            else if ( !par.H || !par.H.length )
               par.H = f1CloneHistoH( F1_DEFAULT_HISTO_H );
            return true;
         }
         let c0 = f1Parse( this.c0_Edit.text );
         let mid = f1Parse( this.m_Edit.text );
         let c1 = f1Parse( this.c1_Edit.text );
         if ( c0 == null || c0 < 0 || mid == null || !( mid > 0 ) || c1 == null || !( c1 > 0 ) )
         {
            f1Message( "Histogram shadows, midtones and highlights must be numbers." );
            return false;
         }
         par.H = f1HistoCurve( c0, mid, c1 );
         if ( this.in_Edit )
         {
            par.input = this.readChannel( this.in_Edit, "SHO" );
            par.output = this.readChannel( this.out_Edit, par.input );
         }
         return true;
      }
      if ( this.step.kind == "pm" )
      {
         let expr = this.pmExpr_Edit.text.replace( /^\s+|\s+$/g, "" );
         if ( !expr.length )
         {
            f1Message( "PixelMath needs an expression." );
            return false;
         }
         par.expression = expr;
         return true;
      }
      if ( this.step.kind == "putstars" )
      {
         par.inputStars = this.readChannel( this.inStars_Edit, this.par.inputStars || "RGB_stars" );
         par.inputTarget = this.readChannel( this.inTarget_Edit, this.par.inputTarget || "LRGB" );
         par.output = this.readChannel( this.out_Edit, this.par.output || par.inputTarget );
         let expr = this.pmExpr_Edit.text.replace( /^\s+|\s+$/g, "" );
         if ( !expr.length
              || expr == "combine(RGB_stars, LRGB, op_screen())"
              || /^combine\([^,]+,\s*[^,]+,\s*op_screen\(\)\)$/.test( expr ) )
            expr = "combine(" + par.inputStars + ", " + par.inputTarget + ", op_screen())";
         par.expression = expr;
         return true;
      }
      return true;
   }

   buildAutoAssign( body )
   {
      this.preferFits_Check = new CheckBox( this );
      this.preferFits_Check.text = "Prefer FITS/XISF FILTER keyword over file name";
      this.preferFits_Check.checked = this.par.preferFits !== false;
      body.add( this.preferFits_Check );
   }

   buildComposeRGB( body )
   {
   }

   buildComposeSHO( body )
   {
   }

   buildHDRMT( body )
   {
      this.addChannelIO( body, {
         input: this.par.input || "RGB",
         output: this.par.output || this.par.input || "RGB"
      } );
      this.layers_Edit = this.edit( this.par.numberOfLayers != null ? this.par.numberOfLayers : 6, 0 );
      this.iterations_Edit = this.edit( this.par.numberOfIterations != null ? this.par.numberOfIterations : 1, 0 );
      this.overdrive_Edit = this.edit( this.par.overdrive != null ? this.par.overdrive : 0, 3 );
      this.inverted_Check = new CheckBox( this );
      this.inverted_Check.text = "Inverted";
      this.inverted_Check.checked = this.par.invertedIterations !== false;
      this.median_Check = new CheckBox( this );
      this.median_Check.text = "Median transform";
      this.median_Check.checked = this.par.medianTransform ? true : false;
      this.toIntensity_Check = new CheckBox( this );
      this.toIntensity_Check.text = "To intensity";
      this.toIntensity_Check.checked = this.par.toIntensity ? true : false;
      this.toLightness_Check = new CheckBox( this );
      this.toLightness_Check.text = "To lightness";
      this.toLightness_Check.checked = this.par.toLightness ? true : false;
      this.preserveHue_Check = new CheckBox( this );
      this.preserveHue_Check.text = "Preserve hue";
      this.preserveHue_Check.checked = this.par.preserveHue ? true : false;
      this.luminanceMask_Check = new CheckBox( this );
      this.luminanceMask_Check.text = "Lightness mask";
      this.luminanceMask_Check.checked = this.par.luminanceMask !== false;
      body.add( this.row( "Number of layers", this.layers_Edit ) );
      body.add( this.row( "Number of iterations", this.iterations_Edit ) );
      body.add( this.inverted_Check );
      body.add( this.row( "Overdrive", this.overdrive_Edit ) );
      body.add( this.median_Check );
      body.add( this.toIntensity_Check );
      body.add( this.toLightness_Check );
      body.add( this.preserveHue_Check );
      body.add( this.luminanceMask_Check );
   }

   buildLRGBComb( body )
   {
      this.addChannelIO( body, {
         inputL: this.par.inputL || "L",
         inputRGB: this.par.inputRGB || "RGB",
         output: this.par.output || "LRGB"
      } );
      this.mL_Edit = this.edit( this.par.mL, 3 );
      this.mc_Edit = this.edit( this.par.mc, 3 );
      this.clip_Check = new CheckBox( this );
      this.clip_Check.text = "Clip highlights";
      this.clip_Check.checked = this.par.clipHighlights !== false;
      body.add( this.row( "Lightness", this.mL_Edit ) );
      body.add( this.row( "Saturation", this.mc_Edit ) );
      body.add( this.clip_Check );
   }

   buildStarStretch( body )
   {
      this.creditNote( body );
      this.addChannelIO( body, {
         input: this.par.input || "RGB_stars",
         output: this.par.output || this.par.input || "RGB_stars"
      } );
      this.ssAmount_Edit = this.edit( this.par.amount, 2 );
      this.ssSat_Edit = this.edit( this.par.satAmount, 2 );
      this.ssGreen_Check = new CheckBox( this );
      this.ssGreen_Check.text = "Remove green via SCNR";
      this.ssGreen_Check.checked = this.par.removeGreen ? true : false;
      body.add( this.row( "Stretch amount", this.ssAmount_Edit ) );
      body.add( this.row( "Color boost", this.ssSat_Edit ) );
      body.add( this.ssGreen_Check );
   }

   buildHisto( body )
   {
      let lrgb = this.step.id == "histo";
      if ( lrgb )
      {
         this.addChannelIO( body, {
            input: this.par.input || "LRGB",
            output: this.par.output || this.par.input || "LRGB"
         } );
         this.resetHisto_Check = new CheckBox( this );
         this.resetHisto_Check.text = "Reset to default H curves";
         this.resetHisto_Check.checked = false;
         body.add( this.resetHisto_Check );
         return;
      }
      let row = ( this.par.H && this.par.H[3] ) ? this.par.H[3] : [ 0.0023, 0.03037975, 0.38481013, 0, 1 ];
      if ( this.par.input )
      {
         this.addChannelIO( body, {
            input: this.par.input || "SHO",
            output: this.par.output || this.par.input || "SHO"
         } );
      }
      this.c0_Edit = this.edit( row[0], 8 );
      this.m_Edit = this.edit( row[1], 8 );
      this.c1_Edit = this.edit( row[2], 8 );
      body.add( this.row( "Shadows", this.c0_Edit ) );
      body.add( this.row( "Midtones", this.m_Edit ) );
      body.add( this.row( "Highlights", this.c1_Edit ) );
   }

   buildPixelMath( body )
   {
      this.pmExpr_Edit = new Edit( this );
      this.pmExpr_Edit.text = this.par.expression || "$T*2";
      this.pmExpr_Edit.setScaledMinWidth( 360 );
      body.add( this.row( "Expression", this.pmExpr_Edit ) );
   }

   buildPutStars( body )
   {
      this.addChannelIO( body, {
         inputStars: this.par.inputStars || "RGB_stars",
         inputTarget: this.par.inputTarget || "LRGB",
         output: this.par.output || this.par.inputTarget || "LRGB"
      } );
      this.pmExpr_Edit = new Edit( this );
      this.pmExpr_Edit.text = this.par.expression
         || "combine(RGB_stars, LRGB, op_screen())";
      this.pmExpr_Edit.setScaledMinWidth( 360 );
      body.add( this.row( "Expression", this.pmExpr_Edit ) );
   }

   buildAutoLinear( body )
   {
      let methods = [
         "Lowest mean",
         "Lowest noise k-sigma",
         "Lowest noise MRS",
         "Red channel",
         "Green channel",
         "Blue channel"
      ];
      this.method_Combo = new ComboBox( this );
      for ( let i = 0; i < methods.length; ++i )
         this.method_Combo.addItem( methods[i] );
      let selected = this.par.referenceMethod || "Lowest mean";
      let index = methods.indexOf( selected );
      this.method_Combo.currentItem = index >= 0 ? index : 0;
      body.add( this.row( "Reference channel", this.method_Combo ) );
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      body.add( this.row( "Target view", this.in_Edit ) );
   }

   buildNBtoRGB( body )
   {
      this.creditNote( body );
      this.sii_Edit = this.channelEdit( this.par.sii || "SII_stars" );
      this.ha_Edit = this.channelEdit( this.par.ha || "Ha_stars" );
      this.oiii_Edit = this.channelEdit( this.par.oiii || "OIII_stars" );
      this.out_Edit = this.channelEdit( this.par.output || "NBtoRGB_stars" );
      this.ratio_Edit = this.edit( this.par.haToOiiRatio != null ? this.par.haToOiiRatio : 0.3, 2 );
      this.stretch_Edit = this.edit( this.par.stretchFactor != null ? this.par.stretchFactor : 6, 2 );
      this.boost_Edit = this.edit( this.par.colorBoost != null ? this.par.colorBoost : 1.7, 2 );
      this.stretch_Check = new CheckBox( this );
      this.stretch_Check.text = "Star stretch inside NB to RGB";
      this.stretch_Check.checked = this.par.applyStarStretch !== false;
      body.add( this.row( "SII stars", this.sii_Edit ) );
      body.add( this.row( "Ha stars", this.ha_Edit ) );
      body.add( this.row( "OIII stars", this.oiii_Edit ) );
      body.add( this.row( "Output view", this.out_Edit ) );
      body.add( this.row( "Ha to OIII ratio", this.ratio_Edit ) );
      body.add( this.stretch_Check );
      body.add( this.row( "Stretch factor", this.stretch_Edit ) );
      body.add( this.row( "Color boost", this.boost_Edit ) );
   }

   buildSHOCombine( body )
   {
      this.r_Edit = this.channelEdit( this.par.inputR || "SII" );
      this.g_Edit = this.channelEdit( this.par.inputG || "Ha" );
      this.b_Edit = this.channelEdit( this.par.inputB || "OIII" );
      this.out_Edit = this.channelEdit( this.par.output || "SHO" );
      body.add( this.row( "R", this.r_Edit ) );
      body.add( this.row( "G", this.g_Edit ) );
      body.add( this.row( "B", this.b_Edit ) );
      body.add( this.row( "Output view", this.out_Edit ) );
   }

   buildRename( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      this.out_Edit = this.channelEdit( this.par.output || "SHO" );
      body.add( this.row( "Input view", this.in_Edit ) );
      body.add( this.row( "New name", this.out_Edit ) );
   }

   buildInvert( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      body.add( this.row( "Input view", this.in_Edit ) );
   }

   buildSCNR( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      this.amount_Edit = this.edit( this.par.amount != null ? this.par.amount : 1, 2 );
      body.add( this.row( "Input view", this.in_Edit ) );
      body.add( this.row( "Amount", this.amount_Edit ) );
   }

   buildLHE( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      this.radius_Edit = this.edit( this.par.radius != null ? this.par.radius : 256, 0 );
      this.slope_Edit = this.edit( this.par.slopeLimit != null ? this.par.slopeLimit : 1.5, 2 );
      this.amount_Edit = this.edit( this.par.amount != null ? this.par.amount : 0.5, 3 );
      body.add( this.row( "Input view", this.in_Edit ) );
      body.add( this.row( "Radius", this.radius_Edit ) );
      body.add( this.row( "Slope limit", this.slope_Edit ) );
      body.add( this.row( "Amount", this.amount_Edit ) );
   }

   buildCurves( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      body.add( this.row( "Input view", this.in_Edit ) );
   }

   buildRotation( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      this.angle_Edit = this.edit( this.par.angleDeg != null ? this.par.angleDeg : 180, 2 );
      body.add( this.row( "Input view", this.in_Edit ) );
      body.add( this.row( "Angle (degrees)", this.angle_Edit ) );
   }

   buildResample( body )
   {
      this.in_Edit = this.channelEdit( this.par.input || "SHO" );
      this.scale_Edit = this.edit( this.par.scale != null ? this.par.scale : 0.5, 2 );
      body.add( this.row( "Input view", this.in_Edit ) );
      body.add( this.row( "Scale", this.scale_Edit ) );
   }
};

var F1AddStepDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.choice = "";
      this.index = -1;
      this.ready = false;
      this.windowTitle = "Add process";
      this.userResizable = false;
      let dialog = this;

      let iconLabel = new Label( this );
      iconLabel.text = "Process icon";
      let icon = new ComboBox( this );
      icon.addItem( "Process icon…" );
      icon.addItem( "From the workspace" );
      icon.setScaledMinWidth( 360 );
      icon.onItemSelected = function( index )
      {
         if ( !dialog.ready || index < 1 )
            return;
         dialog.choice = "icon";
         dialog.ok();
      };

      let builtinLabel = new Label( this );
      builtinLabel.text = "Built-in process";
      let builtin = new ComboBox( this );
      builtin.addItem( "Built-in process…" );
      for ( let i = 0; i < F1_ADDABLE_STEPS.length; ++i )
         builtin.addItem( f1StepLabel( F1_ADDABLE_STEPS[i] ) );
      builtin.setScaledMinWidth( 360 );
      builtin.onItemSelected = function( index )
      {
         if ( !dialog.ready || index < 1 )
            return;
         dialog.choice = "builtin";
         dialog.index = index - 1;
         dialog.ok();
      };

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 6;
      this.sizer.add( iconLabel );
      this.sizer.add( icon );
      this.sizer.addSpacing( 8 );
      this.sizer.add( builtinLabel );
      this.sizer.add( builtin );
      this.ready = true;
   }
};

var F1PhaseFailureDialog = class extends Dialog
{
   constructor( info )
   {
      super();
      this.choice = "stop";
      this.windowTitle = "BatchProcessing_byHrast";
      this.userResizable = true;
      let dialog = this;
      let contText = "Skip failed step " + info.stepTitle + " and continue other steps";
      let stopText = "Stop the rest of script";
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = info.message;

      let cont = new PushButton( this );
      cont.text = contText;
      cont.onClick = function()
      {
         dialog.choice = "continue";
         dialog.ok();
      };
      let stop = new PushButton( this );
      stop.text = stopText;
      stop.onClick = function()
      {
         dialog.choice = "stop";
         dialog.ok();
      };
      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add( note );
      this.sizer.add( cont );
      this.sizer.add( stop );
      this.setScaledMinWidth( 720 );
   }
};

var BatchProcessingDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.windowTitle = "BatchProcessing_byHrast " + BP_VERSION;
      this.userResizable = true;
      this.ready = false;
      this.loading = true;
      let dialog = this;

      this.lists = {};
      this.stepTrees = {};
      this.stepNodes = {};
      this.stepButton = {};
      this.stepUpButton = {};
      this.stepDownButton = {};
      this.stepAddButton = {};
      this.stepRemoveButton = {};
      this.phaseTrees = {};
      this.phaseNodes = {};
      this.phaseButton = {};
      this.phaseUpButton = {};
      this.phaseDownButton = {};
      this.phaseAddButton = {};
      this.phaseRemoveButton = {};
      let imageSizer = new VerticalSizer;
      imageSizer.spacing = 8;
      imageSizer.margin = 10;
      for ( let i = 0; i < F1_SLOTS.length; ++i )
         imageSizer.add( this.makeSlotBlock( F1_SLOTS[i] ) );

      this.image_Group = this.makeCollapsibleSection( "Images", imageSizer, true );
      this.pre_Group = this.makePhaseGroup( "pre", "Pre" );
      this.post_Group = this.makePhaseGroup( "post", "Post" );

      this.preset_Label = new Label( this );
      this.preset_Label.text = "Preset:";
      this.preset_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

      this.preset_Combo = new ComboBox( this );
      this.preset_Combo.editEnabled = true;
      this.preset_Combo.setScaledMinWidth( 180 );
      this.preset_Combo.toolTip = "<p>Quick profiles stored inside PixInsight. "
                                + F1_LRGB_PRESET + " is the LRGB workflow, including Post. "
                                + F1_SHO_PRESET + " is the narrowband preset. "
                                + F1_CLEAR_PRESET + " leaves Pre, Post and every filter row empty. "
                                + "Type a new name, then Save.</p>";

      this.presetSave_Button = new PushButton( this );
      this.presetSave_Button.text = "Save";
      this.presetSave_Button.toolTip = "<p>Save the current setup under the preset name in the box. "
                                    + "Does not overwrite " + F1_LRGB_PRESET + ", " + F1_SHO_PRESET
                                    + " or " + F1_CLEAR_PRESET + " — type a new name first.</p>";
      this.presetSave_Button.onClick = () => dialog.savePreset();

      this.presetLoad_Button = new PushButton( this );
      this.presetLoad_Button.text = "Load";
      this.presetLoad_Button.toolTip = "<p>Load the selected preset. "
                                    + F1_LRGB_PRESET + " restores the LRGB chain and the Post steps. "
                                    + F1_SHO_PRESET + " restores the narrowband chain. "
                                    + F1_CLEAR_PRESET + " clears Pre, Post and every filter row. "
                                    + "Selected images stay. Closing the script does not restore a preset.</p>";
      this.presetLoad_Button.onClick = () => dialog.loadPreset();

      this.presetDelete_Button = new PushButton( this );
      this.presetDelete_Button.text = "Delete";
      this.presetDelete_Button.toolTip = "<p>Delete the selected named preset. "
                                    + F1_LRGB_PRESET + ", " + F1_SHO_PRESET + " and " + F1_CLEAR_PRESET
                                    + " cannot be deleted.</p>";
      this.presetDelete_Button.onClick = () => dialog.deletePreset();

      this.exportSettings_Button = new PushButton( this );
      this.exportSettings_Button.text = "Export Settings";
      this.exportSettings_Button.toolTip = "<p>Export the current setup to a .bpshrast file on disk "
                                       + "(for backup or sharing).</p>";
      this.exportSettings_Button.onClick = () => dialog.exportSettingsFile();

      this.importSettings_Button = new PushButton( this );
      this.importSettings_Button.text = "Import Settings";
      this.importSettings_Button.toolTip = "<p>Import a .bpshrast file from disk. "
                                       + "Selected images stay; process order and parameters are replaced.</p>";
      this.importSettings_Button.onClick = () => dialog.importSettingsFile();

      this.run_Button = new PushButton( this );
      this.run_Button.text = "Process";
      this.run_Button.defaultButton = true;
      this.run_Button.onClick = () => dialog.run();

      this.close_Button = new PushButton( this );
      this.close_Button.text = "Close";
      this.close_Button.onClick = () =>
      {
         dialog.saveFromControls();
         dialog.cancel();
      };

      let presetRow = new HorizontalSizer;
      presetRow.spacing = 6;
      presetRow.add( this.preset_Label );
      presetRow.add( this.preset_Combo, 100 );
      presetRow.add( this.presetSave_Button );
      presetRow.add( this.presetLoad_Button );
      presetRow.add( this.presetDelete_Button );
      presetRow.addSpacing( 12 );
      presetRow.add( this.exportSettings_Button );
      presetRow.add( this.importSettings_Button );

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( this.run_Button );
      buttons.add( this.close_Button );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.makeHeaderRow() );
      this.sizer.add( this.pre_Group );
      this.sizer.add( this.image_Group, 100 );
      this.sizer.add( this.post_Group );
      this.sizer.add( presetRow );
      this.sizer.add( buttons );

      this.fillPresetCombo( f1ReadString( "lastPreset", F1_BUILTIN_PRESET ) );

      this.restoreViews();
      this.ensureLayoutUpdated();
      this.adjustToContents();
      this.setVariableSize();
      this.setScaledMinWidth( 760 );
      this.loading = false;
      this.onHide = () =>
      {
         if ( !dialog.ready )
            return;
         try
         {
            dialog.saveFromControls();
         }
         catch ( e )
         {
         }
      };
      this.ready = true;
   }

   openAddMenu( onIcon, onBuiltin )
   {
      let pick = new F1AddStepDialog();
      if ( !pick.execute() )
         return;
      if ( pick.choice == "icon" )
         onIcon();
      else if ( pick.choice == "builtin" )
         onBuiltin( pick.index );
   }

   makeHeaderLink( text, url )
   {
      let link = new Label( this );
      link.useRichText = true;
      link.text = "<u>" + text + "</u>";
      link.toolTip = "<p>" + url + "</p>";
      try { link.cursor = new Cursor( StdCursor_PointingHand ); } catch ( e ) {}
      link.onMousePress = function()
      {
         Dialog.openBrowser( url );
      };
      return link;
   }

   makeHeaderRow()
   {
      let row = new HorizontalSizer;
      row.spacing = 0;
      let lead = new Label( this );
      lead.text = "Repository: ";
      let mid = new Label( this );
      mid.text = " · Tutorials for this script:";
      row.add( lead );
      row.add( this.makeHeaderLink( "pixinsight.byhrast.com", "https://pixinsight.byhrast.com" ) );
      row.add( mid );
      row.add( this.makeHeaderLink( "YouTube", "https://www.youtube.com/playlist?list=PLduFG38CI4kQ" ) );
      row.addStretch();
      return row;
   }

   makeFixedLabel( text )
   {
      let label = new Label( this );
      label.text = text;
      label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      label.setScaledFixedWidth( 88 );
      return label;
   }

   makeCollapsibleSection( title, contentSizer, startOpen )
   {
      let dialog = this;
      let section = new Control( this );
      section.sizer = contentSizer;
      let bar = new SectionBar( this, title );
      bar.setSection( section );
      if ( !startOpen )
         section.hide();
      bar.updateIcon();
      bar.onToggleSection = function( sectionBar, toggleBegin )
      {
         if ( !toggleBegin )
         {
            dialog.ensureLayoutUpdated();
            dialog.adjustToContents();
            dialog.setVariableSize();
         }
      };
      let wrap = new VerticalSizer;
      wrap.spacing = 0;
      wrap.add( bar );
      wrap.add( section );
      return wrap;
   }

   fourRowHeight( control )
   {
      let row = 24;
      try
      {
         if ( control.font && control.font.height > 0 )
            row = control.font.height + 10;
      }
      catch ( e )
      {
      }
      return 4 * row + 8;
   }

   makePhaseGroup( name, title )
   {
      let dialog = this;
      let tree = new TreeBox( this );
      tree.numberOfColumns = 1;
      tree.headerVisible = false;
      tree.rootDecoration = false;
      tree.alternateRowColor = true;
      tree.multipleSelection = false;
      tree.nodeDragging = false;
      // Four visible rows. Extra steps scroll; the list does not grow with the dialog.
      tree.setScaledFixedHeight( this.fourRowHeight( tree ) );
      this.phaseTrees[name] = tree;
      this.phaseNodes[name] = {};
      this.fillPhaseTree( name );

      tree.onNodeUpdated = function( node )
      {
         if ( dialog.loading )
            return;
         let step = dialog.phaseStepFromNode( name, node );
         if ( !step || !f1PhaseStepInstalled( step ) )
            return;
         f1[name].steps[step.id].on = node.checked ? true : false;
         dialog.syncPhaseButtons( name );
      };
      tree.onNodeDoubleClicked = function( node )
      {
         let step = dialog.phaseStepFromNode( name, node );
         if ( step )
            dialog.openPhaseStep( name, step );
      };
      tree.onCurrentNodeUpdated = function()
      {
         dialog.syncPhaseButtons( name );
      };

      let up = new ToolButton( this );
      up.setScaledFixedSize( 24, 24 );
      up.icon = this.scaledResource( ":/arrows/arrow-up.png" );
      up.onClick = function() { dialog.movePhaseStep( name, -1 ); };
      let down = new ToolButton( this );
      down.setScaledFixedSize( 24, 24 );
      down.icon = this.scaledResource( ":/arrows/arrow-down.png" );
      down.onClick = function() { dialog.movePhaseStep( name, 1 ); };
      let add = new PushButton( this );
      add.text = "+";
      add.toolTip = "<p>Add a process icon from the workspace, or a built-in process.</p>";
      add.onClick = function()
      {
         dialog.openAddMenu(
            function() { dialog.addPhaseIconStep( name ); },
            function( index ) { dialog.addPhaseBuiltin( name, index ); }
         );
      };
      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.toolTip = "<p>Remove the selected step from this phase. Built-in steps come back with "
                    + "Load Default or a preset that still includes them.</p>";
      remove.onClick = function() { dialog.removePhaseIconStep( name ); };
      let setup = new PushButton( this );
      setup.text = "Settings";
      setup.onClick = function()
      {
         let step = dialog.phaseSelectedStep( name );
         if ( step )
            dialog.openPhaseStep( name, step );
      };
      this.phaseButton[name] = setup;
      this.phaseUpButton[name] = up;
      this.phaseDownButton[name] = down;
      this.phaseAddButton[name] = add;
      this.phaseRemoveButton[name] = remove;
      this.syncPhaseButtons( name );

      let note = new Label( this );
      note.wordWrapping = true;
      note.text = name == "pre"
         ? "Runs before the filter rows."
         : "Runs after the filter rows.";

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.add( up );
      buttons.add( down );
      buttons.add( add );
      buttons.add( remove );
      buttons.addStretch();
      buttons.add( setup );

      let sizer = new VerticalSizer;
      sizer.margin = 8;
      sizer.spacing = 6;
      sizer.add( note );
      sizer.add( tree );
      sizer.add( buttons );

      // Collapsible so low-resolution screens can hide Pre / Post.
      return this.makeCollapsibleSection( title, sizer, true );
   }

   fillPhaseTree( name )
   {
      let tree = this.phaseTrees[name];
      tree.clear();
      this.phaseNodes[name] = {};
      let steps = f1PhaseOrderedSteps( name );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1[name].steps[step.id];
         if ( !state )
            state = f1[name].steps[step.id] = { on: f1PhaseDefaultOn( step ), par: f1PhaseDefaultParams( step ) };
         let node = new TreeBoxNode( tree );
         let installed = f1PhaseStepInstalled( step );
         node.checkable = true;
         node.checked = installed && state.on ? true : false;
         node.setText( 0, f1StepTitle( step, state.par ) + ( installed ? "" : " (not installed)" ) );
         node.enabled = installed ? true : false;
         this.phaseNodes[name][step.id] = node;
      }
   }

   phaseStepFromNode( name, node )
   {
      if ( !node )
         return null;
      let map = this.phaseNodes[name];
      for ( let id in map )
         if ( map[id] === node )
         {
            let steps = f1PhaseAllSteps( name );
            for ( let i = 0; i < steps.length; ++i )
               if ( steps[i].id == id )
                  return steps[i];
         }
      return null;
   }

   phaseSelectedStep( name )
   {
      return this.phaseStepFromNode( name, this.phaseTrees[name].currentNode );
   }

   syncPhaseButtons( name )
   {
      let tree = this.phaseTrees[name];
      let node = tree ? tree.currentNode : null;
      let index = node ? tree.childIndex( node ) : -1;
      let step = this.phaseSelectedStep( name );
      if ( this.phaseButton[name] )
         this.phaseButton[name].enabled = step && f1PhaseStepInstalled( step ) ? true : false;
      if ( this.phaseUpButton[name] )
         this.phaseUpButton[name].enabled = index > 0;
      if ( this.phaseDownButton[name] )
         this.phaseDownButton[name].enabled = index >= 0 && index < tree.numberOfChildren - 1;
      if ( this.phaseRemoveButton[name] )
         this.phaseRemoveButton[name].enabled = step ? true : false;
   }

   readPhaseOrder( name )
   {
      let tree = this.phaseTrees[name];
      let order = [];
      for ( let i = 0; i < tree.numberOfChildren; ++i )
      {
         let step = this.phaseStepFromNode( name, tree.child( i ) );
         if ( step )
            order.push( step.id );
      }
      f1[name].order = f1PhaseNormalizeOrder( name, order );
   }

   movePhaseStep( name, delta )
   {
      let tree = this.phaseTrees[name];
      let node = tree.currentNode;
      if ( !node )
         return;
      let from = tree.childIndex( node );
      let to = from + delta;
      if ( from < 0 || to < 0 || to >= tree.numberOfChildren )
         return;
      tree.move( from, to );
      tree.currentNode = node;
      this.readPhaseOrder( name );
      this.syncPhaseButtons( name );
   }

   blankAddedPar( step, par )
   {
      if ( !f1ShowsOneTarget( step.kind ) )
         return par;
      par.channel = "";
      if ( par.input != null )
         par.input = "";
      return par;
   }

   namedForSlot( slot, step, par )
   {
      if ( !f1ShowsOneTarget( step.kind ) )
         return par;
      par.channel = slot;
      if ( par.input != null )
         par.input = slot;
      return par;
   }

   addFilterBuiltin( slot, index )
   {
      let template = F1_ADDABLE_STEPS[index];
      if ( !template )
         return;
      let id = template.kind + "_" + ( new Date() ).getTime().toString( 36 );
      let step = { id: id, title: template.title, kind: template.kind };
      if ( template.mode )
         step.mode = template.mode;
      if ( !f1.adopted[slot] )
         f1.adopted[slot] = [];
      f1.adopted[slot].push( step );
      f1.steps[slot][id] = {
         on: true,
         par: this.namedForSlot( slot, step, f1DefaultParams( slot, step ) )
      };
      let order = f1.order[slot] ? f1.order[slot].slice( 0 ) : f1DefaultOrder( slot );
      order.push( id );
      f1.order[slot] = f1NormalizeOrder( slot, order );
      this.fillStepTree( slot );
      if ( this.stepNodes[slot][id] )
         this.stepTrees[slot].currentNode = this.stepNodes[slot][id];
      this.syncStepButtons( slot );
   }

   addPhaseBuiltin( name, index )
   {
      let template = F1_ADDABLE_STEPS[index];
      if ( !template )
         return;
      let id = template.kind + "_" + name + "_" + ( new Date() ).getTime().toString( 36 );
      let step = { id: id, title: template.title, kind: template.kind };
      if ( template.mode )
         step.mode = template.mode;
      if ( !f1[name].added )
         f1[name].added = [];
      f1[name].added.push( step );
      let par = f1PhaseDefaultParams( step );
      if ( step.kind == "blurx" && step.mode == "correct" )
      {
         par.correctOnly = true;
         par.sharpenStars = 0;
         par.starHalos = 0;
         par.sharpenNonstellar = 0;
      }
      f1[name].steps[id] = {
         on: true,
         par: this.blankAddedPar( step, par )
      };
      f1[name].order = f1PhaseNormalizeOrder( name, ( f1[name].order || [] ).concat( [ id ] ) );
      this.fillPhaseTree( name );
      if ( this.phaseNodes[name][id] )
         this.phaseTrees[name].currentNode = this.phaseNodes[name][id];
      this.syncPhaseButtons( name );
   }

   addPhaseIconStep( name )
   {
      let pick = new F1IconPickDialog();
      if ( !pick.execute() || !pick.iconName )
         return;
      try
      {
         let snap = f1SnapshotFromIcon( pick.iconName );
         let id = "icon_" + name + "_" + ( new Date() ).getTime().toString( 36 );
         let step = {
            id: id,
            title: snap.title,
            kind: "icon",
            processId: snap.processId,
            iconName: snap.iconName
         };
         if ( !f1[name].extra )
            f1[name].extra = [];
         f1[name].extra.push( step );
         f1[name].steps[id] = {
            on: true,
            par: {
               processId: snap.processId,
               iconName: snap.iconName,
               source: snap.source,
               title: snap.title,
               channel: "",
               input: ""
            }
         };
         f1[name].order = f1PhaseNormalizeOrder( name, ( f1[name].order || [] ).concat( [ id ] ) );
         this.fillPhaseTree( name );
         if ( this.phaseNodes[name][id] )
            this.phaseTrees[name].currentNode = this.phaseNodes[name][id];
         this.syncPhaseButtons( name );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   removePhaseIconStep( name )
   {
      let step = this.phaseSelectedStep( name );
      if ( !step )
         return;
      if ( !f1Confirm( "Remove step \"" + f1StepLabel( step ) + "\"?" ) )
         return;
      if ( step.kind == "icon" )
      {
         let next = [];
         let extra = f1[name].extra || [];
         for ( let i = 0; i < extra.length; ++i )
            if ( extra[i].id != step.id )
               next.push( extra[i] );
         f1[name].extra = next;
         delete f1[name].steps[step.id];
      }
      else if ( f1[name].added )
      {
         let next = [];
         let found = false;
         for ( let i = 0; i < f1[name].added.length; ++i )
         {
            if ( f1[name].added[i].id == step.id )
            {
               found = true;
               continue;
            }
            next.push( f1[name].added[i] );
         }
         if ( found )
         {
            f1[name].added = next;
            delete f1[name].steps[step.id];
         }
         else
         {
            if ( !f1[name].removed )
               f1[name].removed = {};
            f1[name].removed[step.id] = true;
         }
      }
      else
      {
         if ( !f1[name].removed )
            f1[name].removed = {};
         f1[name].removed[step.id] = true;
      }
      let order = [];
      let old = f1[name].order || [];
      for ( let i = 0; i < old.length; ++i )
         if ( old[i] != step.id )
            order.push( old[i] );
      f1[name].order = f1PhaseNormalizeOrder( name, order );
      this.fillPhaseTree( name );
      this.syncPhaseButtons( name );
   }

   openPhaseStep( name, step )
   {
      try
      {
         let gui = new FazaSetupDialog( name, step, f1[name].steps[step.id].par );
         if ( gui.execute() )
         {
            if ( step.kind == "icon" )
            {
               step.title = f1[name].steps[step.id].par.title || step.title;
               step.processId = f1[name].steps[step.id].par.processId || step.processId;
            }
            this.fillPhaseTree( name );
            if ( this.phaseNodes[name][step.id] )
               this.phaseTrees[name].currentNode = this.phaseNodes[name][step.id];
         }
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   makeSlotBlock( slot )
   {
      let block = new VerticalSizer;
      block.spacing = 6;
      block.add( this.makeViewRow( slot ) );
      let stepsRow = new HorizontalSizer;
      stepsRow.spacing = 6;
      let stepsIndent = new Label( this );
      stepsIndent.text = "";
      stepsIndent.setScaledFixedWidth( 88 );
      stepsRow.add( stepsIndent );
      stepsRow.add( this.makeStepSection( slot ), 100 );
      block.add( stepsRow );
      // Small gap under Steps so filter groups do not stick together.
      block.addSpacing( 5 );
      return block;
   }

   makeViewRow( slot )
   {
      let list = new ViewList( this );
      list.getMainViews();
      // Keep combo readable — layout must not squash ViewList height.
      list.setScaledFixedHeight( 28 );
      list.toolTip = "<p>Empty means " + slot + " is not processed.</p>";
      list.onViewSelected = function( view )
      {
         // Ignore transient selections while Pre/Compose refreshes ViewLists.
         if ( f1.suppressViewSync )
            return;
         f1.views[slot] = ( view && !view.isNull ) ? view.id : "";
      };
      this.lists[slot] = list;

      let row = new HorizontalSizer;
      row.spacing = 6;
      row.add( this.makeFixedLabel( slot ) );
      row.add( list, 100 );
      return row;
   }

   makeStepSection( slot )
   {
      let dialog = this;
      let section = new Control( this );
      section.sizer = new VerticalSizer;
      section.sizer.spacing = 8;
      section.sizer.margin = 8;

      let tree = new TreeBox( this );
      tree.numberOfColumns = 1;
      tree.headerVisible = false;
      tree.rootDecoration = false;
      tree.alternateRowColor = true;
      tree.multipleSelection = false;
      tree.nodeDragging = false;
      tree.nodeExpansion = false;
      // Fixed height: min+stretch made the dialog keep growing after expand/collapse.
      tree.setScaledFixedHeight( 180 );
      tree.toolTip = "<p>Select a process, then use the arrows to move it. "
                   + "Double-click or Settings opens its parameters.</p>";
      this.stepTrees[slot] = tree;
      this.stepNodes[slot] = {};
      this.fillStepTree( slot );

      tree.onNodeUpdated = function( node )
      {
         if ( dialog.loading )
            return;
         let step = dialog.stepFromNode( slot, node );
         if ( !step || !f1StepInstalled( step ) )
            return;
         let wasOn = f1.steps[slot][step.id].on;
         f1.steps[slot][step.id].on = node.checked ? true : false;
         dialog.syncStepButtons( slot );
         if ( node.checked && !wasOn )
            dialog.openStep( slot, step );
      };
      tree.onNodeDoubleClicked = function( node )
      {
         let step = dialog.stepFromNode( slot, node );
         if ( step )
            dialog.openStep( slot, step );
      };
      tree.onCurrentNodeUpdated = function()
      {
         dialog.syncStepButtons( slot );
      };

      let up = new ToolButton( this );
      up.setScaledFixedSize( 24, 24 );
      up.icon = this.scaledResource( ":/arrows/arrow-up.png" );
      up.toolTip = "<p>Move the selected process earlier.</p>";
      up.onClick = function()
      {
         dialog.moveSelectedStep( slot, -1 );
      };

      let down = new ToolButton( this );
      down.setScaledFixedSize( 24, 24 );
      down.icon = this.scaledResource( ":/arrows/arrow-down.png" );
      down.toolTip = "<p>Move the selected process later.</p>";
      down.onClick = function()
      {
         dialog.moveSelectedStep( slot, 1 );
      };

      let add = new PushButton( this );
      add.text = "+";
      add.toolTip = "<p>Add a process icon from the workspace, or a built-in process. "
                  + "A built-in process needs its channel filled in.</p>";
      add.onClick = function()
      {
         dialog.openAddMenu(
            function() { dialog.addIconStep( slot ); },
            function( index ) { dialog.addFilterBuiltin( slot, index ); }
         );
      };

      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.toolTip = "<p>Remove the selected step from this chain. Built-in steps come back with "
                    + "Load Default or a preset that still includes them.</p>";
      remove.onClick = function()
      {
         dialog.removeSelectedIconStep( slot );
      };

      let setup = new PushButton( this );
      setup.text = "Settings";
      setup.toolTip = "<p>Open settings for the selected process.</p>";
      setup.onClick = function()
      {
         let step = dialog.selectedStep( slot );
         if ( step )
            dialog.openStep( slot, step );
      };
      this.stepButton[slot] = setup;
      this.stepUpButton[slot] = up;
      this.stepDownButton[slot] = down;
      this.stepAddButton[slot] = add;
      this.stepRemoveButton[slot] = remove;
      this.syncStepButtons( slot );

      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Select a process, then use the arrows to reorder. "
                + "+ opens a choice: a workspace icon, or a built-in process.";

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.add( up );
      buttons.add( down );
      buttons.add( add );
      buttons.add( remove );
      buttons.addStretch();
      buttons.add( setup );

      let copyTargets = f1CopyTargetsFor( slot );
      let copyRow = null;
      if ( copyTargets.length )
      {
      copyRow = new HorizontalSizer;
      copyRow.spacing = 4;
      let copyLabel = new Label( this );
      copyLabel.text = "Copy this Setup to";
      copyLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      copyLabel.toolTip = "<p>Copy this filter's full step order, checkboxes and parameters. "
                        + "Channel and filter names found in any process are switched to the target filter. "
                        + "Narrowband targets also take that filter's wavelength and bandwidth.</p>";
      copyRow.add( copyLabel );
      for ( let t = 0; t < copyTargets.length; ++t )
      {
         let target = copyTargets[t];
         let copyBtn = new PushButton( this );
         copyBtn.text = target;
         copyBtn.toolTip = "<p>Copy the full " + slot + " step order to " + target
                         + ". Filter names inside the processes become " + target + ".</p>";
         copyBtn.onClick = ( function( fromSlot, toSlot )
         {
            return function()
            {
               try
               {
                  dialog.readStepOrder( fromSlot );
                  let steps = f1OrderedSteps( fromSlot );
                  for ( let i = 0; i < steps.length; ++i )
                  {
                     let step = steps[i];
                     let node = dialog.stepNodes[fromSlot][step.id];
                     if ( node && f1.steps[fromSlot][step.id] )
                        f1.steps[fromSlot][step.id].on = node.checked ? true : false;
                  }
                  f1CopySlotSetup( fromSlot, toSlot );
                  dialog.fillStepTree( toSlot );
                  dialog.syncStepButtons( toSlot );
                  f1WriteSettings();
                  f1Message( "Copied " + fromSlot + " setup to " + toSlot + ".", true );
               }
               catch ( e )
               {
                  f1Message( e.message ? e.message : e.toString() );
               }
            };
         } )( slot, target );
         copyRow.add( copyBtn );
      }
      copyRow.addStretch();
      }

      section.sizer.add( note );
      section.sizer.addSpacing( 4 );
      section.sizer.add( tree );
      section.sizer.addSpacing( 4 );
      section.sizer.add( buttons );
      if ( copyRow )
      {
         section.sizer.addSpacing( 4 );
         section.sizer.add( copyRow );
      }

      let bar = new SectionBar( this, "Steps" );
      bar.setSection( section );
      section.hide();
      bar.updateIcon();
      bar.onToggleSection = function( sectionBar, toggleBegin )
      {
         if ( !toggleBegin )
         {
            dialog.ensureLayoutUpdated();
            dialog.adjustToContents();
            dialog.setVariableSize();
         }
      };

      let wrap = new VerticalSizer;
      wrap.spacing = 0;
      wrap.add( bar );
      wrap.add( section );
      return wrap;
   }

   fillStepTree( slot )
   {
      let tree = this.stepTrees[slot];
      tree.clear();
      this.stepNodes[slot] = {};
      let steps = f1OrderedSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         let node = new TreeBoxNode( tree );
         let installed = f1StepInstalled( step );
         node.checkable = true;
         node.checked = installed && state.on ? true : false;
         node.setText( 0, f1StepTitle( step, state.par ) + ( installed ? "" : " (not installed)" ) );
         node.enabled = installed ? true : false;
         if ( !installed )
            node.setToolTip( 0, step.title + " is not installed in PixInsight. This step is skipped." );
         this.stepNodes[slot][step.id] = node;
      }
   }

   stepFromNode( slot, node )
   {
      if ( !node )
         return null;
      let map = this.stepNodes[slot];
      for ( let id in map )
         if ( map[id] === node )
         {
            let steps = f1AllSteps( slot );
            for ( let i = 0; i < steps.length; ++i )
               if ( steps[i].id == id )
                  return steps[i];
         }
      return null;
   }

   addIconStep( slot )
   {
      let pick = new F1IconPickDialog();
      if ( !pick.execute() || !pick.iconName )
         return;
      try
      {
         let snap = f1SnapshotFromIcon( pick.iconName );
         let id = f1NewIconStepId();
         let step = {
            id: id,
            title: snap.title,
            kind: "icon",
            processId: snap.processId,
            iconName: snap.iconName
         };
         if ( !f1.extra[slot] )
            f1.extra[slot] = [];
         f1.extra[slot].push( step );
         f1.steps[slot][id] = {
            on: true,
            par: {
               processId: snap.processId,
               iconName: snap.iconName,
               source: snap.source,
               title: snap.title,
               channel: slot,
               input: slot
            }
         };
         let order = f1.order[slot] ? f1.order[slot].slice( 0 ) : f1DefaultOrder( slot );
         order.push( id );
         f1.order[slot] = f1NormalizeOrder( slot, order );
         this.fillStepTree( slot );
         let node = this.stepNodes[slot][id];
         if ( node )
            this.stepTrees[slot].currentNode = node;
         this.syncStepButtons( slot );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   removeSelectedIconStep( slot )
   {
      let step = this.selectedStep( slot );
      if ( !step )
         return;
      if ( !f1Confirm( "Remove step \"" + f1StepLabel( step ) + "\"?" ) )
         return;
      if ( step.kind == "icon" )
      {
         let extra = f1.extra[slot] || [];
         let next = [];
         for ( let i = 0; i < extra.length; ++i )
            if ( extra[i].id != step.id )
               next.push( extra[i] );
         f1.extra[slot] = next;
         delete f1.steps[slot][step.id];
      }
      else
      {
         if ( !f1.removed[slot] )
            f1.removed[slot] = {};
         f1.removed[slot][step.id] = true;
      }
      let order = [];
      let old = f1.order[slot] || [];
      for ( let i = 0; i < old.length; ++i )
         if ( old[i] != step.id )
            order.push( old[i] );
      f1.order[slot] = f1NormalizeOrder( slot, order );
      this.fillStepTree( slot );
      this.syncStepButtons( slot );
   }

   selectedStep( slot )
   {
      return this.stepFromNode( slot, this.stepTrees[slot].currentNode );
   }

   readStepOrder( slot )
   {
      let tree = this.stepTrees[slot];
      let order = [];
      for ( let i = 0; i < tree.numberOfChildren; ++i )
      {
         let step = this.stepFromNode( slot, tree.child( i ) );
         if ( step )
            order.push( step.id );
      }
      f1.order[slot] = f1NormalizeOrder( slot, order );
   }

   moveSelectedStep( slot, delta )
   {
      let tree = this.stepTrees[slot];
      let node = tree.currentNode;
      if ( !node )
         return;
      let from = tree.childIndex( node );
      if ( from < 0 )
         return;
      let to = from + delta;
      if ( to < 0 || to >= tree.numberOfChildren )
         return;
      tree.move( from, to );
      tree.currentNode = node;
      this.readStepOrder( slot );
      this.syncStepButtons( slot );
   }

   syncStepButtons( slot )
   {
      let tree = this.stepTrees[slot];
      let node = tree ? tree.currentNode : null;
      let index = node ? tree.childIndex( node ) : -1;
      let step = this.selectedStep( slot );
      if ( this.stepButton[slot] )
         this.stepButton[slot].enabled = step && f1StepInstalled( step ) ? true : false;
      if ( this.stepUpButton[slot] )
         this.stepUpButton[slot].enabled = index > 0;
      if ( this.stepDownButton[slot] )
         this.stepDownButton[slot].enabled = index >= 0 && index < tree.numberOfChildren - 1;
      if ( this.stepRemoveButton[slot] )
         this.stepRemoveButton[slot].enabled = step ? true : false;
   }

   openStep( slot, step )
   {
      try
      {
         let changed = f1OpenStep( slot, step, this.selectedView( slot ) );
         if ( changed )
         {
            if ( step.kind == "icon" )
            {
               step.title = f1.steps[slot][step.id].par.title || step.title;
               step.processId = f1.steps[slot][step.id].par.processId || step.processId;
            }
            this.fillStepTree( slot );
            let node = this.stepNodes[slot][step.id];
            if ( node )
               this.stepTrees[slot].currentNode = node;
            this.syncStepButtons( slot );
         }
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   restoreViews()
   {
      let dialog = this;
      f1WithViewSyncSuppressed( function()
      {
         for ( let i = 0; i < F1_SLOTS.length; ++i )
         {
            let slot = F1_SLOTS[i];
            try
            {
               dialog.lists[slot].getMainViews();
            }
            catch ( e )
            {
            }
            let id = f1.views[slot];
            if ( !id )
            {
               try
               {
                  dialog.lists[slot].currentView = new View;
               }
               catch ( e )
               {
               }
               continue;
            }
            try
            {
               let view = View.viewById( id );
               if ( view && !view.isNull )
                  dialog.lists[slot].currentView = view;
               else
               {
                  f1.views[slot] = "";
                  dialog.lists[slot].currentView = new View;
               }
            }
            catch ( e )
            {
            }
         }
      } );
   }

   selectedView( slot )
   {
      let view = this.lists[slot].currentView;
      if ( !view || view.isNull )
         return null;
      return view;
   }

   keepShoChannels()
   {
      // A checked Compose SHO would drop SII, Ha and OIII before StarX, so Post cannot find the star views.
      if ( f1.pre && f1.pre.steps && f1.pre.steps.composesho )
         f1.pre.steps.composesho.on = false;
      let node = this.phaseNodes.pre ? this.phaseNodes.pre.composesho : null;
      if ( node )
         node.checked = false;
   }

   saveFromControls()
   {
      for ( let s = 0; s < F1_SLOTS.length; ++s )
      {
         let slot = F1_SLOTS[s];
         let view = this.selectedView( slot );
         f1.views[slot] = view ? view.id : "";
         this.readStepOrder( slot );
         let steps = f1AllSteps( slot );
         for ( let i = 0; i < steps.length; ++i )
         {
            let step = steps[i];
            let node = this.stepNodes[slot][step.id];
            if ( !node )
               continue;
            if ( !f1StepInstalled( step ) )
               continue;
            f1.steps[slot][step.id].on = node.checked ? true : false;
         }
      }
      let phases = [ "pre", "post" ];
      for ( let p = 0; p < phases.length; ++p )
      {
         let name = phases[p];
         this.readPhaseOrder( name );
         let steps = f1PhaseAllSteps( name );
         for ( let i = 0; i < steps.length; ++i )
         {
            let step = steps[i];
            let node = this.phaseNodes[name][step.id];
            if ( !node || !f1PhaseStepInstalled( step ) || !f1[name].steps[step.id] )
               continue;
            f1[name].steps[step.id].on = node.checked ? true : false;
         }
      }
      f1WriteSettings();
   }

   refreshAfterProfile()
   {
      this.loading = true;
      try
      {
         for ( let s = 0; s < F1_SLOTS.length; ++s )
         {
            let slot = F1_SLOTS[s];
            this.fillStepTree( slot );
            this.syncStepButtons( slot );
         }
         this.fillPhaseTree( "pre" );
         this.fillPhaseTree( "post" );
         this.syncPhaseButtons( "pre" );
         this.syncPhaseButtons( "post" );
         this.restoreViews();
      }
      finally
      {
         this.loading = false;
      }
   }

   slotHasWork( slot )
   {
      let steps = f1OrderedSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let state = f1.steps[slot][steps[i].id];
         if ( state && state.on && f1StepInstalled( steps[i] ) )
            return true;
      }
      return false;
   }

   collectJobs()
   {
      let jobs = [];
      let seen = {};
      for ( let i = 0; i < F1_SLOTS.length; ++i )
      {
         let slot = F1_SLOTS[i];
         // A row with every step off is not a job, so a leftover image is not an issue.
         if ( !this.slotHasWork( slot ) )
            continue;
         // f1.views is source of truth after Pre (Compose RGB clears R/G/B there).
         let id = f1.views[slot];
         let view = id ? f1ViewById( id ) : null;
         if ( !view )
            continue;
         if ( seen[view.id] )
         {
            jobs.push( { slot: slot, view: view, duplicate: seen[view.id] } );
            continue;
         }
         seen[view.id] = slot;
         jobs.push( { slot: slot, view: view, duplicate: "" } );
      }
      return jobs;
   }

   phaseHasWork( name )
   {
      let steps = f1PhaseOrderedSteps( name );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1[name].steps[step.id];
         if ( state && state.on && f1PhaseStepInstalled( step ) )
            return true;
      }
      return false;
   }

   fillPresetCombo( selectName )
   {
      let want = f1NormalizePresetName( selectName ) || F1_LRGB_PRESET;
      this.preset_Combo.clear();
      let builtins = [ F1_LRGB_PRESET, F1_SHO_PRESET, F1_CLEAR_PRESET ];
      let index = 0;
      for ( let i = 0; i < builtins.length; ++i )
      {
         this.preset_Combo.addItem( builtins[i] );
         if ( builtins[i].toLowerCase() == want.toLowerCase() )
            index = i;
      }
      let list = f1ListPresets();
      for ( let i = 0; i < list.length; ++i )
      {
         this.preset_Combo.addItem( list[i] );
         if ( list[i].toLowerCase() == want.toLowerCase() )
            index = builtins.length + i;
      }
      if ( !f1IsBuiltinPreset( want ) )
      {
         let found = false;
         for ( let i = 0; i < list.length; ++i )
            if ( list[i].toLowerCase() == want.toLowerCase() )
               found = true;
         if ( !found )
         {
            this.preset_Combo.addItem( want );
            index = this.preset_Combo.numberOfItems - 1;
         }
      }
      this.preset_Combo.currentItem = index;
      try
      {
         this.preset_Combo.editText = want;
      }
      catch ( e )
      {
      }
   }

   currentPresetName()
   {
      let text = "";
      try
      {
         if ( this.preset_Combo.editEnabled && this.preset_Combo.editText != null )
            text = String( this.preset_Combo.editText );
      }
      catch ( e )
      {
      }
      if ( !text.replace( /^\s+|\s+$/g, "" ).length
           && this.preset_Combo.numberOfItems > 0
           && this.preset_Combo.currentItem >= 0 )
         text = this.preset_Combo.itemText( this.preset_Combo.currentItem );
      return f1NormalizePresetName( text );
   }

   savePreset()
   {
      try
      {
         this.saveFromControls();
         let name = this.currentPresetName();
         if ( !name || f1IsBuiltinPreset( name ) )
         {
            f1Message( "Type a preset name in the box (not " + F1_LRGB_PRESET + ", " + F1_SHO_PRESET + " or " + F1_CLEAR_PRESET + "), then click Save." );
            return;
         }
         let exists = false;
         let list = f1ListPresets();
         for ( let i = 0; i < list.length; ++i )
            if ( list[i].toLowerCase() == name.toLowerCase() )
            {
               exists = true;
               break;
            }
         let askText = exists
            ? ( "Overwrite preset \"" + name + "\" with the current settings?" )
            : ( "Save current settings as preset \"" + name + "\"?" );
         if ( !f1Confirm( askText ) )
            return;
         name = f1SaveNamedPreset( name, f1CollectProfile() );
         f1WriteSettings();
         this.fillPresetCombo( name );
         f1Message( "Preset saved: " + name, true );
      }
      catch ( e )
      {
         f1Message( f1ErrorText( e ) );
      }
   }

   loadPreset()
   {
      try
      {
         let name = this.currentPresetName() || F1_BUILTIN_PRESET;
         if ( !f1Confirm( "Load preset \"" + name + "\"? Current dialog settings will be replaced." ) )
            return;
         if ( f1IsBuiltinPreset( name ) )
         {
            f1ResetToDefaults( name );
            Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, name );
            this.refreshAfterProfile();
            f1WriteSettings();
            this.fillPresetCombo( name );
            f1Message( "Restored " + name + " settings.", true );
            return;
         }
         let profile = f1LoadNamedPreset( name );
         f1ApplyProfile( profile );
         this.refreshAfterProfile();
         f1WriteSettings();
         this.fillPresetCombo( name );
         f1Message( "Preset loaded: " + name, true );
      }
      catch ( e )
      {
         f1Message( f1ErrorText( e ) );
      }
   }

   deletePreset()
   {
      try
      {
         let name = this.currentPresetName();
         if ( !name || f1IsBuiltinPreset( name ) )
         {
            f1Message( F1_LRGB_PRESET + ", " + F1_SHO_PRESET + " and " + F1_CLEAR_PRESET + " cannot be deleted. Select a named preset first." );
            return;
         }
         if ( !f1Confirm( "Delete preset \"" + name + "\"? This cannot be undone." ) )
            return;
         f1DeleteNamedPreset( name );
         this.fillPresetCombo( F1_BUILTIN_PRESET );
         f1Message( "Preset deleted: " + name, true );
      }
      catch ( e )
      {
         f1Message( f1ErrorText( e ) );
      }
   }

   exportSettingsFile()
   {
      try
      {
         this.saveFromControls();
         let fd = new SaveFileDialog;
         fd.caption = "Export BatchProcessing_byHrast settings";
         fd.filters = [
            [ "BatchProcessing settings", "*.bpshrast" ],
            [ "JSON files", "*.json" ],
            [ "All files", "*" ]
         ];
         fd.overwritePrompt = true;
         if ( !fd.execute() )
            return;
         let path = fd.filePath;
         if ( !/\.(bpshrast|json)$/i.test( path ) )
            path += ".bpshrast";
         File.writeTextFile( path, JSON.stringify( f1CollectProfile(), null, 2 ) );
         f1Message( "Settings exported:\n" + path, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   importSettingsFile()
   {
      try
      {
         let fd = new OpenFileDialog;
         fd.caption = "Import BatchProcessing_byHrast settings";
         fd.filters = [
            [ "BatchProcessing settings", "*.bpshrast" ],
            [ "JSON files", "*.json" ],
            [ "All files", "*" ]
         ];
         if ( !fd.execute() )
            return;
         let text = File.readTextFile( fd.filePath );
         let profile = JSON.parse( text );
         f1ApplyProfile( profile );
         this.refreshAfterProfile();
         f1WriteSettings();
         f1Message( "Settings imported:\n" + fd.filePath, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   runPhaseChoice( name, done, failed )
   {
      let label = name == "pre" ? "Pre" : "Post";
      console.noteln( "<end><cbr><br>===== " + label + " =====" );
      let start = 0;
      while ( true )
      {
         try
         {
            f1RunPhase( name, this, start );
            if ( name == "pre" )
               this.restoreViews();
            done.push( label );
            return "ok";
         }
         catch ( e )
         {
            if ( f1UserAbort() )
            {
               failed.push( label + " · aborted by user" );
               return "abort";
            }
            let info = e && e.phaseFailure ? e.phaseFailure : null;
            if ( !info )
            {
               failed.push( f1ErrorText( e ) );
               return "stop";
            }
            let ask = new F1PhaseFailureDialog( info );
            let accepted = false;
            try
            {
               accepted = ask.execute() ? true : false;
            }
            catch ( ex )
            {
               accepted = false;
            }
            if ( accepted && ask.choice == "continue" )
            {
               start = info.stepIndex + 1;
               continue;
            }
            failed.push( info.message );
            f1OfferPhaseRemainder( info );
            return "stop";
         }
      }
   }

   run()
   {
      this.saveFromControls();
      if ( f1SeparatesNarrowband() )
         this.keepShoChannels();
      let hasPre = this.phaseHasWork( "pre" );
      let hasPost = this.phaseHasWork( "post" );
      let jobs = this.collectJobs();
      if ( jobs.length == 0 && !hasPre && !hasPost )
      {
         f1Message( "No image selected and Pre/Post are empty. An empty row is skipped." );
         return;
      }

      console.show();
      console.abortEnabled = true;
      this.run_Button.enabled = false;
      f1.processSeed = null;
      let done = [];
      let failed = [];
      let aborted = false;
      let skipPost = false;
      let skipFilters = false;
      try
      {
         if ( hasPre )
         {
            let preState = this.runPhaseChoice( "pre", done, failed );
            if ( preState == "abort" )
               aborted = true;
            else if ( preState == "stop" )
               skipFilters = true;
         }

         if ( !aborted && !skipFilters )
         {
            jobs = this.collectJobs();
            {
               let labels = [];
               for ( let j = 0; j < jobs.length; ++j )
               {
                  if ( jobs[j].duplicate )
                     labels.push( jobs[j].slot + "(dup)" );
                  else
                     labels.push( jobs[j].slot );
               }
               console.noteln( "<end><cbr><br>* Filter jobs: "
                               + ( labels.length ? labels.join( ", " ) : "(none)" ) );
            }
            let jobsBySlot = {};
            let pending = [];
            for ( let i = 0; i < jobs.length; ++i )
            {
               let job = jobs[i];
               jobsBySlot[job.slot] = job;
               if ( job.duplicate )
               {
                  failed.push( job.slot + " · skipped: the same image is already in row " + job.duplicate );
                  continue;
               }
               try
               {
                  f1RunSlot( job.slot, job.view, 0 );
                  done.push( job.slot );
               }
               catch ( e )
               {
                  if ( f1UserAbort() )
                  {
                     aborted = true;
                     failed.push( job.slot + " · aborted by user" );
                     break;
                  }
                  let info = f1SlotFailureFrom( e );
                  if ( info && info.slot == job.slot )
                     pending.push( info );
                  else
                     failed.push( f1ErrorText( e ) );
               }
               CoreApplication.processEvents();
               if ( f1UserAbort() )
               {
                  aborted = true;
                  failed.push( "Aborted by user." );
                  break;
               }
            }
            while ( pending.length && !aborted )
            {
               let ask = new F1FailureChoiceDialog( pending );
               let accepted = false;
               try
               {
                  accepted = ask.execute() ? true : false;
               }
               catch ( e )
               {
                  accepted = false;
               }
               if ( !accepted || ask.choice != "continue" )
               {
                  skipPost = true;
                  for ( let p = 0; p < pending.length; ++p )
                     failed.push( pending[p].message );
                  f1OfferRemainderIcons( pending, jobsBySlot );
                  break;
               }
               let next = [];
               for ( let p = 0; p < pending.length; ++p )
               {
                  let info = pending[p];
                  let job = jobsBySlot[info.slot];
                  if ( !job )
                  {
                     failed.push( info.message );
                     continue;
                  }
                  try
                  {
                     f1RunSlot( info.slot, job.view, info.stepIndex + 1 );
                     if ( done.indexOf( info.slot ) < 0 )
                        done.push( info.slot );
                  }
                  catch ( e )
                  {
                     if ( f1UserAbort() )
                     {
                        aborted = true;
                        failed.push( info.slot + " · aborted by user" );
                        break;
                     }
                     let again = f1SlotFailureFrom( e );
                     if ( again && again.slot == info.slot )
                        next.push( again );
                     else
                        failed.push( f1ErrorText( e ) );
                  }
                  if ( aborted || f1UserAbort() )
                  {
                     aborted = true;
                     break;
                  }
               }
               pending = next;
            }
         }

         if ( hasPost && !aborted && !skipPost && !skipFilters )
            this.runPhaseChoice( "post", done, failed );
      }
      catch ( e )
      {
         let message = f1ErrorText( e );
         if ( f1UserAbort() )
            failed.push( "Aborted by user." );
         else if ( failed.indexOf( message ) < 0 )
            failed.push( message );
      }
      finally
      {
         f1.processSeed = null;
         this.run_Button.enabled = true;
         try
         {
            this.saveFromControls();
         }
         catch ( e )
         {
         }
      }

      if ( failed.length > 0 )
         f1Message( ( done.length > 0 ? ( "Processed: " + done.join( ", " ) + ".\n" ) : "" )
                    + "Issues:\n" + failed.join( "\n" ) );
      else
         f1Message( "Processed: " + done.join( ", " ) + ".", true );
   }
};

// ----------------------------------------------------------------------------

function main()
{
   f1MaybeFactoryResetFromFlag();
   f1LoadSettings();
   f1LoadDatabase();
   let dialog = new BatchProcessingDialog();
   dialog.execute();
}

main();
