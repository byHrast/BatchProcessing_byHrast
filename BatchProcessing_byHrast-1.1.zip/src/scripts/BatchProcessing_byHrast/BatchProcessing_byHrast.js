// ----------------------------------------------------------------------------
// BatchProcessing_byHrast
//
// The row selects the filter. An empty row is skipped.
// Settings are a dialog inside the script, separate for each filter.
// Names are the full process names. ScreenTransferFunction is last.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    BatchProcessing_byHrast : Batch Processing > BatchProcessing_byHrast

#feature-info  BatchProcessing_byHrast. One row per filter: Ha, OIII, SII, L, R, G, B and RGB. \
               Settings stay inside the script and apply only to that filter.

#define USE_SOLVER_LIBRARY
#define SETTINGS_MODULE "BatchProcessing_byHrast"

#include "../ImageSolver/ImageSolver.js"
#include "EarlyCalibrationCurves.jsh"

#define SETTINGS_PREFIX "Faza1/"

// ----------------------------------------------------------------------------

var F1_SLOTS = [ "Ha", "OIII", "SII", "L", "R", "G", "B", "RGB" ];

var F1_FILTER_STEPS = [
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "blurx2", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_RGB_STEPS = [
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "spcc", title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { id: "blurx", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_WAVE = { Ha: 656.3, OIII: 500.7, SII: 671.6 };
var F1_BAND = { Ha: 3.0, OIII: 3.0, SII: 3.0 };

var f1 = {
   views: { Ha: "", OIII: "", SII: "", L: "", R: "", G: "", B: "", RGB: "" },
   steps: {},
   solverKeep: {},
   db: { L: [], R: [], G: [], B: [], Q: [] },
   curveByName: {}
};

function f1Format( value, digits )
{
   if ( value == null || !isFinite( value ) )
      return "";
   return format( "%." + digits + "f", value );
}

function f1Parse( text )
{
   let trimmed = String( text == null ? "" : text ).trim().replace( ",", "." );
   if ( trimmed.length == 0 )
      return null;
   let value = Number( trimmed );
   return isFinite( value ) ? value : null;
}

function f1ReadBool( key, fallback )
{
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.Boolean );
   if ( Settings.lastReadOK )
      return value ? true : false;
   return fallback;
}

function f1ReadString( key, fallback )
{
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.String );
   if ( Settings.lastReadOK && typeof value == "string" )
      return value;
   return fallback;
}

function f1StepsFor( slot )
{
   return slot == "RGB" ? F1_RGB_STEPS : F1_FILTER_STEPS;
}

function f1StepInstalled( step )
{
   switch ( step.kind )
   {
   case "blurx":   return typeof BlurXTerminator == "function";
   case "solver":  return typeof ImageSolver == "function";
   case "spfc":    return typeof SpectrophotometricFluxCalibration == "function";
   case "mgc":     return typeof MultiscaleGradientCorrection == "function";
   case "spcc":    return typeof SpectrophotometricColorCalibration == "function";
   case "noisex":  return typeof NoiseXTerminator == "function";
   case "starx":   return typeof StarXTerminator == "function";
   case "screen":  return typeof ScreenTransferFunction == "function";
   case "stretch": return typeof MultiscaleAdaptiveStretch == "function";
   }
   return true;
}

function f1Narrow( slot )
{
   return slot == "Ha" || slot == "OIII" || slot == "SII";
}

function f1DefaultParams( slot, step )
{
   if ( step.kind == "blurx" )
   {
      let sharpen = step.mode == "sharpen";
      return {
         correctOnly: !sharpen,
         sharpenStars: sharpen ? 0.10 : 0,
         starHalos: sharpen ? 0.05 : 0,
         sharpenNonstellar: sharpen ? 0.70 : 0,
         overlap: 0.20
      };
   }
   if ( step.kind == "spfc" )
   {
      let narrow = f1Narrow( slot );
      let gray = f1GrayName( slot );
      return {
         narrowband: narrow,
         wavelength: narrow ? F1_WAVE[slot] : 656.3,
         bandwidth: narrow ? F1_BAND[slot] : 3.0,
         grayName: gray,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   }
   if ( step.kind == "mgc" )
      return {
         scale: 1024,
         separation: 3,
         smoothness: 1.0,
         grayFilter: slot == "RGB" ? "L" : slot,
         showModel: true
      };
   if ( step.kind == "spcc" )
      return {
         narrowband: false,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   if ( step.kind == "noisex" )
      return { denoise: 0.70, detail: 0.15 };
   if ( step.kind == "starx" )
      return { outputStars: false, unscreen: false };
   if ( step.kind == "screen" )
      return { linked: true, shadows: -2.8, target: 0.25 };
   if ( step.kind == "stretch" )
      return {
         targetBackground: 0.15,
         aggressiveness: 0.70,
         dynamicRange: 0.40,
         contrastRecovery: true,
         scaleSeparation: 1024,
         intensity: 1.00,
         saturation: false,
         saturationAmount: 0.75,
         saturationBoost: 0.50
      };
   return {};
}

function f1ApplySavedParams( slot, step, state )
{
   let raw = f1ReadString( "par_" + slot + "_" + step.id, "" );
   if ( !raw )
      return;
   try
   {
      let saved = JSON.parse( raw );
      if ( !saved || typeof saved != "object" )
         return;
      for ( let key in saved )
         if ( saved[key] != null )
            state.par[key] = saved[key];
   }
   catch ( e )
   {
   }
}

function f1GrayName( slot )
{
   if ( slot == "R" )
      return EC_redFilterName;
   if ( slot == "G" )
      return EC_greenFilterName;
   if ( slot == "B" )
      return EC_blueFilterName;
   return EC_grayFilterName;
}

function f1GrayChannel( slot )
{
   if ( slot == "R" || slot == "G" || slot == "B" )
      return slot;
   return "L";
}

function f1AddCurve( channel, name, data )
{
   if ( !f1.db[channel] || !name || !data || f1.curveByName[name] )
      return;
   f1.db[channel].push( name );
   f1.curveByName[name] = data;
}

function f1LoadDatabase()
{
   f1.db = { L: [], R: [], G: [], B: [], Q: [] };
   f1.curveByName = {};
   let path = "";
   let dirs = [ "PXI_DOCDIR", "PXI_BINDIR", "PXI_SRCDIR" ];
   for ( let i = 0; i < dirs.length && !path; ++i )
   {
      let dir = System.getEnvironmentVariable( dirs[i] );
      if ( dir )
      {
         let candidate = File.extractDrive( dir ) + File.extractDirectory( dir.replace( /[\/\\]+$/, "" ) ) + "/library/filters.xspd";
         if ( File.exists( candidate ) )
            path = candidate;
      }
   }
   if ( !path && File.exists( "C:/Program Files/PixInsight/library/filters.xspd" ) )
      path = "C:/Program Files/PixInsight/library/filters.xspd";
   if ( path )
   {
      let text = File.readTextFile( path );
      let re = /<Filter name="([^"]+)" channel="([^"]+)"[^>]*?\sdata="([^"]*)"/g;
      for ( let match = re.exec( text ); match; match = re.exec( text ) )
         f1AddCurve( match[2], match[1], match[3] );
   }
   f1AddCurve( "L", EC_grayFilterName, EC_grayFilterTrCurve );
   f1AddCurve( "R", EC_redFilterName, EC_redFilterTrCurve );
   f1AddCurve( "G", EC_greenFilterName, EC_greenFilterTrCurve );
   f1AddCurve( "B", EC_blueFilterName, EC_blueFilterTrCurve );
   f1AddCurve( "Q", EC_deviceQECurveName, EC_deviceQECurve );
   let channels = [ "L", "R", "G", "B", "Q" ];
   for ( let i = 0; i < channels.length; ++i )
      f1.db[channels[i]].sort();
}

function f1Curve( name, fallback )
{
   if ( name && f1.curveByName[name] )
      return f1.curveByName[name];
   return fallback;
}

function f1InitSteps()
{
   f1.steps = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.steps[slot] = {};
      let steps = f1StepsFor( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         f1.steps[slot][step.id] = { on: true, par: f1DefaultParams( slot, step ) };
      }
   }
}

function f1LoadSettings()
{
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.views[slot] = f1ReadString( "view" + slot, "" );
      let steps = f1StepsFor( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         state.on = f1ReadBool( "on_" + slot + "_" + step.id, true );
         f1ApplySavedParams( slot, step, state );
      }
   }
}

function f1WriteSettings()
{
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      Settings.write( SETTINGS_PREFIX + "view" + slot, DataType.String, f1.views[slot] );
      let steps = f1StepsFor( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         Settings.write( SETTINGS_PREFIX + "on_" + slot + "_" + step.id, DataType.Boolean, state.on );
         Settings.write( SETTINGS_PREFIX + "par_" + slot + "_" + step.id, DataType.String, JSON.stringify( state.par ) );
      }
   }
}

function f1Message( text, info )
{
   ( new MessageBox( text, "BatchProcessing_byHrast", info ? StdIcon.Information : StdIcon.Warning, StdButton.Ok ) ).execute();
}

function f1Set( process, name, value )
{
   try
   {
      process[name] = value;
      return true;
   }
   catch ( e )
   {
      return false;
   }
}

function f1Need( process, name, value )
{
   if ( !f1Set( process, name, value ) )
      throw new Error( "Parameter was not accepted: " + name );
}

function f1RequireModule( name, present )
{
   if ( !present )
      throw new Error( name + " is not installed." );
}

function f1BuildBlurX( par )
{
   f1RequireModule( "BlurXTerminator", typeof BlurXTerminator == "function" );
   let process = new BlurXTerminator;
   let correct = par.correctOnly ? true : false;
   f1Set( process, "ml_version", 0 );
   f1Need( process, "correct_only", correct );
   f1Set( process, "sharpen_stars", correct ? 0 : par.sharpenStars );
   f1Set( process, "adjust_star_halos", correct ? 0 : par.starHalos );
   f1Set( process, "nonstellar_diameter", 0.0 );
   f1Set( process, "auto_nonstellar_psf", true );
   f1Set( process, "sharpen_nonstellar", correct ? 0 : par.sharpenNonstellar );
   f1Set( process, "lunar_planetary", false );
   f1Set( process, "overlap", par.overlap );
   return process;
}

function f1FillFlux( process, par )
{
   let grayName = par.grayName || EC_grayFilterName;
   f1Need( process, "narrowbandMode", par.narrowband ? true : false );
   f1Need( process, "grayFilterTrCurve", f1Curve( grayName, EC_grayFilterTrCurve ) );
   f1Need( process, "grayFilterName", grayName );
   f1Need( process, "grayFilterWavelength", par.wavelength );
   f1Need( process, "grayFilterBandwidth", par.bandwidth );
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "redFilterWavelength", 656.3 );
   f1Set( process, "redFilterBandwidth", 3.0 );
   f1Set( process, "greenFilterWavelength", 500.7 );
   f1Set( process, "greenFilterBandwidth", 3.0 );
   f1Set( process, "blueFilterWavelength", 500.7 );
   f1Set( process, "blueFilterBandwidth", 3.0 );
   f1Set( process, "broadbandIntegrationStepSize", 0.5 );
   f1Set( process, "narrowbandIntegrationSteps", 10 );
   f1Set( process, "rejectionLimit", 0.3 );
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "minMagnitude", 0 );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "psfStructureLayers", 5 );
   f1Set( process, "saturationThreshold", 0.75 );
   f1Set( process, "saturationRelative", true );
   f1Set( process, "saturationShrinkFactor", 0.10 );
   f1Set( process, "psfNoiseLayers", 1 );
   f1Set( process, "psfHotPixelFilterRadius", 1 );
   f1Set( process, "psfNoiseReductionFilterRadius", 0 );
   f1Set( process, "psfMinStructureSize", 0 );
   f1Set( process, "psfMinSNR", 40 );
   f1Set( process, "psfAllowClusteredSources", false );
   f1Set( process, "psfGrowth", 1.75 );
   f1Set( process, "psfMaxStars", 24576 );
   f1Set( process, "psfSearchTolerance", 4 );
   f1Set( process, "psfChannelSearchTolerance", 2 );
   f1Set( process, "generateGraphs", true );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   try
   {
      process.psfType = SpectrophotometricFluxCalibration.PSFType_Auto;
   }
   catch ( e )
   {
   }
}

function f1BuildFlux( par )
{
   f1RequireModule( "SpectrophotometricFluxCalibration", typeof SpectrophotometricFluxCalibration == "function" );
   let process = new SpectrophotometricFluxCalibration;
   f1FillFlux( process, par );
   return process;
}

function f1BuildGradient( par )
{
   f1RequireModule( "MultiscaleGradientCorrection", typeof MultiscaleGradientCorrection == "function" );
   let process = new MultiscaleGradientCorrection;
   f1Need( process, "useMARSDatabase", true );
   f1Need( process, "grayMARSFilter", par.grayFilter );
   f1Need( process, "redMARSFilter", "R" );
   f1Need( process, "greenMARSFilter", "G" );
   f1Need( process, "blueMARSFilter", "B" );
   f1Set( process, "referenceImageId", "" );
   f1Need( process, "gradientScale", Math.round( par.scale ) );
   f1Need( process, "structureSeparation", Math.round( par.separation ) );
   f1Need( process, "modelSmoothness", par.smoothness );
   f1Set( process, "minFieldRatio", 0.017 );
   f1Set( process, "maxFieldRatio", 0.167 );
   f1Set( process, "enforceFieldLimits", true );
   f1Set( process, "scaleFactorRK", 1 );
   f1Set( process, "scaleFactorG", 1 );
   f1Set( process, "scaleFactorB", 1 );
   f1Set( process, "showGradientModel", par.showModel ? true : false );
   f1Set( process, "command", "" );
   return process;
}

function f1BuildColor( par )
{
   f1RequireModule( "SpectrophotometricColorCalibration", typeof SpectrophotometricColorCalibration == "function" );
   let process = new SpectrophotometricColorCalibration;
   f1Set( process, "narrowbandMode", par.narrowband ? true : false );
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "generateGraphs", false );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   return process;
}

function f1BuildNoise( par )
{
   f1RequireModule( "NoiseXTerminator", typeof NoiseXTerminator == "function" );
   let process = new NoiseXTerminator;
   f1Need( process, "denoise", par.denoise );
   f1Need( process, "detail", par.detail );
   return process;
}

function f1BuildStars( par )
{
   f1RequireModule( "StarXTerminator", typeof StarXTerminator == "function" );
   let process = new StarXTerminator;
   f1Need( process, "output_stars", par.outputStars ? true : false );
   f1Set( process, "unscreen", par.outputStars && par.unscreen ? true : false );
   return process;
}

function f1CopyRow( row )
{
   return [ row[0], row[1], row[2], row[3], row[4] ];
}

function f1StretchRow( median, mad, channel, inverted, shadowsClipping, targetBackground )
{
   let med = median.at( channel );
   let dev = mad.at( channel );
   if ( !inverted )
   {
      let c0 = ( 1 + dev != 1 ) ? Math.range( med + shadowsClipping * dev, 0.0, 1.0 ) : 0.0;
      let midtone = Math.mtf( targetBackground, med - c0 );
      return [ c0, 1, midtone, 0, 1 ];
   }
   let c1 = ( 1 + dev != 1 ) ? Math.range( med - shadowsClipping * dev, 0.0, 1.0 ) : 1.0;
   let midtone = Math.mtf( c1 - med, targetBackground );
   return [ 0, c1, midtone, 0, 1 ];
}

function f1MakeScreen( view, par )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let linked = par.linked ? true : false;
   let shadowsClipping = isFinite( par.shadows ) ? par.shadows : -2.8;
   let targetBackground = isFinite( par.target ) ? par.target : 0.25;
   let process = new ScreenTransferFunction;
   let rows = [
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ]
   ];
   if ( view && view.image )
   {
      let color = view.image.isColor;
      let count = color ? 3 : 1;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );
      if ( linked || !color )
      {
         let inverted = 0;
         for ( let c = 0; c < count; ++c )
            if ( median.at( c ) > 0.5 )
               ++inverted;
         let row;
         if ( inverted < count )
         {
            let c0 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               if ( 1 + mad.at( c ) != 1 )
                  c0 += median.at( c ) + shadowsClipping * mad.at( c );
               mid += median.at( c );
            }
            c0 = Math.range( c0 / count, 0.0, 1.0 );
            row = [ c0, 1, Math.mtf( targetBackground, mid / count - c0 ), 0, 1 ];
         }
         else
         {
            let c1 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               mid += median.at( c );
               if ( 1 + mad.at( c ) != 1 )
                  c1 += median.at( c ) - shadowsClipping * mad.at( c );
               else
                  c1 += 1;
            }
            c1 = Math.range( c1 / count, 0.0, 1.0 );
            row = [ 0, c1, Math.mtf( c1 - mid / count, targetBackground ), 0, 1 ];
         }
         let limit = color ? 3 : 1;
         for ( let c = 0; c < limit; ++c )
            rows[c] = f1CopyRow( row );
      }
      else
      {
         for ( let c = 0; c < count; ++c )
            rows[c] = f1StretchRow( median, mad, c, median.at( c ) >= 0.5, shadowsClipping, targetBackground );
      }
   }
   process.STF = rows;
   return process;
}

function f1ResetScreen( view )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let process = new ScreenTransferFunction;
   let row = [ 0, 1, 0.5, 0, 1 ];
   process.STF = [ row.slice( 0 ), row.slice( 0 ), row.slice( 0 ), row.slice( 0 ) ];
   if ( process.executeOn( view, false ) === false )
      throw new Error( "ScreenTransferFunction failed." );
}

function f1BuildStretch( par )
{
   f1RequireModule( "MultiscaleAdaptiveStretch", typeof MultiscaleAdaptiveStretch == "function" );
   let process = new MultiscaleAdaptiveStretch;
   f1Need( process, "targetBackground", par.targetBackground );
   f1Need( process, "aggressiveness", par.aggressiveness );
   f1Need( process, "dynamicRangeCompression", par.dynamicRange );
   f1Need( process, "contrastRecovery", par.contrastRecovery ? true : false );
   f1Need( process, "scaleSeparation", Math.round( par.scaleSeparation ) );
   f1Need( process, "contrastRecoveryIntensity", par.intensity );
   f1Need( process, "saturationEnabled", par.saturation ? true : false );
   f1Need( process, "saturationAmount", par.saturationAmount );
   f1Need( process, "saturationBoost", par.saturationBoost );
   f1Set( process, "previewLargeScale", false );
   f1Set( process, "backgroundROIEnabled", false );
   return process;
}

function f1Build( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( step.kind == "blurx" )
      return f1BuildBlurX( par );
   if ( step.kind == "spfc" )
      return f1BuildFlux( par );
   if ( step.kind == "mgc" )
      return f1BuildGradient( par );
   if ( step.kind == "spcc" )
      return f1BuildColor( par );
   if ( step.kind == "noisex" )
      return f1BuildNoise( par );
   if ( step.kind == "starx" )
      return f1BuildStars( par );
   if ( step.kind == "screen" )
      return f1MakeScreen( view, par );
   if ( step.kind == "stretch" )
      return f1BuildStretch( par );
   return null;
}

function f1OpenSolver( slot, view )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   if ( typeof ImageSolverDialog != "function" )
      throw new Error( "ImageSolver dialog is not available." );
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      if ( view )
         solver.initialize( view.window, false /*prioritizeSettings*/ );
      solver.solverCfg.useActive = true;
   }
   let gui = new ImageSolverDialog( solver.solverCfg, solver.metadata, true /*showTargetImage*/ );
   if ( gui.execute() )
      f1.solverKeep[slot] = solver;
}

function f1OpenStep( slot, step, view )
{
   if ( step.kind == "solver" )
   {
      f1OpenSolver( slot, view );
      return false;
   }
   let gui = new FazaSetupDialog( slot, step, f1.steps[slot][step.id].par );
   return gui.execute() ? true : false;
}

function f1Solve( window, slot )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   console.writeln( "<end><cbr><br>ImageSolver" );
   console.flush();
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      solver.initialize( window, false /*prioritizeSettings*/ );
   }
   solver.solverCfg.useActive = true;
   window.bringToFront();
   solver.solveImage( window );
   console.writeln( window.astrometricSolutionSummary().trim() );
}

function f1Execute( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( step.kind == "screen" )
   {
      console.writeln( "<end><cbr><br>ScreenTransferFunction  "
                       + ( par.linked ? "linked channels" : "channels separate" ) );
      console.flush();
      let process = f1MakeScreen( view, par );
      if ( process.executeOn( view, false ) === false )
         throw new Error( "ScreenTransferFunction failed." );
      return;
   }
   if ( step.kind == "spcc" && ( !view.image || !view.image.isColor ) )
      throw new Error( "SpectrophotometricColorCalibration needs a three-channel image." );
   console.writeln( "<end><cbr><br>" + step.title );
   console.flush();
   let instance = f1Build( slot, step, view );
   if ( !instance )
      throw new Error( step.title + " is not ready." );
   if ( instance.executeOn( view ) === false )
      throw new Error( step.title + " failed." );
   if ( step.kind == "stretch" )
      f1ResetScreen( view );
}

function f1RunSlot( slot, view )
{
   let window = view.window;
   console.noteln( "<end><cbr><br>* " + slot + ": " + view.id );
   console.flush();
   let steps = f1StepsFor( slot );
   let ran = false;
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1.steps[slot][step.id];
      if ( !state.on )
         continue;
      if ( !f1StepInstalled( step ) )
      {
         console.warningln( "<end><cbr>** " + step.title + " is not installed. Step skipped." );
         continue;
      }
      ran = true;
      if ( step.kind == "solver" )
         f1Solve( window, slot );
      else
         f1Execute( slot, step, view );
      CoreApplication.processEvents();
   }
   if ( !ran )
      console.writeln( "No enabled steps." );
   console.noteln( "<end><cbr>* " + slot + " done: " + view.id );
}

// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------

var FazaSetupDialog = class extends Dialog
{
   constructor( slot, step, par )
   {
      super();
      this.slot = slot;
      this.step = step;
      this.par = par;
      this.windowTitle = slot + "  " + step.title;
      this.userResizable = true;
      let dialog = this;
      let body = new VerticalSizer;
      body.spacing = 6;
      body.margin = 8;

      if ( step.kind == "blurx" )
         this.buildBlurX( body );
      else if ( step.kind == "spfc" )
         this.buildFlux( body );
      else if ( step.kind == "mgc" )
         this.buildGradient( body );
      else if ( step.kind == "spcc" )
         this.buildColor( body );
      else if ( step.kind == "noisex" )
         this.buildNoise( body );
      else if ( step.kind == "starx" )
         this.buildStars( body );
      else if ( step.kind == "screen" )
         this.buildScreen( body );
      else if ( step.kind == "stretch" )
         this.buildStretch( body );

      let okButton = new PushButton( this );
      okButton.text = "OK";
      okButton.defaultButton = true;
      okButton.onClick = function()
      {
         if ( dialog.readBack() )
            dialog.ok();
      };
      let cancelButton = new PushButton( this );
      cancelButton.text = "Cancel";
      cancelButton.onClick = function()
      {
         dialog.cancel();
      };
      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( okButton );
      buttons.add( cancelButton );
      body.addSpacing( 8 );
      body.add( buttons );
      this.sizer = body;
      this.setScaledMinWidth( 560 );
   }

   label( text, width )
   {
      let item = new Label( this );
      item.text = text;
      item.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      item.setScaledFixedWidth( width || 230 );
      return item;
   }

   edit( value, digits )
   {
      let item = new Edit( this );
      item.text = f1Format( value, digits );
      item.setScaledFixedWidth( 90 );
      return item;
   }

   row( caption, control )
   {
      let line = new HorizontalSizer;
      line.spacing = 6;
      line.add( this.label( caption ) );
      line.add( control );
      line.addStretch();
      let box = new Control( this );
      box.sizer = line;
      return box;
   }

   namesFor( channel, selected )
   {
      let items = f1.db[channel] ? f1.db[channel].slice( 0 ) : [];
      if ( selected && items.indexOf( selected ) < 0 )
         items.unshift( selected );
      if ( items.length == 0 && selected )
         items.push( selected );
      return items;
   }

   combo( channel, selected )
   {
      let box = new ComboBox( this );
      let items = this.namesFor( channel, selected );
      for ( let i = 0; i < items.length; ++i )
         box.addItem( items[i] );
      let index = 0;
      for ( let i = 0; i < items.length; ++i )
         if ( items[i] == selected )
            index = i;
      if ( box.numberOfItems > 0 )
         box.currentItem = index;
      box.setScaledMinWidth( 280 );
      return box;
   }

   chosen( box )
   {
      if ( !box || box.numberOfItems < 1 || box.currentItem < 0 )
         return "";
      return box.itemText( box.currentItem );
   }

   buildBlurX( body )
   {
      this.correct_Check = new CheckBox( this );
      this.correct_Check.text = "Correct Only";
      this.correct_Check.checked = this.par.correctOnly ? true : false;
      this.stars_Edit = this.edit( this.par.sharpenStars, 2 );
      this.halos_Edit = this.edit( this.par.starHalos, 2 );
      this.nonstellar_Edit = this.edit( this.par.sharpenNonstellar, 2 );
      this.overlap_Edit = this.edit( this.par.overlap, 2 );
      let dialog = this;
      let apply = function()
      {
         let on = dialog.correct_Check.checked;
         dialog.stars_Edit.enabled = !on;
         dialog.halos_Edit.enabled = !on;
         dialog.nonstellar_Edit.enabled = !on;
      };
      this.correct_Check.onCheck = apply;
      apply();
      body.add( this.correct_Check );
      body.add( this.row( "Sharpen Stars", this.stars_Edit ) );
      body.add( this.row( "Adjust Star Halos", this.halos_Edit ) );
      body.add( this.row( "Sharpen Nonstellar", this.nonstellar_Edit ) );
      body.add( this.row( "Overlap", this.overlap_Edit ) );
   }

   buildFlux( body )
   {
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = this.par.narrowband ? true : false;
      this.wave_Edit = this.edit( this.par.wavelength, 1 );
      this.band_Edit = this.edit( this.par.bandwidth, 1 );
      this.sensor_Combo = this.combo( "Q", this.par.sensorName );
      this.gray_Combo = null;
      this.red_Combo = null;
      this.green_Combo = null;
      this.blue_Combo = null;
      this.waveRow = this.row( "Wavelength", this.wave_Edit );
      this.bandRow = this.row( "Bandwidth", this.band_Edit );
      this.filterRows = [];
      if ( this.slot == "RGB" )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else if ( this.slot == "R" )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
      }
      else if ( this.slot == "G" )
      {
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
      }
      else if ( this.slot == "B" )
      {
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else
      {
         this.gray_Combo = this.combo( f1GrayChannel( this.slot ), this.par.grayName );
         this.filterRows.push( this.row( "Gray filter", this.gray_Combo ) );
      }
      let dialog = this;
      let apply = function( resize )
      {
         let on = dialog.narrow_Check.checked;
         if ( on )
         {
            dialog.waveRow.show();
            dialog.bandRow.show();
         }
         else
         {
            dialog.waveRow.hide();
            dialog.bandRow.hide();
         }
         for ( let i = 0; i < dialog.filterRows.length; ++i )
         {
            if ( on )
               dialog.filterRows[i].hide();
            else
               dialog.filterRows[i].show();
         }
         if ( resize )
            dialog.adjustToContents();
      };
      this.narrow_Check.onCheck = function()
      {
         apply( true );
      };
      body.add( this.narrow_Check );
      body.add( this.waveRow );
      body.add( this.bandRow );
      for ( let i = 0; i < this.filterRows.length; ++i )
         body.add( this.filterRows[i] );
      body.add( this.row( "QE curve", this.sensor_Combo ) );
      apply( false );
   }

   buildGradient( body )
   {
      this.scale_Edit = this.edit( this.par.scale, 0 );
      this.separation_Edit = this.edit( this.par.separation, 0 );
      this.smooth_Edit = this.edit( this.par.smoothness, 2 );
      this.mars_Combo = new ComboBox( this );
      let mars = [ "Ha", "OIII", "SII", "L", "R", "G", "B" ];
      if ( mars.indexOf( this.par.grayFilter ) < 0 )
         mars.unshift( this.par.grayFilter );
      for ( let i = 0; i < mars.length; ++i )
         this.mars_Combo.addItem( mars[i] );
      let index = 0;
      for ( let i = 0; i < mars.length; ++i )
         if ( mars[i] == this.par.grayFilter )
            index = i;
      this.mars_Combo.currentItem = index;
      this.show_Check = new CheckBox( this );
      this.show_Check.text = "Show gradient model";
      this.show_Check.checked = this.par.showModel ? true : false;
      body.add( this.row( "Gradient scale", this.scale_Edit ) );
      body.add( this.row( "Structure separation", this.separation_Edit ) );
      body.add( this.row( "Model smoothness", this.smooth_Edit ) );
      body.add( this.row( "Gray filter", this.mars_Combo ) );
      if ( this.slot == "RGB" )
      {
         let note = new Label( this );
         note.wordWrapping = true;
         note.text = "Red, Green and Blue use the Red filter, Green filter and Blue filter. Gray filter above is the gray reference.";
         body.add( note );
      }
      body.add( this.show_Check );
   }

   buildColor( body )
   {
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = this.par.narrowband ? true : false;
      this.red_Combo = this.combo( "R", this.par.redName );
      this.green_Combo = this.combo( "G", this.par.greenName );
      this.blue_Combo = this.combo( "B", this.par.blueName );
      this.sensor_Combo = this.combo( "Q", this.par.sensorName );
      body.add( this.narrow_Check );
      body.add( this.row( "Red filter", this.red_Combo ) );
      body.add( this.row( "Green filter", this.green_Combo ) );
      body.add( this.row( "Blue filter", this.blue_Combo ) );
      body.add( this.row( "QE curve", this.sensor_Combo ) );
   }

   buildNoise( body )
   {
      this.denoise_Edit = this.edit( this.par.denoise, 2 );
      this.detail_Edit = this.edit( this.par.detail, 2 );
      body.add( this.row( "Denoise", this.denoise_Edit ) );
      body.add( this.row( "Detail", this.detail_Edit ) );
   }

   buildStars( body )
   {
      this.stars_Check = new CheckBox( this );
      this.stars_Check.text = "Star image";
      this.stars_Check.checked = this.par.outputStars ? true : false;
      this.stars_Check.toolTip = "<p>When checked, a stars window stays open as well. Otherwise the image stays starless.</p>";
      this.unscreen_Check = new CheckBox( this );
      this.unscreen_Check.text = "Unscreen";
      this.unscreen_Check.checked = this.par.unscreen ? true : false;
      let dialog = this;
      let apply = function()
      {
         dialog.unscreen_Check.enabled = dialog.stars_Check.checked;
      };
      this.stars_Check.onCheck = apply;
      apply();
      body.add( this.stars_Check );
      body.add( this.unscreen_Check );
   }

   buildScreen( body )
   {
      this.linked_Check = new CheckBox( this );
      this.linked_Check.text = "Link RGB Channels";
      this.linked_Check.checked = this.par.linked ? true : false;
      this.shadows_Edit = this.edit( this.par.shadows, 1 );
      this.target_Edit = this.edit( this.par.target, 2 );
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Only the display changes. Pixels stay linear.";
      body.add( note );
      body.add( this.linked_Check );
      body.add( this.row( "Shadows clipping", this.shadows_Edit ) );
      body.add( this.row( "Target background", this.target_Edit ) );
   }

   buildStretch( body )
   {
      this.target_Edit = this.edit( this.par.targetBackground, 2 );
      this.aggressive_Edit = this.edit( this.par.aggressiveness, 2 );
      this.range_Edit = this.edit( this.par.dynamicRange, 2 );
      this.recovery_Check = new CheckBox( this );
      this.recovery_Check.text = "Contrast Recovery";
      this.recovery_Check.checked = this.par.contrastRecovery ? true : false;
      this.separation_Edit = this.edit( this.par.scaleSeparation, 0 );
      this.intensity_Edit = this.edit( this.par.intensity, 2 );
      this.saturation_Check = new CheckBox( this );
      this.saturation_Check.text = "Color Saturation";
      this.saturation_Check.checked = this.par.saturation ? true : false;
      this.amount_Edit = this.edit( this.par.saturationAmount, 2 );
      this.boost_Edit = this.edit( this.par.saturationBoost, 2 );
      let dialog = this;
      let apply = function()
      {
         let recovery = dialog.recovery_Check.checked;
         dialog.separation_Edit.enabled = recovery;
         dialog.intensity_Edit.enabled = recovery;
         let color = dialog.saturation_Check.checked;
         dialog.amount_Edit.enabled = color;
         dialog.boost_Edit.enabled = color;
      };
      this.recovery_Check.onCheck = apply;
      this.saturation_Check.onCheck = apply;
      apply();
      body.add( this.row( "Target background", this.target_Edit ) );
      body.add( this.row( "Aggressiveness", this.aggressive_Edit ) );
      body.add( this.row( "Dynamic range compression", this.range_Edit ) );
      body.add( this.recovery_Check );
      body.add( this.row( "Scale separation", this.separation_Edit ) );
      body.add( this.row( "Intensity", this.intensity_Edit ) );
      body.add( this.saturation_Check );
      body.add( this.row( "Amount", this.amount_Edit ) );
      body.add( this.row( "Boost", this.boost_Edit ) );
   }

   needNumber( edit, label, allowNegative )
   {
      let value = f1Parse( edit.text );
      if ( value == null || ( !allowNegative && !( value > 0 ) ) || ( allowNegative && !isFinite( value ) ) )
      {
         f1Message( label + " is not a number." );
         return null;
      }
      return value;
   }

   readBack()
   {
      let par = this.par;
      if ( this.step.kind == "blurx" )
      {
         let overlap = this.needNumber( this.overlap_Edit, "Overlap", false );
         let stars = this.needNumber( this.stars_Edit, "Sharpen Stars", true );
         let halos = this.needNumber( this.halos_Edit, "Adjust Star Halos", true );
         let nonstellar = this.needNumber( this.nonstellar_Edit, "Sharpen Nonstellar", true );
         if ( overlap == null || stars == null || halos == null || nonstellar == null )
            return false;
         par.correctOnly = this.correct_Check.checked;
         par.overlap = overlap;
         par.sharpenStars = stars;
         par.starHalos = halos;
         par.sharpenNonstellar = nonstellar;
         return true;
      }
      if ( this.step.kind == "spfc" )
      {
         let wave = this.needNumber( this.wave_Edit, "Wavelength", false );
         let band = this.needNumber( this.band_Edit, "Bandwidth", false );
         if ( wave == null || band == null )
            return false;
         par.narrowband = this.narrow_Check.checked;
         par.wavelength = wave;
         par.bandwidth = band;
         if ( this.gray_Combo )
            par.grayName = this.chosen( this.gray_Combo );
         if ( this.red_Combo )
            par.redName = this.chosen( this.red_Combo );
         if ( this.green_Combo )
            par.greenName = this.chosen( this.green_Combo );
         if ( this.blue_Combo )
            par.blueName = this.chosen( this.blue_Combo );
         if ( this.slot == "R" && this.red_Combo )
            par.grayName = par.redName;
         else if ( this.slot == "G" && this.green_Combo )
            par.grayName = par.greenName;
         else if ( this.slot == "B" && this.blue_Combo )
            par.grayName = par.blueName;
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "mgc" )
      {
         let scale = this.needNumber( this.scale_Edit, "Gradient scale", false );
         let separation = this.needNumber( this.separation_Edit, "Structure separation", false );
         let smoothness = this.needNumber( this.smooth_Edit, "Model smoothness", false );
         if ( scale == null || separation == null || smoothness == null )
            return false;
         par.scale = scale;
         par.separation = separation;
         par.smoothness = smoothness;
         par.grayFilter = this.chosen( this.mars_Combo );
         par.showModel = this.show_Check.checked;
         return true;
      }
      if ( this.step.kind == "spcc" )
      {
         par.narrowband = this.narrow_Check.checked;
         par.redName = this.chosen( this.red_Combo );
         par.greenName = this.chosen( this.green_Combo );
         par.blueName = this.chosen( this.blue_Combo );
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "noisex" )
      {
         let denoise = this.needNumber( this.denoise_Edit, "Denoise", true );
         let detail = this.needNumber( this.detail_Edit, "Detail", true );
         if ( denoise == null || detail == null )
            return false;
         par.denoise = denoise;
         par.detail = detail;
         return true;
      }
      if ( this.step.kind == "starx" )
      {
         par.outputStars = this.stars_Check.checked;
         par.unscreen = this.unscreen_Check.checked;
         return true;
      }
      if ( this.step.kind == "screen" )
      {
         let shadows = this.needNumber( this.shadows_Edit, "Shadows clipping", true );
         let target = this.needNumber( this.target_Edit, "Target background", false );
         if ( shadows == null || target == null )
            return false;
         par.linked = this.linked_Check.checked;
         par.shadows = shadows;
         par.target = target;
         return true;
      }
      if ( this.step.kind == "stretch" )
      {
         let target = this.needNumber( this.target_Edit, "Target background", false );
         let aggressive = this.needNumber( this.aggressive_Edit, "Aggressiveness", true );
         let range = this.needNumber( this.range_Edit, "Dynamic range compression", true );
         let separation = this.needNumber( this.separation_Edit, "Scale separation", false );
         let intensity = this.needNumber( this.intensity_Edit, "Intensity", true );
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         let boost = this.needNumber( this.boost_Edit, "Boost", true );
         if ( target == null || aggressive == null || range == null || separation == null
              || intensity == null || amount == null || boost == null )
            return false;
         par.targetBackground = target;
         par.aggressiveness = aggressive;
         par.dynamicRange = range;
         par.contrastRecovery = this.recovery_Check.checked;
         par.scaleSeparation = separation;
         par.intensity = intensity;
         par.saturation = this.saturation_Check.checked;
         par.saturationAmount = amount;
         par.saturationBoost = boost;
         return true;
      }
      return true;
   }
};

var BatchProcessingDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.windowTitle = "BatchProcessing_byHrast";
      this.userResizable = true;
      this.ready = false;
      this.loading = true;
      let dialog = this;

      this.help_Label = new Label( this );
      this.help_Label.wordWrapping = true;
      this.help_Label.text = "Drop an open image onto a row, or pick it from the list. "
                            + "Settings opens that step for this filter only. "
                            + "An empty row is skipped.";

      this.lists = {};
      this.stepCheck = {};
      this.stepButton = {};
      let imageSizer = new VerticalSizer;
      imageSizer.spacing = 6;
      imageSizer.add( this.help_Label );
      for ( let i = 0; i < F1_SLOTS.length; ++i )
         imageSizer.add( this.makeSlotBlock( F1_SLOTS[i] ) );

      this.image_Group = new GroupBox( this );
      this.image_Group.title = "Images";
      this.image_Group.sizer = imageSizer;
      this.image_Group.sizer.margin = 6;

      this.run_Button = new PushButton( this );
      this.run_Button.text = "Process";
      this.run_Button.defaultButton = true;
      this.run_Button.onClick = () => dialog.run();

      this.close_Button = new PushButton( this );
      this.close_Button.text = "Close";
      this.close_Button.onClick = () =>
      {
         dialog.saveFromControls();
         dialog.cancel();
      };

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( this.run_Button );
      buttons.add( this.close_Button );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.image_Group );
      this.sizer.add( buttons );
      this.setScaledMinSize( 760, 560 );

      this.restoreViews();
      this.loading = false;
      this.onHide = () =>
      {
         if ( !dialog.ready )
            return;
         try
         {
            dialog.saveFromControls();
         }
         catch ( e )
         {
         }
      };
      this.ready = true;
   }

   makeFixedLabel( text )
   {
      let label = new Label( this );
      label.text = text;
      label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      label.setScaledFixedWidth( 88 );
      return label;
   }

   makeSlotBlock( slot )
   {
      let block = new VerticalSizer;
      block.spacing = 2;
      block.add( this.makeViewRow( slot ) );
      block.add( this.makeStepSection( slot ) );
      return block;
   }

   makeViewRow( slot )
   {
      let list = new ViewList( this );
      list.getMainViews();
      list.toolTip = "<p>Empty means " + slot + " is not processed.</p>";
      list.onViewSelected = function( view )
      {
         f1.views[slot] = ( view && !view.isNull ) ? view.id : "";
      };
      this.lists[slot] = list;

      let row = new HorizontalSizer;
      row.spacing = 6;
      row.add( this.makeFixedLabel( slot ) );
      row.add( list, 100 );
      return row;
   }

   makeStepSection( slot )
   {
      let dialog = this;
      let section = new Control( this );
      section.sizer = new VerticalSizer;
      section.sizer.spacing = 4;
      section.sizer.margin = 4;
      let steps = f1StepsFor( slot );
      this.stepCheck[slot] = {};
      this.stepButton[slot] = {};
      for ( let i = 0; i < steps.length; ++i )
         section.sizer.add( this.makeStepRow( slot, steps[i] ) );

      let bar = new SectionBar( this, "Steps" );
      bar.setSection( section );
      section.hide();
      bar.updateIcon();
      bar.onToggleSection = function( sectionBar, toggleBegin )
      {
         if ( !toggleBegin )
            dialog.adjustToContents();
      };

      let wrap = new VerticalSizer;
      wrap.spacing = 0;
      wrap.add( bar );
      wrap.add( section );
      return wrap;
   }

   makeStepRow( slot, step )
   {
      let dialog = this;
      let state = f1.steps[slot][step.id];
      let check = new CheckBox( this );
      check.text = step.title;
      check.checked = state.on;
      check.onCheck = function( checked )
      {
         if ( dialog.loading )
            return;
         let on = typeof checked == "boolean" ? checked : this.checked;
         state.on = on;
         dialog.syncStepRow( slot, step, on );
         if ( on )
            dialog.openStep( slot, step );
      };

      let setup = new PushButton( this );
      setup.text = "Settings";
      setup.toolTip = "<p>" + step.title + " for the " + slot + " filter only.</p>";
      setup.enabled = state.on;
      setup.onClick = function()
      {
         dialog.openStep( slot, step );
      };

      if ( !f1StepInstalled( step ) )
      {
         check.text = step.title + " (not installed)";
         check.checked = false;
         check.enabled = false;
         check.toolTip = "<p>" + step.title + " is not installed in PixInsight. This step is skipped.</p>";
         setup.enabled = false;
      }

      this.stepCheck[slot][step.id] = check;
      this.stepButton[slot][step.id] = setup;

      let row = new HorizontalSizer;
      row.spacing = 6;
      row.add( check );
      row.addStretch();
      row.add( setup );
      return row;
   }

   syncStepRow( slot, step, on )
   {
      this.stepButton[slot][step.id].enabled = on;
   }

   openStep( slot, step )
   {
      try
      {
         f1OpenStep( slot, step, this.selectedView( slot ) );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   restoreViews()
   {
      for ( let i = 0; i < F1_SLOTS.length; ++i )
      {
         let slot = F1_SLOTS[i];
         let id = f1.views[slot];
         if ( !id )
            continue;
         try
         {
            let view = View.viewById( id );
            if ( view && !view.isNull )
               this.lists[slot].currentView = view;
         }
         catch ( e )
         {
         }
      }
   }

   selectedView( slot )
   {
      let view = this.lists[slot].currentView;
      if ( !view || view.isNull )
         return null;
      return view;
   }

   saveFromControls()
   {
      for ( let s = 0; s < F1_SLOTS.length; ++s )
      {
         let slot = F1_SLOTS[s];
         let view = this.selectedView( slot );
         f1.views[slot] = view ? view.id : "";
         let steps = f1StepsFor( slot );
         for ( let i = 0; i < steps.length; ++i )
         {
            let step = steps[i];
            if ( !f1StepInstalled( step ) )
               continue;
            let state = f1.steps[slot][step.id];
            state.on = this.stepCheck[slot][step.id].checked;
         }
      }
      f1WriteSettings();
   }

   run()
   {
      this.saveFromControls();

      let jobs = [];
      let seen = {};
      for ( let i = 0; i < F1_SLOTS.length; ++i )
      {
         let slot = F1_SLOTS[i];
         let view = this.selectedView( slot );
         if ( !view )
            continue;
         if ( seen[view.id] )
         {
            jobs.push( { slot: slot, view: view, duplicate: seen[view.id] } );
            continue;
         }
         seen[view.id] = slot;
         jobs.push( { slot: slot, view: view, duplicate: "" } );
      }
      if ( jobs.length == 0 )
      {
         f1Message( "No image selected. An empty row is skipped." );
         return;
      }

      console.show();
      console.abortEnabled = true;
      this.run_Button.enabled = false;
      let done = [];
      let failed = [];
      try
      {
         for ( let i = 0; i < jobs.length; ++i )
         {
            let job = jobs[i];
            if ( job.duplicate )
            {
               failed.push( job.slot + ": the same image is already in row " + job.duplicate );
               continue;
            }
            try
            {
               f1RunSlot( job.slot, job.view );
               done.push( job.slot );
            }
            catch ( e )
            {
               let message = e.message ? e.message : e.toString();
               console.criticalln( "*** " + job.slot + ": " + message );
               failed.push( job.slot + ": " + message );
               if ( /abort/i.test( message ) )
                  break;
            }
            CoreApplication.processEvents();
         }
      }
      finally
      {
         this.run_Button.enabled = true;
         try
         {
            this.saveFromControls();
         }
         catch ( e )
         {
         }
      }

      if ( failed.length > 0 )
         f1Message( ( done.length > 0 ? ( "Processed: " + done.join( ", " ) + ".\n" ) : "" )
                    + "Stopped:\n" + failed.join( "\n" ) );
      else
         f1Message( "Processed: " + done.join( ", " ) + ".", true );
   }
};

// ----------------------------------------------------------------------------

function main()
{
   f1LoadSettings();
   f1LoadDatabase();
   let dialog = new BatchProcessingDialog();
   dialog.execute();
}

main();
