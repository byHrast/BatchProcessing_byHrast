// ----------------------------------------------------------------------------
// BatchProcessing_byHrast — Pre / Post helpers
// ----------------------------------------------------------------------------

var F1_PRE_STEPS = [
   { id: "autoassign", title: "Auto-assign filters", kind: "autoassign" },
   { id: "composergb", title: "Compose RGB (R+G+B)", kind: "composergb" }
];

var F1_POST_STEPS = [
   { id: "hdrmt", title: "HDRMultiscaleTransform", kind: "hdrmt" },
   { id: "lrgbcomb", title: "LRGBCombination", kind: "lrgbcomb" },
   { id: "starstretch", title: "Star Stretch", kind: "starstretch" },
   { id: "histo", title: "HistogramTransformation", kind: "histo" },
   { id: "putstars", title: "PixelMath (screen stars)", kind: "putstars" }
];

var F1_DEFAULT_HISTO_H = [
   // c0, m, c1, r0, r1
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.03807615, 0.50000000, 0.90581162, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ]
];

function f1CloneHistoH( src )
{
   let H = src && src.length ? src : F1_DEFAULT_HISTO_H;
   let out = [];
   for ( let i = 0; i < H.length; ++i )
      out.push( H[i].slice( 0 ) );
   return out;
}

var F1_FILTER_ALIASES = {
   L: "L", LUM: "L", LUMINANCE: "L", CLEAR: "L",
   R: "R", RED: "R",
   G: "G", GREEN: "G",
   B: "B", BLUE: "B",
   HA: "Ha", HALPHA: "Ha", "H-ALPHA": "Ha", H_ALPHA: "Ha",
   OIII: "OIII", O3: "OIII", "O-III": "OIII",
   SII: "SII", S2: "SII", "S-II": "SII",
   RGB: "RGB", OSC: "RGB", COLOR: "RGB", COLOUR: "RGB"
};

function f1PostViewName( par, key, fallback )
{
   let value = par && par[key] != null ? String( par[key] ).replace( /^\s+|\s+$/g, "" ) : "";
   return value || fallback;
}

function f1ResolvePostView( preferred, fallbacks )
{
   let view = f1ViewById( preferred );
   if ( view )
      return view;
   if ( !fallbacks )
      return null;
   for ( let i = 0; i < fallbacks.length; ++i )
   {
      view = f1ViewById( fallbacks[i] );
      if ( view )
      {
         console.writeln( "  using fallback view " + fallbacks[i]
                          + " (wanted " + preferred + ")" );
         return view;
      }
   }
   return null;
}

function f1MaybeRenamePostView( view, outId )
{
   outId = ( outId == null ? "" : String( outId ) ).replace( /^\s+|\s+$/g, "" );
   if ( !view || !outId || view.id == outId )
      return view;
   return f1RenameMainView( view, outId );
}

function f1PhaseDefaultParams( step )
{
   if ( step.kind == "autoassign" )
      return { preferFits: true };
   if ( step.kind == "composergb" )
      return {};
   if ( step.kind == "hdrmt" )
      return {
         input: "RGB",
         output: "RGB",
         numberOfLayers: 6,
         numberOfIterations: 1,
         invertedIterations: true,
         overdrive: 0.0,
         medianTransform: false,
         toLightness: false,
         toIntensity: false,
         preserveHue: false,
         luminanceMask: true,
         deringing: false
      };
   if ( step.kind == "lrgbcomb" )
      return {
         inputL: "L",
         inputRGB: "RGB",
         output: "LRGB",
         mL: 0.5,
         mc: 0.5,
         clipHighlights: true
      };
   if ( step.kind == "starstretch" )
      return {
         input: "RGB_stars",
         output: "RGB_stars",
         amount: 5.0,
         satAmount: 1.0,
         removeGreen: false
      };
   if ( step.kind == "histo" )
      return {
         input: "LRGB",
         output: "LRGB",
         H: f1CloneHistoH( F1_DEFAULT_HISTO_H )
      };
   if ( step.kind == "putstars" )
      return {
         inputStars: "RGB_stars",
         inputTarget: "LRGB",
         output: "LRGB",
         expression: "combine(RGB_stars, LRGB, op_screen())"
      };
   return {};
}

function f1InitPhase( name, builtins )
{
   f1[name] = { steps: {}, order: [], extra: [] };
   let order = [];
   for ( let i = 0; i < builtins.length; ++i )
   {
      let step = builtins[i];
      order.push( step.id );
      f1[name].steps[step.id] = { on: step.kind == "autoassign", par: f1PhaseDefaultParams( step ) };
   }
   f1[name].order = order;
}

function f1InitPrePost()
{
   f1InitPhase( "pre", F1_PRE_STEPS );
   f1InitPhase( "post", F1_POST_STEPS );
}

function f1PhaseBuiltins( name )
{
   return name == "pre" ? F1_PRE_STEPS : F1_POST_STEPS;
}

function f1PhaseAllSteps( name )
{
   let list = f1PhaseBuiltins( name ).slice( 0 );
   let extra = ( f1[name] && f1[name].extra ) ? f1[name].extra : [];
   for ( let i = 0; i < extra.length; ++i )
      list.push( extra[i] );
   return list;
}

function f1PhaseNormalizeOrder( name, ids )
{
   let steps = f1PhaseAllSteps( name );
   let known = {};
   for ( let i = 0; i < steps.length; ++i )
      known[steps[i].id] = steps[i];
   let order = [];
   let seen = {};
   if ( ids && ids.length )
   {
      for ( let i = 0; i < ids.length; ++i )
      {
         let id = ids[i];
         if ( known[id] && !seen[id] )
         {
            order.push( id );
            seen[id] = true;
         }
      }
   }
   for ( let i = 0; i < steps.length; ++i )
      if ( !seen[steps[i].id] )
         order.push( steps[i].id );
   return order;
}

function f1PhaseOrderedSteps( name )
{
   let steps = f1PhaseAllSteps( name );
   let byId = {};
   for ( let i = 0; i < steps.length; ++i )
      byId[steps[i].id] = steps[i];
   let order = f1PhaseNormalizeOrder( name, f1[name].order );
   f1[name].order = order;
   let list = [];
   for ( let i = 0; i < order.length; ++i )
      if ( byId[order[i]] )
         list.push( byId[order[i]] );
   return list;
}

function f1PhaseStepInstalled( step )
{
   if ( !step )
      return false;
   if ( step.kind == "autoassign" || step.kind == "composergb" || step.kind == "putstars" )
      return true;
   if ( step.kind == "starstretch" )
   {
      try
      {
         let list = f1StarStretchScriptCandidates();
         for ( let i = 0; i < list.length; ++i )
            if ( File.exists( list[i] ) )
               return true;
      }
      catch ( e )
      {
      }
      return typeof StarStretchParameters == "object";
   }
   if ( step.kind == "hdrmt" )
      return typeof HDRMultiscaleTransform == "function";
   if ( step.kind == "lrgbcomb" )
      return typeof LRGBCombination == "function";
   if ( step.kind == "histo" )
      return typeof HistogramTransformation == "function";
   if ( step.kind == "icon" )
      return f1GlobalIsFunction( step.processId );
   return false;
}

function f1ViewById( id )
{
   if ( !id )
      return null;
   try
   {
      let view = View.viewById( id );
      if ( view && !view.isNull )
         return view;
   }
   catch ( e )
   {
   }
   return null;
}

function f1MainWindows()
{
   let list = [];
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
   {
      let w = windows[i];
      if ( !w || !w.isWindow )
         continue;
      try
      {
         if ( w.mainView && !w.mainView.isNull )
            list.push( w );
      }
      catch ( e )
      {
      }
   }
   return list;
}

function f1WindowIds()
{
   let ids = {};
   let windows = f1MainWindows();
   for ( let i = 0; i < windows.length; ++i )
      ids[windows[i].mainView.id] = true;
   return ids;
}

function f1Keyword( window, name )
{
   try
   {
      let keywords = window.keywords;
      for ( let i = 0; i < keywords.length; ++i )
         if ( keywords[i].name == name )
         {
            let value = keywords[i].strippedValue;
            if ( value == null )
               value = keywords[i].value;
            return value == null ? "" : String( value ).trim();
         }
   }
   catch ( e )
   {
   }
   return "";
}

function f1NormalizeFilterToken( raw )
{
   let text = String( raw == null ? "" : raw ).trim();
   if ( !text )
      return "";
   let key = text.toUpperCase().replace( /\s+/g, "" );
   if ( F1_FILTER_ALIASES[key] )
      return F1_FILTER_ALIASES[key];
   if ( F1_FILTER_ALIASES[text.toUpperCase()] )
      return F1_FILTER_ALIASES[text.toUpperCase()];
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      if ( F1_SLOTS[s].toUpperCase() == key )
         return F1_SLOTS[s];
   return "";
}

function f1DetectFilterFromText( text )
{
   let src = String( text == null ? "" : text );
   let m = /FILTER-([A-Za-z0-9+-]+)/i.exec( src );
   if ( m )
   {
      let slot = f1NormalizeFilterToken( m[1] );
      if ( slot )
         return slot;
   }
   let upper = "_" + src.toUpperCase().replace( /[^A-Z0-9]+/g, "_" ) + "_";
   let keys = [
      "HALPHA", "H_ALPHA", "H-ALPHA", "HA",
      "OIII", "O-III", "O3",
      "SII", "S-II", "S2",
      "RGB", "OSC",
      "LUM", "LUMINANCE",
      "_L_", "_R_", "_G_", "_B_"
   ];
   for ( let i = 0; i < keys.length; ++i )
   {
      let token = keys[i];
      if ( token.charAt( 0 ) == "_" )
      {
         if ( upper.indexOf( token ) >= 0 )
            return f1NormalizeFilterToken( token.replace( /_/g, "" ) );
      }
      else if ( new RegExp( "(^|_)" + token + "(_|$)" ).test( upper ) )
      {
         let slot = f1NormalizeFilterToken( token );
         if ( slot )
            return slot;
      }
   }
   return "";
}

function f1DetectFilterForWindow( window, preferFits )
{
   let view = window.mainView;
   let isColor = false;
   try
   {
      isColor = view && view.image && view.image.isColor ? true : false;
   }
   catch ( e )
   {
   }
   // Combined color masters belong in RGB, never in R/G/B.
   if ( isColor )
      return "RGB";
   if ( preferFits )
   {
      let fromFits = f1NormalizeFilterToken( f1Keyword( window, "FILTER" ) );
      if ( fromFits )
         return fromFits;
   }
   let id = view.id;
   let path = "";
   try { path = window.filePath || ""; } catch ( e ) {}
   let fromName = f1DetectFilterFromText( id );
   if ( fromName )
      return fromName;
   fromName = f1DetectFilterFromText( File.extractName( path ) );
   if ( fromName )
      return fromName;
   if ( !preferFits )
   {
      let fromFits = f1NormalizeFilterToken( f1Keyword( window, "FILTER" ) );
      if ( fromFits )
         return fromFits;
   }
   return "";
}

function f1ClearDialogSlot( dialog, slot )
{
   f1.views[slot] = "";
   if ( !dialog || !dialog.lists || !dialog.lists[slot] )
      return;
   try
   {
      dialog.lists[slot].getMainViews();
   }
   catch ( e )
   {
   }
   try
   {
      // Empty selection so the filter chain skips this row.
      dialog.lists[slot].currentView = new View;
   }
   catch ( e )
   {
   }
}

function f1SetDialogSlot( dialog, slot, view )
{
   f1.views[slot] = view ? view.id : "";
   if ( !dialog || !dialog.lists || !dialog.lists[slot] || !view )
      return;
   try
   {
      dialog.lists[slot].getMainViews();
   }
   catch ( e )
   {
   }
   try
   {
      dialog.lists[slot].currentView = view;
   }
   catch ( e )
   {
   }
}

function f1RenameMainView( view, newId )
{
   if ( !view || view.isNull )
      throw new Error( "Missing view for rename." );
   if ( view.id == newId )
      return view;
   let existing = f1ViewById( newId );
   if ( existing && existing.window.mainView.id == newId && existing.window.uniqueId != view.window.uniqueId )
      throw new Error( "View id already in use: " + newId );
   view.id = newId;
   return view;
}

function f1FindNewWindow( beforeIds )
{
   let windows = f1MainWindows();
   for ( let i = 0; i < windows.length; ++i )
   {
      let id = windows[i].mainView.id;
      if ( !beforeIds[id] )
         return windows[i];
   }
   try
   {
      let active = ImageWindow.activeWindow;
      if ( active && active.isWindow && active.mainView && !beforeIds[active.mainView.id] )
         return active;
   }
   catch ( e )
   {
   }
   return null;
}

function f1AutoAssignFilters( par, dialog )
{
   let preferFits = !par || par.preferFits !== false;
   let assigned = {};
   let windows = f1MainWindows();
   console.noteln( "<end><cbr><br>* Pre: Auto-assign filters" );
   for ( let i = 0; i < windows.length; ++i )
   {
      let window = windows[i];
      let view = window.mainView;
      let slot = f1DetectFilterForWindow( window, preferFits );
      if ( !slot )
      {
         console.writeln( "  skip (no filter): " + view.id );
         continue;
      }
      if ( assigned[slot] )
      {
         console.warningln( "  skip duplicate " + slot + ": " + view.id );
         continue;
      }
      try
      {
         if ( view.id != slot )
         {
            console.writeln( "  " + view.id + " -> " + slot );
            f1RenameMainView( view, slot );
         }
         else
            console.writeln( "  already " + slot );
         // Never place a color RGB image into mono R/G/B rows.
         if ( ( slot == "R" || slot == "G" || slot == "B" ) && view.image && view.image.isColor )
         {
            console.warningln( "  skip color view for " + slot + ": " + view.id );
            continue;
         }
         f1SetDialogSlot( dialog, slot, view );
         assigned[slot] = true;
      }
      catch ( e )
      {
         console.warningln( "  " + view.id + ": " + ( e.message ? e.message : e.toString() ) );
      }
   }
}

function f1ComposeRGB( par, dialog )
{
   f1RequireModule( "ChannelCombination", typeof ChannelCombination == "function" );
   let r = f1ViewById( f1.views.R || "R" );
   let g = f1ViewById( f1.views.G || "G" );
   let b = f1ViewById( f1.views.B || "B" );
   if ( !r || !g || !b )
   {
      console.warningln( "<end><cbr>** Compose RGB skipped: need R, G and B views." );
      return null;
   }
   console.noteln( "<end><cbr><br>* Pre: Compose RGB from R+G+B" );
   if ( f1ViewById( "RGB" ) )
      throw new Error( "View id already in use: RGB" );
   let before = f1WindowIds();
   let P = new ChannelCombination;
   P.colorSpace = ChannelCombination.RGB;
   P.channels = [
      [ true, r.id ],
      [ true, g.id ],
      [ true, b.id ]
   ];
   f1Set( P, "inheritAstrometricSolution", true );
   if ( P.executeGlobal() === false )
      throw new Error( "ChannelCombination failed." );
   let window = f1FindNewWindow( before );
   if ( !window )
   {
      try { window = ImageWindow.activeWindow; } catch ( e ) {}
   }
   if ( !window || !window.isWindow )
      throw new Error( "Compose RGB did not create a new image." );
   f1RenameMainView( window.mainView, "RGB" );
   console.writeln( "  created RGB" );
   // Combined RGB is the filter to process — clear separate R/G/B rows.
   f1SetDialogSlot( dialog, "RGB", window.mainView );
   f1ClearDialogSlot( dialog, "R" );
   f1ClearDialogSlot( dialog, "G" );
   f1ClearDialogSlot( dialog, "B" );
   console.writeln( "  RGB row filled; R/G/B rows cleared for the filter chain" );
   return window.mainView;
}

function f1RenameStarXResult( slot, beforeIds )
{
   if ( slot != "RGB" )
      return;
   let window = f1FindNewWindow( beforeIds );
   if ( !window )
   {
      // StarX may name the stars view with a predictable suffix
      let candidates = [];
      let windows = f1MainWindows();
      for ( let i = 0; i < windows.length; ++i )
      {
         let id = windows[i].mainView.id;
         if ( /stars/i.test( id ) && id != "RGB_stars" )
            candidates.push( windows[i] );
      }
      if ( candidates.length == 1 )
         window = candidates[0];
      else if ( candidates.length > 1 )
      {
         for ( let i = 0; i < candidates.length; ++i )
            if ( !beforeIds[candidates[i].mainView.id] )
            {
               window = candidates[i];
               break;
            }
      }
   }
   if ( !window )
   {
      console.warningln( "  could not find StarX stars view to rename to RGB_stars" );
      return;
   }
   let existing = f1ViewById( "RGB_stars" );
   if ( existing && existing.window.uniqueId != window.uniqueId )
      throw new Error( "View id already in use: RGB_stars" );
   f1RenameMainView( window.mainView, "RGB_stars" );
   console.writeln( "  stars -> RGB_stars" );
}

function f1RunHDRMT( par )
{
   f1RequireModule( "HDRMultiscaleTransform", typeof HDRMultiscaleTransform == "function" );
   let inId = f1PostViewName( par, "input", "RGB" );
   let outId = f1PostViewName( par, "output", inId );
   let view = f1ResolvePostView( inId, [ f1.views.RGB || "RGB", "RGB" ] );
   if ( !view )
   {
      console.warningln( "<end><cbr>** HDRMultiscaleTransform skipped: view not found: " + inId );
      return;
   }
   console.noteln( "<end><cbr><br>* Post: HDRMultiscaleTransform on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = new HDRMultiscaleTransform;
   f1Need( P, "numberOfLayers", Math.round( isFinite( par.numberOfLayers ) ? par.numberOfLayers : 6 ) );
   f1Need( P, "numberOfIterations", Math.round( isFinite( par.numberOfIterations ) ? par.numberOfIterations : 1 ) );
   f1Need( P, "invertedIterations", par.invertedIterations !== false );
   f1Need( P, "overdrive", isFinite( par.overdrive ) ? par.overdrive : 0.0 );
   f1Need( P, "medianTransform", par.medianTransform ? true : false );
   f1Set( P, "scalingFunctionName", "B3 Spline (5)" );
   f1Set( P, "toIntensity", par.toIntensity ? true : false );
   f1Set( P, "toLightness", par.toLightness ? true : false );
   f1Set( P, "preserveHue", par.preserveHue ? true : false );
   f1Need( P, "luminanceMask", par.luminanceMask !== false );
   f1Set( P, "deringing", par.deringing ? true : false );
   if ( P.executeOn( view ) === false )
      throw new Error( "HDRMultiscaleTransform failed." );
   f1MaybeRenamePostView( view, outId );
}

function f1RunLRGBCombination( par )
{
   f1RequireModule( "LRGBCombination", typeof LRGBCombination == "function" );
   let inL = f1PostViewName( par, "inputL", "L" );
   let inRGB = f1PostViewName( par, "inputRGB", "RGB" );
   let outId = f1PostViewName( par, "output", "LRGB" );
   let L = f1ResolvePostView( inL, [ f1.views.L || "L", "L" ] );
   let rgb = f1ResolvePostView( inRGB, [ f1.views.RGB || "RGB", "RGB" ] );
   if ( !L || !rgb )
   {
      console.warningln( "<end><cbr>** LRGBCombination skipped: need "
                         + inL + " and " + inRGB + " views." );
      return;
   }
   if ( f1ViewById( outId ) )
      throw new Error( "View id already in use: " + outId );
   console.noteln( "<end><cbr><br>* Post: LRGBCombination (" + L.id + " onto " + rgb.id
                   + ") -> " + outId );
   let clone = new ImageWindow( rgb.image.width, rgb.image.height,
                                rgb.image.numberOfChannels,
                                rgb.window.bitsPerSample,
                                rgb.window.isFloatSample,
                                true /*isColor*/,
                                outId );
   clone.mainView.beginProcess( UndoFlag.NoSwapFile );
   clone.mainView.image.assign( rgb.image );
   clone.mainView.endProcess();
   clone.show();
   let P = new LRGBCombination;
   P.channels = [
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ true, L.id, 1.0 ]
   ];
   f1Need( P, "mL", par.mL );
   f1Need( P, "mc", par.mc );
   f1Set( P, "clipHighlights", par.clipHighlights !== false );
   f1Set( P, "noiseReduction", false );
   if ( P.executeOn( clone.mainView ) === false )
      throw new Error( "LRGBCombination failed." );
   f1MaybeRenamePostView( clone.mainView, outId );
   console.writeln( "  created " + clone.mainView.id );
}

var f1StarStretchApi = null;

function f1StarStretchScriptCandidates()
{
   let dir = "";
   try
   {
      dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ );
   }
   catch ( e )
   {
      dir = "";
   }
   let list = [];
   if ( dir )
   {
      list.push( dir + "/star_stretch.js" );
      list.push( dir + "/SetiAstro/star_stretch.js" );
   }
   list.push( "C:/Program Files/PixInsight/src/scripts/star_stretch.js" );
   return list;
}

function f1EnsureStarStretchLibrary()
{
   if ( f1StarStretchApi
        && f1StarStretchApi.StarStretchParameters
        && typeof f1StarStretchApi.applyPixelMath == "function" )
      return f1StarStretchApi;
   let candidates = f1StarStretchScriptCandidates();
   let path = "";
   for ( let i = 0; i < candidates.length; ++i )
      if ( File.exists( candidates[i] ) )
      {
         path = candidates[i];
         break;
      }
   if ( !path )
      throw new Error( "SetiAstro Star Stretch script not found. "
                       + "Place Franklin Marek's official star_stretch.js next to BatchProcessing_byHrast "
                       + "(or in SetiAstro/), or keep the SetiAstro install under PixInsight/src/scripts/. "
                       + "This script does not reimplement Star Stretch." );
   let text = File.readTextFile( path );
   // Load Franklin Marek's script as a library; do not run its interactive main()/dialog.
   text = text.replace( /\r\n/g, "\n" );
   // Strip PJSR preprocessor lines — they are not valid inside Function().
   text = text.replace( /^[ \t]*#[^\n]*\n/gm, "" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*$/m, "\n" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*\n/g, "\n" );
   let api = null;
   try
   {
      api = ( new Function(
         text
         + "\n; return {"
         + " StarStretchParameters: (typeof StarStretchParameters!=='undefined')?StarStretchParameters:null,"
         + " applyPixelMath: (typeof applyPixelMath==='function')?applyPixelMath:null,"
         + " applyColorSaturation: (typeof applyColorSaturation==='function')?applyColorSaturation:null,"
         + " applySCNR: (typeof applySCNR==='function')?applySCNR:null,"
         + " isGrayscale: (typeof isGrayscale==='function')?isGrayscale:null,"
         + " disableSTF: (typeof disableSTF==='function')?disableSTF:null"
         + " };"
      ) )();
   }
   catch ( e )
   {
      throw new Error( "Could not load SetiAstro Star Stretch from:\n" + path
                       + "\n" + ( e.message ? e.message : e.toString() ) );
   }
   if ( !api || !api.StarStretchParameters || typeof api.applyPixelMath != "function" )
      throw new Error( "Star Stretch loaded from " + path
                       + " but required exports are missing." );
   api.path = path;
   f1StarStretchApi = api;
   console.writeln( "Using SetiAstro Star Stretch by Franklin Marek (www.setiastro.com): " + path );
   return api;
}

function f1RunStarStretch( par )
{
   let inId = f1PostViewName( par, "input", "RGB_stars" );
   let outId = f1PostViewName( par, "output", inId );
   let view = f1ResolvePostView( inId, [ "RGB_stars" ] );
   if ( !view )
   {
      console.warningln( "<end><cbr>** Star Stretch skipped: view not found: " + inId );
      return;
   }
   let api = f1EnsureStarStretchLibrary();
   console.noteln( "<end><cbr><br>* Post: Star Stretch (SetiAstro) on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = api.StarStretchParameters;
   P.amount = isFinite( par.amount ) ? par.amount : 5.0;
   P.satAmount = isFinite( par.satAmount ) ? par.satAmount : 1.0;
   P.removeGreen = par.removeGreen ? true : false;
   P.targetView = view;
   if ( typeof P.updateSaturationLevel == "function" )
      P.updateSaturationLevel();
   api.applyPixelMath( view, P.amount );
   let gray = false;
   try
   {
      gray = api.isGrayscale ? api.isGrayscale( view ) : !( view.image && view.image.isColor );
   }
   catch ( e )
   {
      gray = !( view.image && view.image.isColor );
   }
   if ( !gray )
   {
      if ( typeof api.applyColorSaturation == "function" )
         api.applyColorSaturation( view );
      if ( P.removeGreen && typeof api.applySCNR == "function" )
         api.applySCNR( view );
   }
   if ( typeof api.disableSTF == "function" )
   {
      try { api.disableSTF( view ); } catch ( e ) {}
   }
   f1MaybeRenamePostView( view, outId );
}

function f1RunHistogramTransformation( par )
{
   f1RequireModule( "HistogramTransformation", typeof HistogramTransformation == "function" );
   let inId = f1PostViewName( par, "input", "LRGB" );
   let outId = f1PostViewName( par, "output", inId );
   // No L / skipped LRGBCombination → fall back to RGB.
   let view = f1ResolvePostView( inId, inId == "LRGB" ? [ "RGB" ] : [ "LRGB", "RGB" ] );
   if ( !view )
   {
      console.warningln( "<end><cbr>** HistogramTransformation skipped: view not found: " + inId );
      return;
   }
   console.noteln( "<end><cbr><br>* Post: HistogramTransformation on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = new HistogramTransformation;
   P.H = f1CloneHistoH( par && par.H ? par.H : F1_DEFAULT_HISTO_H );
   if ( P.executeOn( view ) === false )
      throw new Error( "HistogramTransformation failed." );
   // Fallback RGB must not be renamed to LRGB — there was no L combination.
   if ( !( inId == "LRGB" && view.id == "RGB" && outId == "LRGB" ) )
      f1MaybeRenamePostView( view, outId );
}

function f1RunPutStars( par )
{
   f1RequireModule( "PixelMath", typeof PixelMath == "function" );
   let starsId = f1PostViewName( par, "inputStars", "RGB_stars" );
   let targetId = f1PostViewName( par, "inputTarget", "LRGB" );
   let outId = f1PostViewName( par, "output", targetId );
   let stars = f1ResolvePostView( starsId, [ "RGB_stars" ] );
   let target = f1ResolvePostView( targetId, targetId == "LRGB" ? [ "RGB" ] : [ "LRGB", "RGB" ] );
   if ( !stars || !target )
   {
      console.warningln( "<end><cbr>** PixelMath put stars skipped: need "
                         + starsId + " and " + targetId + "." );
      return;
   }
   let expression = ( par && par.expression ) ? String( par.expression ).replace( /^\s+|\s+$/g, "" ) : "";
   if ( !expression.length
        || expression == "combine(RGB_stars, LRGB, op_screen())"
        || /^combine\([^,]+,\s*[^,]+,\s*op_screen\(\)\)$/.test( expression ) )
      expression = "combine(" + stars.id + ", " + target.id + ", op_screen())";
   console.noteln( "<end><cbr><br>* Post: PixelMath screen " + stars.id + " onto " + target.id );
   let P = new PixelMath;
   P.expression = expression;
   f1Set( P, "useSingleExpression", true );
   f1Set( P, "createNewImage", false );
   if ( P.executeOn( target ) === false )
      throw new Error( "PixelMath put stars failed." );
   if ( !( targetId == "LRGB" && target.id == "RGB" && outId == "LRGB" ) )
      f1MaybeRenamePostView( target, outId );
}

function f1RunPhaseIcon( step, state )
{
   if ( !state.par.source )
      throw new Error( step.title + " has no saved parameters." );
   let process = f1BuildFromIconSource( state.par.source );
   f1AutoWireCombineProcess( process, step.processId || state.par.processId );
   let target = f1ViewById( f1.views.RGB || "RGB" )
             || f1ViewById( f1.views.L || "L" )
             || f1ViewById( "LRGB" );
   if ( !target )
      throw new Error( step.title + ": no target view." );
   if ( process.executeOn( target ) === false )
      throw new Error( step.title + " failed." );
}

function f1AutoWireCombineProcess( process, processId )
{
   if ( !process || !processId )
      return;
   try
   {
      if ( processId == "ChannelCombination" )
      {
         let r = f1ViewById( f1.views.R || "R" );
         let g = f1ViewById( f1.views.G || "G" );
         let b = f1ViewById( f1.views.B || "B" );
         if ( r && g && b )
            process.channels = [ [ true, r.id ], [ true, g.id ], [ true, b.id ] ];
      }
      else if ( processId == "LRGBCombination" )
      {
         let L = f1ViewById( f1.views.L || "L" );
         if ( L )
            process.channels = [
               [ false, "", 1.0 ],
               [ false, "", 1.0 ],
               [ false, "", 1.0 ],
               [ true, L.id, 1.0 ]
            ];
      }
   }
   catch ( e )
   {
   }
}

function f1RunPhase( name, dialog )
{
   let steps = f1PhaseOrderedSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      if ( !state || !state.on )
         continue;
      if ( !f1PhaseStepInstalled( step ) )
      {
         console.warningln( "<end><cbr>** " + step.title + " is not installed. Step skipped." );
         continue;
      }
      if ( step.kind == "autoassign" )
         f1AutoAssignFilters( state.par, dialog );
      else if ( step.kind == "composergb" )
         f1ComposeRGB( state.par, dialog );
      else if ( step.kind == "hdrmt" )
         f1RunHDRMT( state.par );
      else if ( step.kind == "lrgbcomb" )
         f1RunLRGBCombination( state.par );
      else if ( step.kind == "starstretch" )
         f1RunStarStretch( state.par );
      else if ( step.kind == "histo" )
         f1RunHistogramTransformation( state.par );
      else if ( step.kind == "putstars" )
         f1RunPutStars( state.par );
      else if ( step.kind == "icon" )
         f1RunPhaseIcon( step, state );
      CoreApplication.processEvents();
   }
}

function f1PhaseExtraForWrite( name )
{
   let extraOut = [];
   let extra = ( f1[name] && f1[name].extra ) ? f1[name].extra : [];
   for ( let i = 0; i < extra.length; ++i )
   {
      let step = extra[i];
      let par = f1[name].steps[step.id] ? f1[name].steps[step.id].par : {};
      extraOut.push( {
         id: step.id,
         kind: "icon",
         title: step.title,
         processId: step.processId || par.processId,
         iconName: par.iconName || "",
         source: par.source || ""
      } );
   }
   return extraOut;
}

function f1WritePhaseSettings( name )
{
   if ( !f1[name] )
      return;
   Settings.write( SETTINGS_PREFIX + name + "_order", DataType.String,
                   JSON.stringify( f1PhaseNormalizeOrder( name, f1[name].order ) ) );
   Settings.write( SETTINGS_PREFIX + name + "_extra", DataType.String,
                   JSON.stringify( f1PhaseExtraForWrite( name ) ) );
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      Settings.write( SETTINGS_PREFIX + name + "_on_" + step.id, DataType.Boolean, state.on );
      Settings.write( SETTINGS_PREFIX + name + "_par_" + step.id, DataType.String, JSON.stringify( state.par ) );
   }
}

function f1LoadPhaseSettings( name )
{
   f1InitPhase( name, f1PhaseBuiltins( name ) );
   let rawExtra = f1ReadString( name + "_extra", "" );
   if ( rawExtra )
   {
      try
      {
         let list = JSON.parse( rawExtra );
         if ( Array.isArray( list ) )
         {
            for ( let i = 0; i < list.length; ++i )
            {
               let item = list[i];
               if ( !item || !item.id || item.kind != "icon" || !item.processId )
                  continue;
               let step = {
                  id: item.id,
                  title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
                  kind: "icon",
                  processId: item.processId
               };
               f1[name].extra.push( step );
               f1[name].steps[step.id] = {
                  on: true,
                  par: {
                     processId: item.processId,
                     iconName: item.iconName || "",
                     source: item.source || "",
                     title: step.title
                  }
               };
            }
         }
      }
      catch ( e )
      {
         f1[name].extra = [];
      }
   }
   let rawOrder = f1ReadString( name + "_order", "" );
   if ( rawOrder )
   {
      try
      {
         let ids = JSON.parse( rawOrder );
         if ( Array.isArray( ids ) )
            f1[name].order = f1PhaseNormalizeOrder( name, ids );
      }
      catch ( e )
      {
      }
   }
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      let fallbackOn = ( step.kind == "autoassign" );
      state.on = f1ReadBool( name + "_on_" + step.id, fallbackOn );
      let rawPar = f1ReadString( name + "_par_" + step.id, "" );
      if ( !rawPar )
         continue;
      try
      {
         let saved = JSON.parse( rawPar );
         if ( saved && typeof saved == "object" )
            for ( let key in saved )
               if ( saved[key] != null )
                  state.par[key] = saved[key];
      }
      catch ( e )
      {
      }
      if ( step.kind == "icon" )
      {
         step.processId = state.par.processId || step.processId;
         step.title = state.par.title || step.title;
      }
   }
}

function f1CollectPhaseProfile( name )
{
   let stepMap = {};
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      stepMap[step.id] = { on: state.on ? true : false, par: state.par || {} };
   }
   return {
      order: f1PhaseNormalizeOrder( name, f1[name].order ),
      extra: f1PhaseExtraForWrite( name ),
      steps: stepMap
   };
}

function f1ApplyPhaseProfile( name, data )
{
   f1InitPhase( name, f1PhaseBuiltins( name ) );
   if ( !data || typeof data != "object" )
      return;
   if ( Array.isArray( data.extra ) )
   {
      for ( let i = 0; i < data.extra.length; ++i )
      {
         let item = data.extra[i];
         if ( !item || !item.id || item.kind != "icon" || !item.processId )
            continue;
         let step = {
            id: item.id,
            title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
            kind: "icon",
            processId: item.processId
         };
         f1[name].extra.push( step );
         f1[name].steps[step.id] = {
            on: true,
            par: {
               processId: item.processId,
               iconName: item.iconName || "",
               source: item.source || "",
               title: step.title
            }
         };
      }
   }
   f1[name].order = f1PhaseNormalizeOrder( name, data.order );
   let stepMap = data.steps || {};
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      let saved = stepMap[step.id];
      if ( !saved || typeof saved != "object" )
         continue;
      if ( saved.on != null )
         state.on = saved.on ? true : false;
      if ( saved.par && typeof saved.par == "object" )
         for ( let key in saved.par )
            if ( saved.par[key] != null )
               state.par[key] = saved.par[key];
      if ( step.kind == "icon" )
      {
         step.processId = state.par.processId || step.processId;
         step.title = state.par.title || step.title;
      }
   }
}
