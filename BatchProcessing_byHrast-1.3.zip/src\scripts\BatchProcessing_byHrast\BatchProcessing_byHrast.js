// ----------------------------------------------------------------------------
// BatchProcessing_byHrast
//
// The row selects the filter. An empty row is skipped.
// Settings are a dialog inside the script, separate for each filter.
// Names are the full process names. ScreenTransferFunction is last.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    BatchProcessing_byHrast : Batch Processing > BatchProcessing_byHrast

#feature-info  BatchProcessing_byHrast. One row per filter: Ha, OIII, SII, L, R, G, B and RGB. \
               Settings stay inside the script and apply only to that filter.

#define USE_SOLVER_LIBRARY
#define SETTINGS_MODULE "BatchProcessing_byHrast"

#define SETTINGS_PREFIX "BatchProcessing_byHrast/"
#define SETTINGS_PREFIX_LEGACY "Faza1/"

#include "../ImageSolver/ImageSolver.js"
#include "EarlyCalibrationCurves.jsh"
#include "BatchProcessing_PrePost.jsh"

// ----------------------------------------------------------------------------

var F1_SLOTS = [ "Ha", "OIII", "SII", "L", "R", "G", "B", "RGB" ];

var F1_FILTER_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "blurless", title: "BlurlessAI", kind: "blurless" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "blurx2", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_RGB_STEPS = [
   { id: "spikeless", title: "SpikeLessAI", kind: "spikeless" },
   { id: "blurx1", title: "BlurXTerminator", kind: "blurx", mode: "correct" },
   { id: "blurless", title: "BlurlessAI", kind: "blurless" },
   { id: "solver", title: "ImageSolver", kind: "solver" },
   { id: "spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "mgc", title: "MultiscaleGradientCorrection", kind: "mgc" },
   { id: "spcc", title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { id: "blurx", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "starx", title: "StarXTerminator", kind: "starx" },
   { id: "screen", title: "ScreenTransferFunction", kind: "screen" },
   { id: "stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" }
];

var F1_WAVE = { Ha: 656.3, OIII: 500.7, SII: 671.6 };
var F1_BAND = { Ha: 3.0, OIII: 3.0, SII: 3.0 };

var f1 = {
   views: { Ha: "", OIII: "", SII: "", L: "", R: "", G: "", B: "", RGB: "" },
   steps: {},
   order: {},
   extra: {},
   pre: { steps: {}, order: [], extra: [] },
   post: { steps: {}, order: [], extra: [] },
   solverKeep: {},
   db: { L: [], R: [], G: [], B: [], Q: [] },
   curveByName: {}
};

function f1Format( value, digits )
{
   if ( value == null || !isFinite( value ) )
      return "";
   return format( "%." + digits + "f", value );
}

function f1Parse( text )
{
   let trimmed = String( text == null ? "" : text ).trim().replace( ",", "." );
   if ( trimmed.length == 0 )
      return null;
   let value = Number( trimmed );
   return isFinite( value ) ? value : null;
}

function f1ReadBool( key, fallback )
{
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.Boolean );
   if ( Settings.lastReadOK )
      return value ? true : false;
   value = Settings.read( SETTINGS_PREFIX_LEGACY + key, DataType.Boolean );
   if ( Settings.lastReadOK )
      return value ? true : false;
   return fallback;
}

function f1ReadString( key, fallback )
{
   let value = Settings.read( SETTINGS_PREFIX + key, DataType.String );
   if ( Settings.lastReadOK && typeof value == "string" )
      return value;
   value = Settings.read( SETTINGS_PREFIX_LEGACY + key, DataType.String );
   if ( Settings.lastReadOK && typeof value == "string" )
      return value;
   return fallback;
}

function f1DetectMarsFiles()
{
   let found = [];
   let appData = System.getEnvironmentVariable( "APPDATA" );
   if ( !appData )
      return found;
   let files = [];
   try
   {
      files = File.searchDirectory( appData.replace( /\\/g, "/" ) + "/Pleiades/*.settings", false );
   }
   catch ( e )
   {
      return found;
   }
   let re = /k="MARSDatabaseFilePath\d+" t="s">([^<]+)</g;
   for ( let i = 0; i < files.length; ++i )
   {
      let text = "";
      try
      {
         text = File.readTextFile( files[i] );
      }
      catch ( e )
      {
         continue;
      }
      for ( let match = re.exec( text ); match; match = re.exec( text ) )
         if ( found.indexOf( match[1] ) < 0 && File.exists( match[1] ) )
            found.push( match[1] );
   }
   return found;
}

function f1MarsFiles()
{
   let raw = f1ReadString( "marsFiles", "" );
   if ( raw )
   {
      try
      {
         let list = JSON.parse( raw );
         if ( Array.isArray( list ) )
            return list;
      }
      catch ( e )
      {
      }
   }
   return f1DetectMarsFiles();
}

function f1WriteMarsFiles( list )
{
   Settings.write( SETTINGS_PREFIX + "marsFiles", DataType.String, JSON.stringify( list ) );
}

function f1StepsFor( slot )
{
   return slot == "RGB" ? F1_RGB_STEPS : F1_FILTER_STEPS;
}

function f1AllSteps( slot )
{
   let list = f1StepsFor( slot ).slice( 0 );
   let extra = f1.extra[slot] || [];
   for ( let i = 0; i < extra.length; ++i )
      list.push( extra[i] );
   return list;
}

function f1StepLabel( step )
{
   if ( step.kind == "blurx" && step.mode == "correct" )
      return "BlurXTerminator, Correct Only";
   return step.title;
}

function f1DefaultOrder( slot )
{
   let steps = f1StepsFor( slot );
   let ids = [];
   for ( let i = 0; i < steps.length; ++i )
      ids.push( steps[i].id );
   return ids;
}

function f1NormalizeOrder( slot, ids )
{
   let steps = f1AllSteps( slot );
   let known = {};
   for ( let i = 0; i < steps.length; ++i )
      known[steps[i].id] = steps[i];
   let order = [];
   let seen = {};
   if ( ids && ids.length )
   {
      for ( let i = 0; i < ids.length; ++i )
      {
         let id = ids[i];
         if ( known[id] && !seen[id] )
         {
            order.push( id );
            seen[id] = true;
         }
      }
   }
   for ( let i = 0; i < steps.length; ++i )
      if ( !seen[steps[i].id] )
         order.push( steps[i].id );
   return order;
}

function f1OrderedSteps( slot )
{
   let steps = f1AllSteps( slot );
   let byId = {};
   for ( let i = 0; i < steps.length; ++i )
      byId[steps[i].id] = steps[i];
   let order = f1NormalizeOrder( slot, f1.order[slot] );
   f1.order[slot] = order;
   let list = [];
   for ( let i = 0; i < order.length; ++i )
      if ( byId[order[i]] )
         list.push( byId[order[i]] );
   return list;
}

function f1ReadOrder( slot )
{
   let raw = f1ReadString( "order_" + slot, "" );
   if ( !raw )
      return f1DefaultOrder( slot );
   try
   {
      let ids = JSON.parse( raw );
      if ( Array.isArray( ids ) )
         return f1NormalizeOrder( slot, ids );
   }
   catch ( e )
   {
   }
   return f1DefaultOrder( slot );
}

function f1GlobalIsFunction( name )
{
   if ( !name || !/^[A-Za-z_][A-Za-z0-9_]*$/.test( name ) )
      return false;
   try
   {
      return ( new Function( "return typeof " + name + " === 'function';" ) )();
   }
   catch ( e )
   {
      return false;
   }
}

function f1StepInstalled( step )
{
   switch ( step.kind )
   {
   case "spikeless": return typeof SpikeLessAI == "function";
   case "blurx":     return typeof BlurXTerminator == "function";
   case "blurless":  return typeof BlurlessAI == "function";
   case "solver":    return typeof ImageSolver == "function";
   case "spfc":      return typeof SpectrophotometricFluxCalibration == "function";
   case "mgc":       return typeof MultiscaleGradientCorrection == "function";
   case "spcc":      return typeof SpectrophotometricColorCalibration == "function";
   case "noisex":    return typeof NoiseXTerminator == "function";
   case "starx":     return typeof StarXTerminator == "function";
   case "screen":    return typeof ScreenTransferFunction == "function";
   case "stretch":   return typeof MultiscaleAdaptiveStretch == "function";
   case "icon":      return f1GlobalIsFunction( step.processId );
   }
   return true;
}

function f1NewIconStepId()
{
   return "icon_" + Date.now().toString( 36 ) + "_" + Math.floor( Math.random() * 1000 );
}

function f1SnapshotFromIcon( iconName )
{
   let instance = ProcessInstance.fromIcon( iconName );
   if ( !instance )
      throw new Error( "Process icon was not found: " + iconName );
   let processId = instance.processId();
   let flags = 0;
   try
   {
      flags = SourceCodeFlag.Minimal;
   }
   catch ( e )
   {
      flags = 15;
   }
   let source = instance.toSource( "JavaScript", "P", 0, flags );
   if ( !source || String( source ).trim().length == 0 )
      throw new Error( "Could not read parameters from process icon: " + iconName );
   return {
      processId: processId,
      iconName: iconName,
      source: String( source ).trim(),
      title: processId + " (" + iconName + ")"
   };
}

function f1BuildFromIconSource( source )
{
   // PixInsight icon source usually starts with "let P = new ...".
   // Evaluating that in a scope that already has P throws:
   // Identifier 'P' has already been declared.
   let code = String( source == null ? "" : source ).trim();
   if ( !code.length )
      throw new Error( "Could not recreate the process from the saved snapshot." );
   code = code.replace( /^\s*(?:var|let|const)\s+P\s*=/, "P =" );
   let process = null;
   try
   {
      process = ( new Function( "var P = null;\n" + code + ";\nreturn P;" ) )();
   }
   catch ( e )
   {
      throw new Error( e.message ? e.message : e.toString() );
   }
   if ( !process )
      throw new Error( "Could not recreate the process from the saved snapshot." );
   return process;
}

function f1Narrow( slot )
{
   return slot == "Ha" || slot == "OIII" || slot == "SII";
}

function f1DefaultParams( slot, step )
{
   if ( step.kind == "spikeless" )
      return {
         model: "SpikeLessAI v2",
         mode: "Linear",
         strength: 1.00,
         stride: 128,
         starLayer: "None",
         generateSpikeImage: false,
         cleanLongTails: false
      };
   if ( step.kind == "blurx" )
   {
      let sharpen = step.mode == "sharpen";
      return {
         correctOnly: !sharpen,
         sharpenStars: sharpen ? 0.10 : 0,
         starHalos: sharpen ? 0.05 : 0,
         sharpenNonstellar: sharpen ? 0.70 : 0,
         overlap: 0.20
      };
   }
   if ( step.kind == "blurless" )
      return {
         amount: 1.00,
         coresAbove: "Clip",
         colourMode: "Channels",
         alignChannels: true,
         crisperSpikes: false
      };
   if ( step.kind == "spfc" )
   {
      let narrow = f1Narrow( slot );
      let gray = f1GrayName( slot );
      return {
         narrowband: narrow,
         wavelength: narrow ? F1_WAVE[slot] : 656.3,
         bandwidth: narrow ? F1_BAND[slot] : 3.0,
         grayName: gray,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   }
   if ( step.kind == "mgc" )
      return {
         scale: 1024,
         separation: 3,
         smoothness: 1.0,
         grayFilter: slot == "RGB" ? "L" : slot,
         showModel: true
      };
   if ( step.kind == "spcc" )
      return {
         narrowband: false,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   if ( step.kind == "noisex" )
      return { denoise: 0.70, detail: 0.15 };
   if ( step.kind == "starx" )
      return { outputStars: false, unscreen: false };
   if ( step.kind == "screen" )
      return { linked: true, shadows: -2.8, target: 0.25 };
   if ( step.kind == "stretch" )
      return {
         targetBackground: 0.15,
         aggressiveness: 0.70,
         dynamicRange: 0.40,
         contrastRecovery: true,
         scaleSeparation: 1024,
         intensity: 1.00,
         saturation: false,
         saturationAmount: 0.75,
         saturationBoost: 0.50
      };
   return {};
}

function f1ApplySavedParams( slot, step, state )
{
   let raw = f1ReadString( "par_" + slot + "_" + step.id, "" );
   if ( !raw )
      return;
   try
   {
      let saved = JSON.parse( raw );
      if ( !saved || typeof saved != "object" )
         return;
      for ( let key in saved )
         if ( saved[key] != null )
            state.par[key] = saved[key];
   }
   catch ( e )
   {
   }
}

function f1GrayName( slot )
{
   if ( slot == "R" )
      return EC_redFilterName;
   if ( slot == "G" )
      return EC_greenFilterName;
   if ( slot == "B" )
      return EC_blueFilterName;
   return EC_grayFilterName;
}

function f1GrayChannel( slot )
{
   if ( slot == "R" || slot == "G" || slot == "B" )
      return slot;
   return "L";
}

function f1AddCurve( channel, name, data )
{
   if ( !f1.db[channel] || !name || !data || f1.curveByName[name] )
      return;
   f1.db[channel].push( name );
   f1.curveByName[name] = data;
}

function f1LoadDatabase()
{
   f1.db = { L: [], R: [], G: [], B: [], Q: [] };
   f1.curveByName = {};
   let path = "";
   let dirs = [ "PXI_DOCDIR", "PXI_BINDIR", "PXI_SRCDIR" ];
   for ( let i = 0; i < dirs.length && !path; ++i )
   {
      let dir = System.getEnvironmentVariable( dirs[i] );
      if ( dir )
      {
         let candidate = File.extractDrive( dir ) + File.extractDirectory( dir.replace( /[\/\\]+$/, "" ) ) + "/library/filters.xspd";
         if ( File.exists( candidate ) )
            path = candidate;
      }
   }
   if ( !path && File.exists( "C:/Program Files/PixInsight/library/filters.xspd" ) )
      path = "C:/Program Files/PixInsight/library/filters.xspd";
   if ( path )
   {
      let text = File.readTextFile( path );
      let re = /<Filter name="([^"]+)" channel="([^"]+)"[^>]*?\sdata="([^"]*)"/g;
      for ( let match = re.exec( text ); match; match = re.exec( text ) )
         f1AddCurve( match[2], match[1], match[3] );
   }
   f1AddCurve( "L", EC_grayFilterName, EC_grayFilterTrCurve );
   f1AddCurve( "R", EC_redFilterName, EC_redFilterTrCurve );
   f1AddCurve( "G", EC_greenFilterName, EC_greenFilterTrCurve );
   f1AddCurve( "B", EC_blueFilterName, EC_blueFilterTrCurve );
   f1AddCurve( "Q", EC_deviceQECurveName, EC_deviceQECurve );
   let channels = [ "L", "R", "G", "B", "Q" ];
   for ( let i = 0; i < channels.length; ++i )
      f1.db[channels[i]].sort();
}

function f1Curve( name, fallback )
{
   if ( name && f1.curveByName[name] )
      return f1.curveByName[name];
   return fallback;
}

function f1InitSteps()
{
   f1.steps = {};
   f1.order = {};
   f1.extra = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.steps[slot] = {};
      f1.extra[slot] = [];
      f1.order[slot] = f1DefaultOrder( slot );
      let steps = f1StepsFor( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         f1.steps[slot][step.id] = { on: true, par: f1DefaultParams( slot, step ) };
      }
   }
   f1InitPrePost();
}

function f1LoadExtra( slot )
{
   let raw = f1ReadString( "extra_" + slot, "" );
   if ( !raw )
   {
      f1.extra[slot] = [];
      return;
   }
   try
   {
      let list = JSON.parse( raw );
      f1ApplyExtraList( slot, list );
   }
   catch ( e )
   {
      f1.extra[slot] = [];
   }
}

function f1LoadSettings()
{
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      f1.views[slot] = f1ReadString( "view" + slot, "" );
      f1LoadExtra( slot );
      f1.order[slot] = f1ReadOrder( slot );
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         state.on = f1ReadBool( "on_" + slot + "_" + step.id, true );
         f1ApplySavedParams( slot, step, state );
         if ( step.kind == "icon" )
         {
            step.processId = state.par.processId || step.processId;
            step.title = state.par.title || step.title;
         }
      }
   }
   f1LoadPhaseSettings( "pre" );
   f1LoadPhaseSettings( "post" );
}

function f1ExtraForWrite( slot )
{
   let extraOut = [];
   let extra = f1.extra[slot] || [];
   for ( let i = 0; i < extra.length; ++i )
   {
      let step = extra[i];
      let par = f1.steps[slot][step.id] ? f1.steps[slot][step.id].par : {};
      extraOut.push( {
         id: step.id,
         kind: "icon",
         title: step.title,
         processId: step.processId || par.processId,
         iconName: par.iconName || "",
         source: par.source || ""
      } );
   }
   return extraOut;
}

function f1WriteSettings()
{
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      Settings.write( SETTINGS_PREFIX + "view" + slot, DataType.String, f1.views[slot] );
      Settings.write( SETTINGS_PREFIX + "order_" + slot, DataType.String,
                      JSON.stringify( f1NormalizeOrder( slot, f1.order[slot] ) ) );
      Settings.write( SETTINGS_PREFIX + "extra_" + slot, DataType.String, JSON.stringify( f1ExtraForWrite( slot ) ) );
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         Settings.write( SETTINGS_PREFIX + "on_" + slot + "_" + step.id, DataType.Boolean, state.on );
         Settings.write( SETTINGS_PREFIX + "par_" + slot + "_" + step.id, DataType.String, JSON.stringify( state.par ) );
      }
   }
   f1WritePhaseSettings( "pre" );
   f1WritePhaseSettings( "post" );
}

function f1CollectProfile()
{
   let slots = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      let stepMap = {};
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         stepMap[step.id] = {
            on: state.on ? true : false,
            par: state.par || {}
         };
      }
      slots[slot] = {
         order: f1NormalizeOrder( slot, f1.order[slot] ),
         extra: f1ExtraForWrite( slot ),
         steps: stepMap
      };
   }
   return {
      format: "BatchProcessing_byHrast",
      version: 2,
      marsFiles: f1MarsFiles(),
      slots: slots,
      pre: f1CollectPhaseProfile( "pre" ),
      post: f1CollectPhaseProfile( "post" )
   };
}

function f1ApplyExtraList( slot, list )
{
   f1.extra[slot] = [];
   if ( !list || !Array.isArray( list ) )
      return;
   for ( let i = 0; i < list.length; ++i )
   {
      let item = list[i];
      if ( !item || !item.id || item.kind != "icon" || !item.processId )
         continue;
      let step = {
         id: item.id,
         title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
         kind: "icon",
         processId: item.processId
      };
      f1.extra[slot].push( step );
      f1.steps[slot][step.id] = {
         on: true,
         par: {
            processId: item.processId,
            iconName: item.iconName || "",
            source: item.source || "",
            title: step.title
         }
      };
   }
}

function f1ApplyProfile( profile )
{
   if ( !profile || typeof profile != "object" )
      throw new Error( "Invalid settings file." );
   if ( profile.format != "BatchProcessing_byHrast" )
      throw new Error( "Not a BatchProcessing_byHrast settings file." );
   let viewsKeep = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      viewsKeep[F1_SLOTS[s]] = f1.views[F1_SLOTS[s]] || "";
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      f1.views[F1_SLOTS[s]] = viewsKeep[F1_SLOTS[s]];
   if ( Array.isArray( profile.marsFiles ) )
      f1WriteMarsFiles( profile.marsFiles );
   let slots = profile.slots || {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
   {
      let slot = F1_SLOTS[s];
      let data = slots[slot] || {};
      f1ApplyExtraList( slot, data.extra );
      f1.order[slot] = f1NormalizeOrder( slot, data.order );
      let stepMap = data.steps || {};
      let steps = f1AllSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         let saved = stepMap[step.id];
         if ( !saved || typeof saved != "object" )
            continue;
         if ( saved.on != null )
            state.on = saved.on ? true : false;
         if ( saved.par && typeof saved.par == "object" )
         {
            for ( let key in saved.par )
               if ( saved.par[key] != null )
                  state.par[key] = saved.par[key];
         }
         if ( step.kind == "icon" )
         {
            step.processId = state.par.processId || step.processId;
            step.title = state.par.title || step.title;
         }
      }
   }
   f1ApplyPhaseProfile( "pre", profile.pre );
   f1ApplyPhaseProfile( "post", profile.post );
}

function f1ResetToDefaults()
{
   let viewsKeep = {};
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      viewsKeep[F1_SLOTS[s]] = f1.views[F1_SLOTS[s]] || "";
   f1InitSteps();
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      f1.views[F1_SLOTS[s]] = viewsKeep[F1_SLOTS[s]];
}

function f1NormalizePresetName( name )
{
   name = ( name == null ? "" : name.toString() ).replace( /^\s+|\s+$/g, "" ).replace( /\s+/g, " " );
   if ( !name )
      return "";
   if ( /^default$/i.test( name ) )
      return "Default";
   name = name.replace( /[\/\\:*?"<>|]/g, "_" );
   if ( name.length > 64 )
      name = name.substring( 0, 64 );
   return name;
}

function f1PresetStorageKey( name )
{
   return "presetData_" + f1NormalizePresetName( name );
}

function f1ListPresets()
{
   let raw = f1ReadString( "presetList", "[]" );
   let list = [];
   try
   {
      list = JSON.parse( raw );
   }
   catch ( e )
   {
      list = [];
   }
   if ( !Array.isArray( list ) )
      list = [];
   let out = [];
   let seen = {};
   for ( let i = 0; i < list.length; ++i )
   {
      let name = f1NormalizePresetName( list[i] );
      if ( !name || name == "Default" || seen[name.toLowerCase()] )
         continue;
      seen[name.toLowerCase()] = true;
      out.push( name );
   }
   out.sort( function( a, b ) { return a.toLowerCase() < b.toLowerCase() ? -1 : ( a.toLowerCase() > b.toLowerCase() ? 1 : 0 ); } );
   return out;
}

function f1WritePresetList( list )
{
   Settings.write( SETTINGS_PREFIX + "presetList", DataType.String, JSON.stringify( list || [] ) );
}

function f1SaveNamedPreset( name, profile )
{
   name = f1NormalizePresetName( name );
   if ( !name || name == "Default" )
      throw new Error( "Choose a preset name other than Default." );
   if ( !profile )
      profile = f1CollectProfile();
   Settings.write( SETTINGS_PREFIX + f1PresetStorageKey( name ), DataType.String, JSON.stringify( profile ) );
   let list = f1ListPresets();
   let found = false;
   for ( let i = 0; i < list.length; ++i )
      if ( list[i].toLowerCase() == name.toLowerCase() )
      {
         list[i] = name;
         found = true;
         break;
      }
   if ( !found )
      list.push( name );
   list.sort( function( a, b ) { return a.toLowerCase() < b.toLowerCase() ? -1 : ( a.toLowerCase() > b.toLowerCase() ? 1 : 0 ); } );
   f1WritePresetList( list );
   Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, name );
   return name;
}

function f1LoadNamedPreset( name )
{
   name = f1NormalizePresetName( name );
   if ( !name || name == "Default" )
      return null;
   let raw = f1ReadString( f1PresetStorageKey( name ), "" );
   if ( !raw )
      throw new Error( "Preset not found: " + name );
   let profile = JSON.parse( raw );
   Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, name );
   return profile;
}

function f1Message( text, info )
{
   ( new MessageBox( text, "BatchProcessing_byHrast", info ? StdIcon.Information : StdIcon.Warning, StdButton.Ok ) ).execute();
}

function f1Set( process, name, value )
{
   try
   {
      process[name] = value;
      return true;
   }
   catch ( e )
   {
      return false;
   }
}

function f1Need( process, name, value )
{
   if ( !f1Set( process, name, value ) )
      throw new Error( "Parameter was not accepted: " + name );
}

function f1ProcessEnum( ctor, name, numericFallback )
{
   try
   {
      if ( ctor && ctor.prototype && ctor.prototype[name] != null )
         return ctor.prototype[name];
   }
   catch ( e )
   {
   }
   return numericFallback;
}

function f1RequireModule( name, present )
{
   if ( !present )
      throw new Error( name + " is not installed." );
}

function f1BuildSpikeLess( par )
{
   f1RequireModule( "SpikeLessAI", typeof SpikeLessAI == "function" );
   let process = new SpikeLessAI;
   f1Set( process, "model", par.model );
   f1Set( process, "processingMode",
          par.mode == "Stretched" ? "Direct" : "LinearVirtualStretch" );
   f1Need( process, "strength", par.strength );
   f1Need( process, "stride", Math.round( par.stride ) );
   f1Set( process, "starSeparation", par.starLayer );
   f1Need( process, "generateSpikeImage", par.generateSpikeImage ? true : false );
   f1Set( process, "polishLeftovers", par.cleanLongTails ? true : false );
   f1Set( process, "farSpikePass", par.cleanLongTails ? true : false );
   f1Set( process, "removeAllSpikes", false );
   f1Set( process, "repairDarkLines", false );
   f1Set( process, "createSpikes", false );
   f1Set( process, "useGPU", true );
   return process;
}

function f1BuildBlurX( par )
{
   f1RequireModule( "BlurXTerminator", typeof BlurXTerminator == "function" );
   let process = new BlurXTerminator;
   let correct = par.correctOnly ? true : false;
   f1Set( process, "ml_version", 0 );
   f1Need( process, "correct_only", correct );
   f1Set( process, "sharpen_stars", correct ? 0 : par.sharpenStars );
   f1Set( process, "adjust_star_halos", correct ? 0 : par.starHalos );
   f1Set( process, "nonstellar_diameter", 0.0 );
   f1Set( process, "auto_nonstellar_psf", true );
   f1Set( process, "sharpen_nonstellar", correct ? 0 : par.sharpenNonstellar );
   f1Set( process, "lunar_planetary", false );
   f1Set( process, "overlap", par.overlap );
   return process;
}

function f1BuildBlurless( par )
{
   f1RequireModule( "BlurlessAI", typeof BlurlessAI == "function" );
   let process = new BlurlessAI;
   f1Need( process, "amount", par.amount );
   let coresName = ( typeof par.coresAbove == "string" && par.coresAbove.length ) ? par.coresAbove : "Clip";
   let coresIndex = { Clip: 0, Keep: 1, Rescale: 2 };
   let cores = ( typeof par.coresAbove == "number" ) ? par.coresAbove
             : f1ProcessEnum( BlurlessAI, coresName,
                              coresIndex[coresName] != null ? coresIndex[coresName] : 0 );
   f1Need( process, "coresAbove", cores );
   let colourName = ( par.colourMode == "Luminance" ) ? "Luminance" : "Channels";
   let colourIndex = { Channels: 0, Luminance: 1 };
   let colour = ( typeof par.colourMode == "number" ) ? par.colourMode
              : f1ProcessEnum( BlurlessAI, colourName, colourIndex[colourName] );
   f1Need( process, "colourMode", colour );
   f1Need( process, "alignChannels", par.alignChannels ? true : false );
   f1Need( process, "crisperSpikes", par.crisperSpikes ? true : false );
   f1Set( process, "useGPU", true );
   return process;
}

function f1FillFlux( process, par )
{
   let grayName = par.grayName || EC_grayFilterName;
   f1Need( process, "narrowbandMode", par.narrowband ? true : false );
   f1Need( process, "grayFilterTrCurve", f1Curve( grayName, EC_grayFilterTrCurve ) );
   f1Need( process, "grayFilterName", grayName );
   f1Need( process, "grayFilterWavelength", par.wavelength );
   f1Need( process, "grayFilterBandwidth", par.bandwidth );
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "redFilterWavelength", 656.3 );
   f1Set( process, "redFilterBandwidth", 3.0 );
   f1Set( process, "greenFilterWavelength", 500.7 );
   f1Set( process, "greenFilterBandwidth", 3.0 );
   f1Set( process, "blueFilterWavelength", 500.7 );
   f1Set( process, "blueFilterBandwidth", 3.0 );
   f1Set( process, "broadbandIntegrationStepSize", 0.5 );
   f1Set( process, "narrowbandIntegrationSteps", 10 );
   f1Set( process, "rejectionLimit", 0.3 );
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "minMagnitude", 0 );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "psfStructureLayers", 5 );
   f1Set( process, "saturationThreshold", 0.75 );
   f1Set( process, "saturationRelative", true );
   f1Set( process, "saturationShrinkFactor", 0.10 );
   f1Set( process, "psfNoiseLayers", 1 );
   f1Set( process, "psfHotPixelFilterRadius", 1 );
   f1Set( process, "psfNoiseReductionFilterRadius", 0 );
   f1Set( process, "psfMinStructureSize", 0 );
   f1Set( process, "psfMinSNR", 40 );
   f1Set( process, "psfAllowClusteredSources", false );
   f1Set( process, "psfGrowth", 1.75 );
   f1Set( process, "psfMaxStars", 24576 );
   f1Set( process, "psfSearchTolerance", 4 );
   f1Set( process, "psfChannelSearchTolerance", 2 );
   f1Set( process, "generateGraphs", true );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   try
   {
      process.psfType = SpectrophotometricFluxCalibration.PSFType_Auto;
   }
   catch ( e )
   {
   }
}

function f1BuildFlux( par )
{
   f1RequireModule( "SpectrophotometricFluxCalibration", typeof SpectrophotometricFluxCalibration == "function" );
   let process = new SpectrophotometricFluxCalibration;
   f1FillFlux( process, par );
   return process;
}

function f1BuildGradient( par )
{
   f1RequireModule( "MultiscaleGradientCorrection", typeof MultiscaleGradientCorrection == "function" );
   let process = new MultiscaleGradientCorrection;
   f1Need( process, "useMARSDatabase", true );
   f1Need( process, "grayMARSFilter", par.grayFilter );
   f1Need( process, "redMARSFilter", "R" );
   f1Need( process, "greenMARSFilter", "G" );
   f1Need( process, "blueMARSFilter", "B" );
   f1Set( process, "referenceImageId", "" );
   f1Need( process, "gradientScale", Math.round( par.scale ) );
   f1Need( process, "structureSeparation", Math.round( par.separation ) );
   f1Need( process, "modelSmoothness", par.smoothness );
   f1Set( process, "minFieldRatio", 0.017 );
   f1Set( process, "maxFieldRatio", 0.167 );
   f1Set( process, "enforceFieldLimits", true );
   f1Set( process, "scaleFactorRK", 1 );
   f1Set( process, "scaleFactorG", 1 );
   f1Set( process, "scaleFactorB", 1 );
   f1Set( process, "showGradientModel", par.showModel ? true : false );
   f1Set( process, "command", "" );
   let files = f1MarsFiles().filter( function( path ) { return File.exists( path ); } );
   if ( files.length == 0 )
      throw new Error( "No MARS database files. Add them in MultiscaleGradientCorrection Settings." );
   f1Need( process, "marsDatabaseFiles", files.map( function( path ) { return [ true, path ]; } ) );
   return process;
}

function f1BuildColor( par )
{
   f1RequireModule( "SpectrophotometricColorCalibration", typeof SpectrophotometricColorCalibration == "function" );
   let process = new SpectrophotometricColorCalibration;
   f1Set( process, "narrowbandMode", par.narrowband ? true : false );
   f1Need( process, "redFilterTrCurve", f1Curve( par.redName, EC_redFilterTrCurve ) );
   f1Need( process, "redFilterName", par.redName );
   f1Need( process, "greenFilterTrCurve", f1Curve( par.greenName, EC_greenFilterTrCurve ) );
   f1Need( process, "greenFilterName", par.greenName );
   f1Need( process, "blueFilterTrCurve", f1Curve( par.blueName, EC_blueFilterTrCurve ) );
   f1Need( process, "blueFilterName", par.blueName );
   f1Need( process, "deviceQECurve", f1Curve( par.sensorName, EC_deviceQECurve ) );
   f1Need( process, "deviceQECurveName", par.sensorName );
   f1Set( process, "catalogId", "GaiaDR3SP" );
   f1Set( process, "autoLimitMagnitude", true );
   f1Set( process, "limitMagnitude", 12 );
   f1Set( process, "generateGraphs", false );
   f1Set( process, "generateStarMaps", false );
   f1Set( process, "generateTextFiles", false );
   f1Set( process, "outputDirectory", "" );
   return process;
}

function f1BuildNoise( par )
{
   f1RequireModule( "NoiseXTerminator", typeof NoiseXTerminator == "function" );
   let process = new NoiseXTerminator;
   f1Need( process, "denoise", par.denoise );
   f1Need( process, "detail", par.detail );
   return process;
}

function f1BuildStars( par )
{
   f1RequireModule( "StarXTerminator", typeof StarXTerminator == "function" );
   let process = new StarXTerminator;
   f1Need( process, "output_stars", par.outputStars ? true : false );
   f1Set( process, "unscreen", par.outputStars && par.unscreen ? true : false );
   return process;
}

function f1CopyRow( row )
{
   return [ row[0], row[1], row[2], row[3], row[4] ];
}

function f1StretchRow( median, mad, channel, inverted, shadowsClipping, targetBackground )
{
   let med = median.at( channel );
   let dev = mad.at( channel );
   if ( !inverted )
   {
      let c0 = ( 1 + dev != 1 ) ? Math.range( med + shadowsClipping * dev, 0.0, 1.0 ) : 0.0;
      let midtone = Math.mtf( targetBackground, med - c0 );
      return [ c0, 1, midtone, 0, 1 ];
   }
   let c1 = ( 1 + dev != 1 ) ? Math.range( med - shadowsClipping * dev, 0.0, 1.0 ) : 1.0;
   let midtone = Math.mtf( c1 - med, targetBackground );
   return [ 0, c1, midtone, 0, 1 ];
}

function f1MakeScreen( view, par )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let linked = par.linked ? true : false;
   let shadowsClipping = isFinite( par.shadows ) ? par.shadows : -2.8;
   let targetBackground = isFinite( par.target ) ? par.target : 0.25;
   let process = new ScreenTransferFunction;
   let rows = [
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ],
      [ 0, 1, 0.5, 0, 1 ]
   ];
   if ( view && view.image )
   {
      let color = view.image.isColor;
      let count = color ? 3 : 1;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );
      if ( linked || !color )
      {
         let inverted = 0;
         for ( let c = 0; c < count; ++c )
            if ( median.at( c ) > 0.5 )
               ++inverted;
         let row;
         if ( inverted < count )
         {
            let c0 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               if ( 1 + mad.at( c ) != 1 )
                  c0 += median.at( c ) + shadowsClipping * mad.at( c );
               mid += median.at( c );
            }
            c0 = Math.range( c0 / count, 0.0, 1.0 );
            row = [ c0, 1, Math.mtf( targetBackground, mid / count - c0 ), 0, 1 ];
         }
         else
         {
            let c1 = 0;
            let mid = 0;
            for ( let c = 0; c < count; ++c )
            {
               mid += median.at( c );
               if ( 1 + mad.at( c ) != 1 )
                  c1 += median.at( c ) - shadowsClipping * mad.at( c );
               else
                  c1 += 1;
            }
            c1 = Math.range( c1 / count, 0.0, 1.0 );
            row = [ 0, c1, Math.mtf( c1 - mid / count, targetBackground ), 0, 1 ];
         }
         let limit = color ? 3 : 1;
         for ( let c = 0; c < limit; ++c )
            rows[c] = f1CopyRow( row );
      }
      else
      {
         for ( let c = 0; c < count; ++c )
            rows[c] = f1StretchRow( median, mad, c, median.at( c ) >= 0.5, shadowsClipping, targetBackground );
      }
   }
   process.STF = rows;
   return process;
}

function f1ResetScreen( view )
{
   f1RequireModule( "ScreenTransferFunction", typeof ScreenTransferFunction == "function" );
   let process = new ScreenTransferFunction;
   let row = [ 0, 1, 0.5, 0, 1 ];
   process.STF = [ row.slice( 0 ), row.slice( 0 ), row.slice( 0 ), row.slice( 0 ) ];
   if ( process.executeOn( view, false ) === false )
      throw new Error( "ScreenTransferFunction failed." );
}

function f1BuildStretch( par )
{
   f1RequireModule( "MultiscaleAdaptiveStretch", typeof MultiscaleAdaptiveStretch == "function" );
   let process = new MultiscaleAdaptiveStretch;
   f1Need( process, "targetBackground", par.targetBackground );
   f1Need( process, "aggressiveness", par.aggressiveness );
   f1Need( process, "dynamicRangeCompression", par.dynamicRange );
   f1Need( process, "contrastRecovery", par.contrastRecovery ? true : false );
   f1Need( process, "scaleSeparation", Math.round( par.scaleSeparation ) );
   f1Need( process, "contrastRecoveryIntensity", par.intensity );
   f1Need( process, "saturationEnabled", par.saturation ? true : false );
   f1Need( process, "saturationAmount", par.saturationAmount );
   f1Need( process, "saturationBoost", par.saturationBoost );
   f1Set( process, "previewLargeScale", false );
   f1Set( process, "backgroundROIEnabled", false );
   return process;
}

function f1Build( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( step.kind == "spikeless" )
      return f1BuildSpikeLess( par );
   if ( step.kind == "blurx" )
      return f1BuildBlurX( par );
   if ( step.kind == "blurless" )
      return f1BuildBlurless( par );
   if ( step.kind == "spfc" )
      return f1BuildFlux( par );
   if ( step.kind == "mgc" )
      return f1BuildGradient( par );
   if ( step.kind == "spcc" )
      return f1BuildColor( par );
   if ( step.kind == "noisex" )
      return f1BuildNoise( par );
   if ( step.kind == "starx" )
      return f1BuildStars( par );
   if ( step.kind == "screen" )
      return f1MakeScreen( view, par );
   if ( step.kind == "stretch" )
      return f1BuildStretch( par );
   if ( step.kind == "icon" )
   {
      if ( !par.source )
         throw new Error( step.title + " has no saved parameters." );
      return f1BuildFromIconSource( par.source );
   }
   return null;
}

function f1OpenSolver( slot, view )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   if ( typeof ImageSolverDialog != "function" )
      throw new Error( "ImageSolver dialog is not available." );
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      if ( view )
         solver.initialize( view.window, false /*prioritizeSettings*/ );
      solver.solverCfg.useActive = true;
   }
   let gui = new ImageSolverDialog( solver.solverCfg, solver.metadata, true /*showTargetImage*/ );
   if ( gui.execute() )
      f1.solverKeep[slot] = solver;
}

function f1OpenStep( slot, step, view )
{
   if ( step.kind == "solver" )
   {
      f1OpenSolver( slot, view );
      return false;
   }
   let gui = new FazaSetupDialog( slot, step, f1.steps[slot][step.id].par );
   return gui.execute() ? true : false;
}

function f1Solve( window, slot )
{
   f1RequireModule( "ImageSolver", typeof ImageSolver == "function" );
   console.writeln( "<end><cbr><br>ImageSolver" );
   console.flush();
   let solver = f1.solverKeep[slot];
   if ( !solver )
   {
      solver = new ImageSolver();
      solver.initialize( window, false /*prioritizeSettings*/ );
   }
   solver.solverCfg.useActive = true;
   window.bringToFront();
   solver.solveImage( window );
   console.writeln( window.astrometricSolutionSummary().trim() );
}

function f1Execute( slot, step, view )
{
   let par = f1.steps[slot][step.id].par;
   if ( step.kind == "screen" )
   {
      console.writeln( "<end><cbr><br>ScreenTransferFunction  "
                       + ( par.linked ? "linked channels" : "channels separate" ) );
      console.flush();
      let process = f1MakeScreen( view, par );
      if ( process.executeOn( view, false ) === false )
         throw new Error( "ScreenTransferFunction failed." );
      return;
   }
   if ( step.kind == "spcc" && ( !view.image || !view.image.isColor ) )
      throw new Error( "SpectrophotometricColorCalibration needs a three-channel image." );
   console.writeln( "<end><cbr><br>" + step.title );
   console.flush();
   let beforeIds = null;
   if ( step.kind == "starx" && slot == "RGB" )
   {
      par.outputStars = true;
      beforeIds = f1WindowIds();
   }
   let instance = f1Build( slot, step, view );
   if ( !instance )
      throw new Error( step.title + " is not ready." );
   if ( instance.executeOn( view ) === false )
      throw new Error( step.title + " failed." );
   if ( step.kind == "stretch" )
      f1ResetScreen( view );
   if ( step.kind == "starx" && slot == "RGB" )
      f1RenameStarXResult( slot, beforeIds );
}

function f1RunSlot( slot, view )
{
   let window = view.window;
   console.noteln( "<end><cbr><br>* " + slot + ": " + view.id );
   console.flush();
   let steps = f1OrderedSteps( slot );
   let ran = false;
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1.steps[slot][step.id];
      if ( !state.on )
         continue;
      if ( !f1StepInstalled( step ) )
      {
         console.warningln( "<end><cbr>** " + step.title + " is not installed. Step skipped." );
         continue;
      }
      ran = true;
      if ( step.kind == "solver" )
         f1Solve( window, slot );
      else
         f1Execute( slot, step, view );
      CoreApplication.processEvents();
   }
   if ( !ran )
      console.writeln( "No enabled steps." );
   console.noteln( "<end><cbr>* " + slot + " done: " + view.id );
}

// ----------------------------------------------------------------------------

var F1IconPickDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.windowTitle = "Process icon";
      this.iconName = "";
      this.userResizable = true;

      let icons = [];
      try
      {
         icons = ProcessInstance.icons();
      }
      catch ( e )
      {
         icons = [];
      }
      icons.sort( function( a, b ) { return a.toLowerCase().localeCompare( b.toLowerCase() ); } );

      let help = new Label( this );
      help.wordWrapping = true;
      help.text = "Choose a process icon from the PixInsight workspace. "
                + "Its parameters are copied into this script.";

      this.icon_Combo = new ComboBox( this );
      for ( let i = 0; i < icons.length; ++i )
         this.icon_Combo.addItem( icons[i] );
      this.icon_Combo.setScaledMinWidth( 320 );

      let empty = new Label( this );
      empty.wordWrapping = true;
      empty.text = icons.length ? "" : "No process icons are on the workspace.";

      let dialog = this;
      let ok = new PushButton( this );
      ok.text = "OK";
      ok.defaultButton = true;
      ok.enabled = icons.length > 0;
      ok.onClick = function()
      {
         if ( dialog.icon_Combo.numberOfItems <= 0 )
            return;
         dialog.iconName = dialog.icon_Combo.itemText( dialog.icon_Combo.currentItem );
         dialog.ok();
      };
      let cancel = new PushButton( this );
      cancel.text = "Cancel";
      cancel.onClick = function() { dialog.cancel(); };

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( ok );
      buttons.add( cancel );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( help );
      this.sizer.add( this.icon_Combo );
      if ( !icons.length )
         this.sizer.add( empty );
      this.sizer.add( buttons );
      this.setScaledMinWidth( 420 );
   }
};

// ----------------------------------------------------------------------------

var FazaSetupDialog = class extends Dialog
{
   constructor( slot, step, par )
   {
      super();
      this.slot = slot;
      this.step = step;
      this.par = par;
      this.windowTitle = slot + "  " + step.title;
      this.userResizable = true;
      let dialog = this;
      let body = new VerticalSizer;
      body.spacing = 6;
      body.margin = 8;

      if ( step.kind == "spikeless" )
         this.buildSpikeLess( body );
      else if ( step.kind == "blurx" )
         this.buildBlurX( body );
      else if ( step.kind == "blurless" )
         this.buildBlurless( body );
      else if ( step.kind == "spfc" )
         this.buildFlux( body );
      else if ( step.kind == "mgc" )
         this.buildGradient( body );
      else if ( step.kind == "spcc" )
         this.buildColor( body );
      else if ( step.kind == "noisex" )
         this.buildNoise( body );
      else if ( step.kind == "starx" )
         this.buildStars( body );
      else if ( step.kind == "screen" )
         this.buildScreen( body );
      else if ( step.kind == "stretch" )
         this.buildStretch( body );
      else if ( step.kind == "icon" )
         this.buildIcon( body );
      else if ( step.kind == "autoassign" )
         this.buildAutoAssign( body );
      else if ( step.kind == "composergb" )
         this.buildComposeRGB( body );
      else if ( step.kind == "hdrmt" )
         this.buildHDRMT( body );
      else if ( step.kind == "lrgbcomb" )
         this.buildLRGBComb( body );
      else if ( step.kind == "starstretch" )
         this.buildStarStretch( body );
      else if ( step.kind == "histo" )
         this.buildHisto( body );
      else if ( step.kind == "putstars" )
         this.buildPutStars( body );

      let okButton = new PushButton( this );
      okButton.text = "OK";
      okButton.defaultButton = true;
      okButton.onClick = function()
      {
         if ( dialog.readBack() )
            dialog.ok();
      };
      let cancelButton = new PushButton( this );
      cancelButton.text = "Cancel";
      cancelButton.onClick = function()
      {
         dialog.cancel();
      };
      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( okButton );
      buttons.add( cancelButton );
      body.addSpacing( 8 );
      body.add( buttons );
      this.sizer = body;
      this.setScaledMinWidth( 560 );
   }

   label( text, width )
   {
      let item = new Label( this );
      item.text = text;
      item.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      item.setScaledFixedWidth( width || 230 );
      return item;
   }

   edit( value, digits )
   {
      let item = new Edit( this );
      item.text = f1Format( value, digits );
      item.setScaledFixedWidth( 90 );
      return item;
   }

   channelEdit( value )
   {
      let item = new Edit( this );
      item.text = value == null ? "" : String( value );
      item.setScaledMinWidth( 160 );
      item.setScaledFixedWidth( 180 );
      return item;
   }

   readChannel( edit, fallback )
   {
      let text = edit && edit.text != null ? String( edit.text ).replace( /^\s+|\s+$/g, "" ) : "";
      return text || fallback || "";
   }

   row( caption, control )
   {
      let line = new HorizontalSizer;
      line.spacing = 6;
      line.add( this.label( caption ) );
      line.add( control );
      line.addStretch();
      let box = new Control( this );
      box.sizer = line;
      return box;
   }

   addChannelIO( body, fields )
   {
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "View names drive which image this step uses. Defaults follow the standard "
                + "Post pipeline. If LRGBCombination is skipped, HistogramTransformation and "
                + "PixelMath keep input LRGB but fall back to RGB at runtime.";
      body.add( note );
      if ( fields.input != null )
      {
         this.in_Edit = this.channelEdit( fields.input );
         body.add( this.row( "Input view", this.in_Edit ) );
      }
      if ( fields.inputL != null )
      {
         this.inL_Edit = this.channelEdit( fields.inputL );
         body.add( this.row( "Input L", this.inL_Edit ) );
      }
      if ( fields.inputRGB != null )
      {
         this.inRGB_Edit = this.channelEdit( fields.inputRGB );
         body.add( this.row( "Input RGB", this.inRGB_Edit ) );
      }
      if ( fields.inputStars != null )
      {
         this.inStars_Edit = this.channelEdit( fields.inputStars );
         body.add( this.row( "Input stars", this.inStars_Edit ) );
      }
      if ( fields.inputTarget != null )
      {
         this.inTarget_Edit = this.channelEdit( fields.inputTarget );
         body.add( this.row( "Input target", this.inTarget_Edit ) );
      }
      if ( fields.output != null )
      {
         this.out_Edit = this.channelEdit( fields.output );
         body.add( this.row( "Output view", this.out_Edit ) );
      }
   }

   namesFor( channel, selected )
   {
      let items = f1.db[channel] ? f1.db[channel].slice( 0 ) : [];
      if ( selected && items.indexOf( selected ) < 0 )
         items.unshift( selected );
      if ( items.length == 0 && selected )
         items.push( selected );
      return items;
   }

   combo( channel, selected )
   {
      let box = new ComboBox( this );
      let items = this.namesFor( channel, selected );
      for ( let i = 0; i < items.length; ++i )
         box.addItem( items[i] );
      let index = 0;
      for ( let i = 0; i < items.length; ++i )
         if ( items[i] == selected )
            index = i;
      if ( box.numberOfItems > 0 )
         box.currentItem = index;
      box.setScaledMinWidth( 280 );
      return box;
   }

   listCombo( items, selected, width )
   {
      let box = new ComboBox( this );
      let list = items.slice( 0 );
      if ( selected && list.indexOf( selected ) < 0 )
         list.unshift( selected );
      for ( let i = 0; i < list.length; ++i )
         box.addItem( list[i] );
      let index = 0;
      for ( let i = 0; i < list.length; ++i )
         if ( list[i] == selected )
            index = i;
      if ( box.numberOfItems > 0 )
         box.currentItem = index;
      box.setScaledMinWidth( width || 220 );
      return box;
   }

   chosen( box )
   {
      if ( !box || box.numberOfItems < 1 || box.currentItem < 0 )
         return "";
      return box.itemText( box.currentItem );
   }

   buildIcon( body )
   {
      let dialog = this;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Parameters were copied from a process icon. "
                + "They are stored in this script. Changing or deleting the icon later does not change this step.";
      body.add( note );
      this.process_Label = new Label( this );
      this.process_Label.text = this.par.processId || "";
      body.add( this.row( "Process", this.process_Label ) );
      this.icon_Label = new Label( this );
      this.icon_Label.text = this.par.iconName || "";
      body.add( this.row( "Copied from icon", this.icon_Label ) );

      let replace = new PushButton( this );
      replace.text = "Replace from process icon";
      replace.onClick = function()
      {
         let pick = new F1IconPickDialog();
         if ( !pick.execute() || !pick.iconName )
            return;
         try
         {
            let snap = f1SnapshotFromIcon( pick.iconName );
            dialog.par.processId = snap.processId;
            dialog.par.iconName = snap.iconName;
            dialog.par.source = snap.source;
            dialog.par.title = snap.title;
            dialog.process_Label.text = snap.processId;
            dialog.icon_Label.text = snap.iconName;
            dialog.step.title = snap.title;
            dialog.step.processId = snap.processId;
            dialog.windowTitle = dialog.slot + "  " + snap.title;
         }
         catch ( e )
         {
            f1Message( e.message ? e.message : e.toString() );
         }
      };
      body.add( replace );
   }

   buildSpikeLess( body )
   {
      this.model_Combo = this.listCombo( [ "SpikeLessAI v2", "SpikeLessAI v1" ], this.par.model );
      this.mode_Combo = this.listCombo( [ "Linear", "Stretched" ], this.par.mode );
      this.strength_Edit = this.edit( this.par.strength, 2 );
      this.stride_Edit = this.edit( this.par.stride, 0 );
      this.starLayer_Combo = this.listCombo( [ "None", "Auto" ], this.par.starLayer );
      this.spikeImage_Check = new CheckBox( this );
      this.spikeImage_Check.text = "Generate spike image";
      this.spikeImage_Check.checked = this.par.generateSpikeImage ? true : false;
      this.tails_Check = new CheckBox( this );
      this.tails_Check.text = "Clean long spike tails";
      this.tails_Check.checked = this.par.cleanLongTails ? true : false;
      body.add( this.row( "Model", this.model_Combo ) );
      body.add( this.row( "Mode", this.mode_Combo ) );
      body.add( this.row( "Strength", this.strength_Edit ) );
      body.add( this.row( "Tile stride", this.stride_Edit ) );
      body.add( this.row( "Star layer", this.starLayer_Combo ) );
      body.add( this.spikeImage_Check );
      body.add( this.tails_Check );
   }

   buildBlurX( body )
   {
      this.correct_Check = new CheckBox( this );
      this.correct_Check.text = "Correct Only";
      this.correct_Check.checked = this.par.correctOnly ? true : false;
      this.stars_Edit = this.edit( this.par.sharpenStars, 2 );
      this.halos_Edit = this.edit( this.par.starHalos, 2 );
      this.nonstellar_Edit = this.edit( this.par.sharpenNonstellar, 2 );
      this.overlap_Edit = this.edit( this.par.overlap, 2 );
      let dialog = this;
      let apply = function()
      {
         let on = dialog.correct_Check.checked;
         dialog.stars_Edit.enabled = !on;
         dialog.halos_Edit.enabled = !on;
         dialog.nonstellar_Edit.enabled = !on;
      };
      this.correct_Check.onCheck = apply;
      apply();
      body.add( this.correct_Check );
      body.add( this.row( "Sharpen Stars", this.stars_Edit ) );
      body.add( this.row( "Adjust Star Halos", this.halos_Edit ) );
      body.add( this.row( "Sharpen Nonstellar", this.nonstellar_Edit ) );
      body.add( this.row( "Overlap", this.overlap_Edit ) );
   }

   buildBlurless( body )
   {
      this.amount_Edit = this.edit( this.par.amount, 2 );
      this.cores_Combo = this.listCombo( [ "Clip", "Keep", "Rescale" ], this.par.coresAbove );
      this.colourLabels = [ "Each channel", "Luminance" ];
      this.colourValues = [ "Channels", "Luminance" ];
      this.colour_Combo = this.listCombo( this.colourLabels,
                                         this.par.colourMode == "Luminance" ? "Luminance" : "Each channel" );
      this.align_Check = new CheckBox( this );
      this.align_Check.text = "Align channels";
      this.align_Check.checked = this.par.alignChannels ? true : false;
      this.crisper_Check = new CheckBox( this );
      this.crisper_Check.text = "Crisper spikes";
      this.crisper_Check.checked = this.par.crisperSpikes ? true : false;
      body.add( this.row( "Amount", this.amount_Edit ) );
      body.add( this.row( "Cores above 1.0", this.cores_Combo ) );
      body.add( this.row( "Color", this.colour_Combo ) );
      body.add( this.align_Check );
      body.add( this.crisper_Check );
   }

   buildFlux( body )
   {
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = this.par.narrowband ? true : false;
      this.wave_Edit = this.edit( this.par.wavelength, 1 );
      this.band_Edit = this.edit( this.par.bandwidth, 1 );
      this.sensor_Combo = this.combo( "Q", this.par.sensorName );
      this.gray_Combo = null;
      this.red_Combo = null;
      this.green_Combo = null;
      this.blue_Combo = null;
      this.waveRow = this.row( "Wavelength", this.wave_Edit );
      this.bandRow = this.row( "Bandwidth", this.band_Edit );
      this.filterRows = [];
      if ( this.slot == "RGB" )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else if ( this.slot == "R" )
      {
         this.red_Combo = this.combo( "R", this.par.redName );
         this.filterRows.push( this.row( "Red filter", this.red_Combo ) );
      }
      else if ( this.slot == "G" )
      {
         this.green_Combo = this.combo( "G", this.par.greenName );
         this.filterRows.push( this.row( "Green filter", this.green_Combo ) );
      }
      else if ( this.slot == "B" )
      {
         this.blue_Combo = this.combo( "B", this.par.blueName );
         this.filterRows.push( this.row( "Blue filter", this.blue_Combo ) );
      }
      else
      {
         this.gray_Combo = this.combo( f1GrayChannel( this.slot ), this.par.grayName );
         this.filterRows.push( this.row( "Gray filter", this.gray_Combo ) );
      }
      let dialog = this;
      let apply = function( resize )
      {
         let on = dialog.narrow_Check.checked;
         if ( on )
         {
            dialog.waveRow.show();
            dialog.bandRow.show();
         }
         else
         {
            dialog.waveRow.hide();
            dialog.bandRow.hide();
         }
         for ( let i = 0; i < dialog.filterRows.length; ++i )
         {
            if ( on )
               dialog.filterRows[i].hide();
            else
               dialog.filterRows[i].show();
         }
         if ( resize )
            dialog.adjustToContents();
      };
      this.narrow_Check.onCheck = function()
      {
         apply( true );
      };
      body.add( this.narrow_Check );
      body.add( this.waveRow );
      body.add( this.bandRow );
      for ( let i = 0; i < this.filterRows.length; ++i )
         body.add( this.filterRows[i] );
      body.add( this.row( "QE curve", this.sensor_Combo ) );
      apply( false );
   }

   buildGradient( body )
   {
      this.scale_Edit = this.edit( this.par.scale, 0 );
      this.separation_Edit = this.edit( this.par.separation, 0 );
      this.smooth_Edit = this.edit( this.par.smoothness, 2 );
      this.mars_Combo = new ComboBox( this );
      let mars = [ "Ha", "OIII", "SII", "L", "R", "G", "B" ];
      if ( mars.indexOf( this.par.grayFilter ) < 0 )
         mars.unshift( this.par.grayFilter );
      for ( let i = 0; i < mars.length; ++i )
         this.mars_Combo.addItem( mars[i] );
      let index = 0;
      for ( let i = 0; i < mars.length; ++i )
         if ( mars[i] == this.par.grayFilter )
            index = i;
      this.mars_Combo.currentItem = index;
      this.show_Check = new CheckBox( this );
      this.show_Check.text = "Show gradient model";
      this.show_Check.checked = this.par.showModel ? true : false;
      body.add( this.row( "Gradient scale", this.scale_Edit ) );
      body.add( this.row( "Structure separation", this.separation_Edit ) );
      body.add( this.row( "Model smoothness", this.smooth_Edit ) );
      body.add( this.row( "Gray filter", this.mars_Combo ) );
      if ( this.slot == "RGB" )
      {
         let note = new Label( this );
         note.wordWrapping = true;
         note.text = "Red, Green and Blue use the Red filter, Green filter and Blue filter. Gray filter above is the gray reference.";
         body.add( note );
      }
      body.add( this.show_Check );
      this.buildMarsFiles( body );
   }

   buildMarsFiles( body )
   {
      let dialog = this;
      this.marsFiles = f1MarsFiles().slice( 0 );

      let title = new Label( this );
      title.text = "MARS database files";
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Shared by every filter.";

      this.mars_Tree = new TreeBox( this );
      this.mars_Tree.numberOfColumns = 1;
      this.mars_Tree.headerVisible = false;
      this.mars_Tree.rootDecoration = false;
      this.mars_Tree.multipleSelection = true;
      this.mars_Tree.setScaledMinHeight( 90 );

      let fill = function()
      {
         dialog.mars_Tree.clear();
         for ( let i = 0; i < dialog.marsFiles.length; ++i )
         {
            let node = new TreeBoxNode( dialog.mars_Tree );
            node.setText( 0, dialog.marsFiles[i] );
            if ( !File.exists( dialog.marsFiles[i] ) )
               node.setToolTip( 0, "File not found." );
         }
      };
      fill();

      let add = new PushButton( this );
      add.text = "Add";
      add.onClick = function()
      {
         let fd = new OpenFileDialog;
         fd.caption = "MARS database files";
         fd.multipleSelections = true;
         fd.filters = [ [ "MARS database files", "*.xmars" ], [ "All files", "*" ] ];
         if ( fd.execute() )
         {
            for ( let i = 0; i < fd.fileNames.length; ++i )
               if ( dialog.marsFiles.indexOf( fd.fileNames[i] ) < 0 )
                  dialog.marsFiles.push( fd.fileNames[i] );
            fill();
         }
      };

      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.onClick = function()
      {
         let keep = [];
         for ( let i = 0; i < dialog.mars_Tree.numberOfChildren; ++i )
            if ( !dialog.mars_Tree.child( i ).selected )
               keep.push( dialog.marsFiles[i] );
         dialog.marsFiles = keep;
         fill();
      };

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( add );
      buttons.add( remove );

      body.addSpacing( 6 );
      body.add( title );
      body.add( note );
      body.add( this.mars_Tree, 100 );
      body.add( buttons );
   }

   buildColor( body )
   {
      this.narrow_Check = new CheckBox( this );
      this.narrow_Check.text = "Narrowband filters mode";
      this.narrow_Check.checked = this.par.narrowband ? true : false;
      this.red_Combo = this.combo( "R", this.par.redName );
      this.green_Combo = this.combo( "G", this.par.greenName );
      this.blue_Combo = this.combo( "B", this.par.blueName );
      this.sensor_Combo = this.combo( "Q", this.par.sensorName );
      body.add( this.narrow_Check );
      body.add( this.row( "Red filter", this.red_Combo ) );
      body.add( this.row( "Green filter", this.green_Combo ) );
      body.add( this.row( "Blue filter", this.blue_Combo ) );
      body.add( this.row( "QE curve", this.sensor_Combo ) );
   }

   buildNoise( body )
   {
      this.denoise_Edit = this.edit( this.par.denoise, 2 );
      this.detail_Edit = this.edit( this.par.detail, 2 );
      body.add( this.row( "Denoise", this.denoise_Edit ) );
      body.add( this.row( "Detail", this.detail_Edit ) );
   }

   buildStars( body )
   {
      this.stars_Check = new CheckBox( this );
      this.stars_Check.text = "Star image";
      this.stars_Check.checked = this.par.outputStars ? true : false;
      this.stars_Check.toolTip = "<p>When checked, a stars window stays open as well. Otherwise the image stays starless.</p>";
      this.unscreen_Check = new CheckBox( this );
      this.unscreen_Check.text = "Unscreen";
      this.unscreen_Check.checked = this.par.unscreen ? true : false;
      let dialog = this;
      let apply = function()
      {
         dialog.unscreen_Check.enabled = dialog.stars_Check.checked;
      };
      this.stars_Check.onCheck = apply;
      apply();
      body.add( this.stars_Check );
      body.add( this.unscreen_Check );
   }

   buildScreen( body )
   {
      this.linked_Check = new CheckBox( this );
      this.linked_Check.text = "Link RGB Channels";
      this.linked_Check.checked = this.par.linked ? true : false;
      this.shadows_Edit = this.edit( this.par.shadows, 1 );
      this.target_Edit = this.edit( this.par.target, 2 );
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Only the display changes. Pixels stay linear.";
      body.add( note );
      body.add( this.linked_Check );
      body.add( this.row( "Shadows clipping", this.shadows_Edit ) );
      body.add( this.row( "Target background", this.target_Edit ) );
   }

   buildStretch( body )
   {
      this.target_Edit = this.edit( this.par.targetBackground, 2 );
      this.aggressive_Edit = this.edit( this.par.aggressiveness, 2 );
      this.range_Edit = this.edit( this.par.dynamicRange, 2 );
      this.recovery_Check = new CheckBox( this );
      this.recovery_Check.text = "Contrast Recovery";
      this.recovery_Check.checked = this.par.contrastRecovery ? true : false;
      this.separation_Edit = this.edit( this.par.scaleSeparation, 0 );
      this.intensity_Edit = this.edit( this.par.intensity, 2 );
      this.saturation_Check = new CheckBox( this );
      this.saturation_Check.text = "Color Saturation";
      this.saturation_Check.checked = this.par.saturation ? true : false;
      this.amount_Edit = this.edit( this.par.saturationAmount, 2 );
      this.boost_Edit = this.edit( this.par.saturationBoost, 2 );
      let dialog = this;
      let apply = function()
      {
         let recovery = dialog.recovery_Check.checked;
         dialog.separation_Edit.enabled = recovery;
         dialog.intensity_Edit.enabled = recovery;
         let color = dialog.saturation_Check.checked;
         dialog.amount_Edit.enabled = color;
         dialog.boost_Edit.enabled = color;
      };
      this.recovery_Check.onCheck = apply;
      this.saturation_Check.onCheck = apply;
      apply();
      body.add( this.row( "Target background", this.target_Edit ) );
      body.add( this.row( "Aggressiveness", this.aggressive_Edit ) );
      body.add( this.row( "Dynamic range compression", this.range_Edit ) );
      body.add( this.recovery_Check );
      body.add( this.row( "Scale separation", this.separation_Edit ) );
      body.add( this.row( "Intensity", this.intensity_Edit ) );
      body.add( this.saturation_Check );
      body.add( this.row( "Amount", this.amount_Edit ) );
      body.add( this.row( "Boost", this.boost_Edit ) );
   }

   needNumber( edit, label, allowNegative )
   {
      let value = f1Parse( edit.text );
      if ( value == null || ( !allowNegative && !( value > 0 ) ) || ( allowNegative && !isFinite( value ) ) )
      {
         f1Message( label + " is not a number." );
         return null;
      }
      return value;
   }

   readBack()
   {
      let par = this.par;
      if ( this.step.kind == "spikeless" )
      {
         let strength = this.needNumber( this.strength_Edit, "Strength", true );
         let stride = this.needNumber( this.stride_Edit, "Tile stride", false );
         if ( strength == null || stride == null || strength < 0 || strength > 1 )
         {
            if ( strength != null && ( strength < 0 || strength > 1 ) )
               f1Message( "Strength must be between 0 and 1." );
            return false;
         }
         par.model = this.chosen( this.model_Combo );
         par.mode = this.chosen( this.mode_Combo );
         par.strength = strength;
         par.stride = stride;
         par.starLayer = this.chosen( this.starLayer_Combo );
         par.generateSpikeImage = this.spikeImage_Check.checked;
         par.cleanLongTails = this.tails_Check.checked;
         return true;
      }
      if ( this.step.kind == "blurx" )
      {
         let overlap = this.needNumber( this.overlap_Edit, "Overlap", false );
         let stars = this.needNumber( this.stars_Edit, "Sharpen Stars", true );
         let halos = this.needNumber( this.halos_Edit, "Adjust Star Halos", true );
         let nonstellar = this.needNumber( this.nonstellar_Edit, "Sharpen Nonstellar", true );
         if ( overlap == null || stars == null || halos == null || nonstellar == null )
            return false;
         par.correctOnly = this.correct_Check.checked;
         par.overlap = overlap;
         par.sharpenStars = stars;
         par.starHalos = halos;
         par.sharpenNonstellar = nonstellar;
         return true;
      }
      if ( this.step.kind == "icon" )
         return true;
      if ( this.step.kind == "blurless" )
      {
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         if ( amount == null || amount < 0 || amount > 1 )
         {
            if ( amount != null )
               f1Message( "Amount must be between 0 and 1." );
            return false;
         }
         par.amount = amount;
         par.coresAbove = this.chosen( this.cores_Combo );
         let colourIndex = this.colour_Combo.currentItem;
         if ( colourIndex < 0 )
            colourIndex = 0;
         par.colourMode = this.colourValues[colourIndex];
         par.alignChannels = this.align_Check.checked;
         par.crisperSpikes = this.crisper_Check.checked;
         return true;
      }
      if ( this.step.kind == "spfc" )
      {
         let wave = this.needNumber( this.wave_Edit, "Wavelength", false );
         let band = this.needNumber( this.band_Edit, "Bandwidth", false );
         if ( wave == null || band == null )
            return false;
         par.narrowband = this.narrow_Check.checked;
         par.wavelength = wave;
         par.bandwidth = band;
         if ( this.gray_Combo )
            par.grayName = this.chosen( this.gray_Combo );
         if ( this.red_Combo )
            par.redName = this.chosen( this.red_Combo );
         if ( this.green_Combo )
            par.greenName = this.chosen( this.green_Combo );
         if ( this.blue_Combo )
            par.blueName = this.chosen( this.blue_Combo );
         if ( this.slot == "R" && this.red_Combo )
            par.grayName = par.redName;
         else if ( this.slot == "G" && this.green_Combo )
            par.grayName = par.greenName;
         else if ( this.slot == "B" && this.blue_Combo )
            par.grayName = par.blueName;
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "mgc" )
      {
         let scale = this.needNumber( this.scale_Edit, "Gradient scale", false );
         let separation = this.needNumber( this.separation_Edit, "Structure separation", false );
         let smoothness = this.needNumber( this.smooth_Edit, "Model smoothness", false );
         if ( scale == null || separation == null || smoothness == null )
            return false;
         par.scale = scale;
         par.separation = separation;
         par.smoothness = smoothness;
         par.grayFilter = this.chosen( this.mars_Combo );
         par.showModel = this.show_Check.checked;
         f1WriteMarsFiles( this.marsFiles );
         return true;
      }
      if ( this.step.kind == "spcc" )
      {
         par.narrowband = this.narrow_Check.checked;
         par.redName = this.chosen( this.red_Combo );
         par.greenName = this.chosen( this.green_Combo );
         par.blueName = this.chosen( this.blue_Combo );
         par.sensorName = this.chosen( this.sensor_Combo );
         return true;
      }
      if ( this.step.kind == "noisex" )
      {
         let denoise = this.needNumber( this.denoise_Edit, "Denoise", true );
         let detail = this.needNumber( this.detail_Edit, "Detail", true );
         if ( denoise == null || detail == null )
            return false;
         par.denoise = denoise;
         par.detail = detail;
         return true;
      }
      if ( this.step.kind == "starx" )
      {
         par.outputStars = this.stars_Check.checked;
         par.unscreen = this.unscreen_Check.checked;
         return true;
      }
      if ( this.step.kind == "screen" )
      {
         let shadows = this.needNumber( this.shadows_Edit, "Shadows clipping", true );
         let target = this.needNumber( this.target_Edit, "Target background", false );
         if ( shadows == null || target == null )
            return false;
         par.linked = this.linked_Check.checked;
         par.shadows = shadows;
         par.target = target;
         return true;
      }
      if ( this.step.kind == "stretch" )
      {
         let target = this.needNumber( this.target_Edit, "Target background", false );
         let aggressive = this.needNumber( this.aggressive_Edit, "Aggressiveness", true );
         let range = this.needNumber( this.range_Edit, "Dynamic range compression", true );
         let separation = this.needNumber( this.separation_Edit, "Scale separation", false );
         let intensity = this.needNumber( this.intensity_Edit, "Intensity", true );
         let amount = this.needNumber( this.amount_Edit, "Amount", true );
         let boost = this.needNumber( this.boost_Edit, "Boost", true );
         if ( target == null || aggressive == null || range == null || separation == null
              || intensity == null || amount == null || boost == null )
            return false;
         par.targetBackground = target;
         par.aggressiveness = aggressive;
         par.dynamicRange = range;
         par.contrastRecovery = this.recovery_Check.checked;
         par.scaleSeparation = separation;
         par.intensity = intensity;
         par.saturation = this.saturation_Check.checked;
         par.saturationAmount = amount;
         par.saturationBoost = boost;
         return true;
      }
      if ( this.step.kind == "autoassign" )
      {
         par.preferFits = this.preferFits_Check.checked;
         return true;
      }
      if ( this.step.kind == "composergb" )
         return true;
      if ( this.step.kind == "hdrmt" )
      {
         let layers = this.needNumber( this.layers_Edit, "Number of layers", false );
         let iterations = this.needNumber( this.iterations_Edit, "Number of iterations", false );
         let overdrive = this.needNumber( this.overdrive_Edit, "Overdrive", true );
         if ( layers == null || iterations == null || overdrive == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "RGB" );
         par.output = this.readChannel( this.out_Edit, par.input );
         par.numberOfLayers = Math.round( layers );
         par.numberOfIterations = Math.round( iterations );
         par.invertedIterations = this.inverted_Check.checked;
         par.overdrive = overdrive;
         par.medianTransform = this.median_Check.checked;
         par.toIntensity = this.toIntensity_Check.checked;
         par.toLightness = this.toLightness_Check.checked;
         par.preserveHue = this.preserveHue_Check.checked;
         par.luminanceMask = this.luminanceMask_Check.checked;
         return true;
      }
      if ( this.step.kind == "lrgbcomb" )
      {
         let mL = this.needNumber( this.mL_Edit, "Lightness", true );
         let mc = this.needNumber( this.mc_Edit, "Saturation", true );
         if ( mL == null || mc == null )
            return false;
         par.inputL = this.readChannel( this.inL_Edit, "L" );
         par.inputRGB = this.readChannel( this.inRGB_Edit, "RGB" );
         par.output = this.readChannel( this.out_Edit, "LRGB" );
         par.mL = mL;
         par.mc = mc;
         par.clipHighlights = this.clip_Check.checked;
         return true;
      }
      if ( this.step.kind == "starstretch" )
      {
         let amount = this.needNumber( this.ssAmount_Edit, "Stretch amount", false );
         let sat = this.needNumber( this.ssSat_Edit, "Color boost", true );
         if ( amount == null || sat == null )
            return false;
         par.input = this.readChannel( this.in_Edit, "RGB_stars" );
         par.output = this.readChannel( this.out_Edit, par.input );
         par.amount = amount;
         par.satAmount = sat;
         par.removeGreen = this.ssGreen_Check.checked;
         return true;
      }
      if ( this.step.kind == "histo" )
      {
         par.input = this.readChannel( this.in_Edit, "LRGB" );
         par.output = this.readChannel( this.out_Edit, par.input );
         if ( this.resetHisto_Check && this.resetHisto_Check.checked )
            par.H = f1CloneHistoH( F1_DEFAULT_HISTO_H );
         else if ( !par.H || !par.H.length )
            par.H = f1CloneHistoH( F1_DEFAULT_HISTO_H );
         return true;
      }
      if ( this.step.kind == "putstars" )
      {
         par.inputStars = this.readChannel( this.inStars_Edit, "RGB_stars" );
         par.inputTarget = this.readChannel( this.inTarget_Edit, "LRGB" );
         par.output = this.readChannel( this.out_Edit, par.inputTarget );
         let expr = this.pmExpr_Edit.text.replace( /^\s+|\s+$/g, "" );
         if ( !expr.length
              || expr == "combine(RGB_stars, LRGB, op_screen())"
              || /^combine\([^,]+,\s*[^,]+,\s*op_screen\(\)\)$/.test( expr ) )
            expr = "combine(" + par.inputStars + ", " + par.inputTarget + ", op_screen())";
         par.expression = expr;
         return true;
      }
      return true;
   }

   buildAutoAssign( body )
   {
      this.preferFits_Check = new CheckBox( this );
      this.preferFits_Check.text = "Prefer FITS/XISF FILTER keyword over file name";
      this.preferFits_Check.checked = this.par.preferFits !== false;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Detects Ha, OIII, SII, L, R, G, B or RGB from keywords or names, "
                + "renames each view to that short id, and fills the matching row.";
      body.add( note );
      body.add( this.preferFits_Check );
   }

   buildComposeRGB( body )
   {
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Combines R+G+B with ChannelCombination (no L), renames the result to RGB, "
                + "fills the RGB filter row, and clears the R/G/B rows so only the combined "
                + "RGB continues in the filter chain.";
      body.add( note );
   }

   buildHDRMT( body )
   {
      this.addChannelIO( body, {
         input: this.par.input || "RGB",
         output: this.par.output || this.par.input || "RGB"
      } );
      this.layers_Edit = this.edit( this.par.numberOfLayers != null ? this.par.numberOfLayers : 6, 0 );
      this.iterations_Edit = this.edit( this.par.numberOfIterations != null ? this.par.numberOfIterations : 1, 0 );
      this.overdrive_Edit = this.edit( this.par.overdrive != null ? this.par.overdrive : 0, 3 );
      this.inverted_Check = new CheckBox( this );
      this.inverted_Check.text = "Inverted";
      this.inverted_Check.checked = this.par.invertedIterations !== false;
      this.median_Check = new CheckBox( this );
      this.median_Check.text = "Median transform";
      this.median_Check.checked = this.par.medianTransform ? true : false;
      this.toIntensity_Check = new CheckBox( this );
      this.toIntensity_Check.text = "To intensity";
      this.toIntensity_Check.checked = this.par.toIntensity ? true : false;
      this.toLightness_Check = new CheckBox( this );
      this.toLightness_Check.text = "To lightness";
      this.toLightness_Check.checked = this.par.toLightness ? true : false;
      this.preserveHue_Check = new CheckBox( this );
      this.preserveHue_Check.text = "Preserve hue";
      this.preserveHue_Check.checked = this.par.preserveHue ? true : false;
      this.luminanceMask_Check = new CheckBox( this );
      this.luminanceMask_Check.text = "Lightness mask";
      this.luminanceMask_Check.checked = this.par.luminanceMask !== false;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Defaults: 6 layers, 1 iteration, Inverted, B3 Spline (5), Lightness mask. "
                + "Standard pipeline uses RGB in and RGB out.";
      body.add( note );
      body.add( this.row( "Number of layers", this.layers_Edit ) );
      body.add( this.row( "Number of iterations", this.iterations_Edit ) );
      body.add( this.inverted_Check );
      body.add( this.row( "Overdrive", this.overdrive_Edit ) );
      body.add( this.median_Check );
      body.add( this.toIntensity_Check );
      body.add( this.toLightness_Check );
      body.add( this.preserveHue_Check );
      body.add( this.luminanceMask_Check );
   }

   buildLRGBComb( body )
   {
      this.addChannelIO( body, {
         inputL: this.par.inputL || "L",
         inputRGB: this.par.inputRGB || "RGB",
         output: this.par.output || "LRGB"
      } );
      this.mL_Edit = this.edit( this.par.mL, 3 );
      this.mc_Edit = this.edit( this.par.mc, 3 );
      this.clip_Check = new CheckBox( this );
      this.clip_Check.text = "Clip highlights";
      this.clip_Check.checked = this.par.clipHighlights !== false;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Applies Input L onto Input RGB and creates Output view.";
      body.add( note );
      body.add( this.row( "Lightness", this.mL_Edit ) );
      body.add( this.row( "Saturation", this.mc_Edit ) );
      body.add( this.clip_Check );
   }

   buildStarStretch( body )
   {
      this.addChannelIO( body, {
         input: this.par.input || "RGB_stars",
         output: this.par.output || this.par.input || "RGB_stars"
      } );
      this.ssAmount_Edit = this.edit( this.par.amount, 2 );
      this.ssSat_Edit = this.edit( this.par.satAmount, 2 );
      this.ssGreen_Check = new CheckBox( this );
      this.ssGreen_Check.text = "Remove green via SCNR";
      this.ssGreen_Check.checked = this.par.removeGreen ? true : false;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Uses Franklin Marek's SetiAstro Star Stretch script (not a reimplementation). "
                + "Place star_stretch.js beside this script or keep the SetiAstro install.";
      body.add( note );
      body.add( this.row( "Stretch amount", this.ssAmount_Edit ) );
      body.add( this.row( "Color boost", this.ssSat_Edit ) );
      body.add( this.ssGreen_Check );
   }

   buildHisto( body )
   {
      this.addChannelIO( body, {
         input: this.par.input || "LRGB",
         output: this.par.output || this.par.input || "LRGB"
      } );
      this.resetHisto_Check = new CheckBox( this );
      this.resetHisto_Check.text = "Reset to default H curves";
      this.resetHisto_Check.checked = false;
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Before PixelMath. Default input LRGB; if missing, uses RGB. "
                + "Default H: G c0=0.03807615, c1=0.90581162.";
      body.add( note );
      body.add( this.resetHisto_Check );
   }

   buildPutStars( body )
   {
      this.addChannelIO( body, {
         inputStars: this.par.inputStars || "RGB_stars",
         inputTarget: this.par.inputTarget || "LRGB",
         output: this.par.output || this.par.inputTarget || "LRGB"
      } );
      this.pmExpr_Edit = new Edit( this );
      this.pmExpr_Edit.text = this.par.expression
         || "combine(RGB_stars, LRGB, op_screen())";
      this.pmExpr_Edit.setScaledMinWidth( 360 );
      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Screens stars onto target. Default expression follows the view names above. "
                + "If target LRGB is missing, falls back to RGB.";
      body.add( note );
      body.add( this.row( "Expression", this.pmExpr_Edit ) );
   }
};

var BatchProcessingDialog = class extends Dialog
{
   constructor()
   {
      super();
      this.windowTitle = "BatchProcessing_byHrast";
      this.userResizable = true;
      this.ready = false;
      this.loading = true;
      let dialog = this;

      this.help_Label = new Label( this );
      this.help_Label.wordWrapping = true;
      this.help_Label.text = "Pre can auto-assign filters and compose RGB from R+G+B. "
                            + "Then each filter row runs its steps. Post can run HDR, LRGB, "
                            + "Star Stretch, HistogramTransformation on LRGB, then PixelMath. "
                            + "Preset Save/Load stores setups inside PixInsight. "
                            + "Export/Import Settings uses a .bpshrast file.";

      this.lists = {};
      this.stepTrees = {};
      this.stepNodes = {};
      this.stepButton = {};
      this.stepUpButton = {};
      this.stepDownButton = {};
      this.stepAddButton = {};
      this.stepRemoveButton = {};
      this.phaseTrees = {};
      this.phaseNodes = {};
      this.phaseButton = {};
      this.phaseUpButton = {};
      this.phaseDownButton = {};
      this.phaseAddButton = {};
      this.phaseRemoveButton = {};
      let imageSizer = new VerticalSizer;
      imageSizer.spacing = 16;
      imageSizer.margin = 10;
      for ( let i = 0; i < F1_SLOTS.length; ++i )
         imageSizer.add( this.makeSlotBlock( F1_SLOTS[i] ) );

      this.image_Group = this.makeCollapsibleSection( "Images", imageSizer, true );
      this.pre_Group = this.makePhaseGroup( "pre", "Pre" );
      this.post_Group = this.makePhaseGroup( "post", "Post" );

      this.preset_Label = new Label( this );
      this.preset_Label.text = "Preset:";
      this.preset_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

      this.preset_Combo = new ComboBox( this );
      this.preset_Combo.editEnabled = true;
      this.preset_Combo.setScaledMinWidth( 180 );
      this.preset_Combo.toolTip = "<p>Quick profiles stored inside PixInsight. "
                                + "Default restores factory settings. Type a new name, then Save.</p>";

      this.presetSave_Button = new PushButton( this );
      this.presetSave_Button.text = "Save";
      this.presetSave_Button.toolTip = "<p>Save the current setup under the preset name in the box. "
                                    + "Does not overwrite Default — type a new name first.</p>";
      this.presetSave_Button.onClick = () => dialog.savePreset();

      this.presetLoad_Button = new PushButton( this );
      this.presetLoad_Button.text = "Load";
      this.presetLoad_Button.toolTip = "<p>Load the selected preset. Default resets Pre/Post and filter "
                                    + "steps to the original script defaults. Selected images stay.</p>";
      this.presetLoad_Button.onClick = () => dialog.loadPreset();

      this.exportSettings_Button = new PushButton( this );
      this.exportSettings_Button.text = "Export Settings";
      this.exportSettings_Button.toolTip = "<p>Export the current setup to a .bpshrast file on disk "
                                       + "(for backup or sharing).</p>";
      this.exportSettings_Button.onClick = () => dialog.exportSettingsFile();

      this.importSettings_Button = new PushButton( this );
      this.importSettings_Button.text = "Import Settings";
      this.importSettings_Button.toolTip = "<p>Import a .bpshrast file from disk. "
                                       + "Selected images stay; process order and parameters are replaced.</p>";
      this.importSettings_Button.onClick = () => dialog.importSettingsFile();

      this.run_Button = new PushButton( this );
      this.run_Button.text = "Process";
      this.run_Button.defaultButton = true;
      this.run_Button.onClick = () => dialog.run();

      this.close_Button = new PushButton( this );
      this.close_Button.text = "Close";
      this.close_Button.onClick = () =>
      {
         dialog.saveFromControls();
         dialog.cancel();
      };

      let presetRow = new HorizontalSizer;
      presetRow.spacing = 6;
      presetRow.add( this.preset_Label );
      presetRow.add( this.preset_Combo, 100 );
      presetRow.add( this.presetSave_Button );
      presetRow.add( this.presetLoad_Button );
      presetRow.addSpacing( 12 );
      presetRow.add( this.exportSettings_Button );
      presetRow.add( this.importSettings_Button );

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.addStretch();
      buttons.add( this.run_Button );
      buttons.add( this.close_Button );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.help_Label );
      this.sizer.add( this.pre_Group );
      this.sizer.add( this.image_Group, 100 );
      this.sizer.add( this.post_Group );
      this.sizer.add( presetRow );
      this.sizer.add( buttons );

      this.fillPresetCombo( f1ReadString( "lastPreset", "Default" ) );

      this.restoreViews();
      this.ensureLayoutUpdated();
      this.adjustToContents();
      this.setScaledMinWidth( 760 );
      this.loading = false;
      this.onHide = () =>
      {
         if ( !dialog.ready )
            return;
         try
         {
            dialog.saveFromControls();
         }
         catch ( e )
         {
         }
      };
      this.ready = true;
   }

   makeFixedLabel( text )
   {
      let label = new Label( this );
      label.text = text;
      label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      label.setScaledFixedWidth( 88 );
      return label;
   }

   makeCollapsibleSection( title, contentSizer, startOpen )
   {
      let dialog = this;
      let section = new Control( this );
      section.sizer = contentSizer;
      let bar = new SectionBar( this, title );
      bar.setSection( section );
      if ( !startOpen )
         section.hide();
      bar.updateIcon();
      bar.onToggleSection = function( sectionBar, toggleBegin )
      {
         if ( !toggleBegin )
         {
            dialog.ensureLayoutUpdated();
            dialog.adjustToContents();
         }
      };
      let wrap = new VerticalSizer;
      wrap.spacing = 0;
      wrap.add( bar );
      wrap.add( section );
      return wrap;
   }

   makePhaseGroup( name, title )
   {
      let dialog = this;
      let tree = new TreeBox( this );
      tree.numberOfColumns = 1;
      tree.headerVisible = false;
      tree.rootDecoration = false;
      tree.alternateRowColor = true;
      tree.multipleSelection = false;
      tree.nodeDragging = false;
      tree.setScaledMinHeight( 120 );
      this.phaseTrees[name] = tree;
      this.phaseNodes[name] = {};
      this.fillPhaseTree( name );

      tree.onNodeUpdated = function( node )
      {
         if ( dialog.loading )
            return;
         let step = dialog.phaseStepFromNode( name, node );
         if ( !step || !f1PhaseStepInstalled( step ) )
            return;
         f1[name].steps[step.id].on = node.checked ? true : false;
         dialog.syncPhaseButtons( name );
      };
      tree.onNodeDoubleClicked = function( node )
      {
         let step = dialog.phaseStepFromNode( name, node );
         if ( step )
            dialog.openPhaseStep( name, step );
      };
      tree.onCurrentNodeUpdated = function()
      {
         dialog.syncPhaseButtons( name );
      };

      let up = new ToolButton( this );
      up.setScaledFixedSize( 24, 24 );
      up.icon = this.scaledResource( ":/arrows/arrow-up.png" );
      up.onClick = function() { dialog.movePhaseStep( name, -1 ); };
      let down = new ToolButton( this );
      down.setScaledFixedSize( 24, 24 );
      down.icon = this.scaledResource( ":/arrows/arrow-down.png" );
      down.onClick = function() { dialog.movePhaseStep( name, 1 ); };
      let add = new PushButton( this );
      add.text = "+";
      add.toolTip = "<p>Add a process icon from the workspace.</p>";
      add.onClick = function() { dialog.addPhaseIconStep( name ); };
      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.onClick = function() { dialog.removePhaseIconStep( name ); };
      let setup = new PushButton( this );
      setup.text = "Settings";
      setup.onClick = function()
      {
         let step = dialog.phaseSelectedStep( name );
         if ( step )
            dialog.openPhaseStep( name, step );
      };
      this.phaseButton[name] = setup;
      this.phaseUpButton[name] = up;
      this.phaseDownButton[name] = down;
      this.phaseAddButton[name] = add;
      this.phaseRemoveButton[name] = remove;
      this.syncPhaseButtons( name );

      let note = new Label( this );
      note.wordWrapping = true;
      note.text = name == "pre"
         ? "Auto-assign renames open masters and fills rows. Compose RGB builds RGB from R+G+B."
         : "HDR on RGB, LRGB from L+RGB, SetiAstro Star Stretch on RGB_stars, then PixelMath screen.";

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.add( up );
      buttons.add( down );
      buttons.add( add );
      buttons.add( remove );
      buttons.addStretch();
      buttons.add( setup );

      let sizer = new VerticalSizer;
      sizer.margin = 8;
      sizer.spacing = 6;
      sizer.add( note );
      sizer.add( tree, 100 );
      sizer.add( buttons );

      // Collapsible so low-resolution screens can hide Pre / Post.
      return this.makeCollapsibleSection( title, sizer, true );
   }

   fillPhaseTree( name )
   {
      let tree = this.phaseTrees[name];
      tree.clear();
      this.phaseNodes[name] = {};
      let steps = f1PhaseOrderedSteps( name );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1[name].steps[step.id];
         let node = new TreeBoxNode( tree );
         let installed = f1PhaseStepInstalled( step );
         node.checkable = true;
         node.checked = installed && state.on ? true : false;
         node.setText( 0, step.title + ( installed ? "" : " (not installed)" ) );
         node.enabled = installed ? true : false;
         this.phaseNodes[name][step.id] = node;
      }
   }

   phaseStepFromNode( name, node )
   {
      if ( !node )
         return null;
      let map = this.phaseNodes[name];
      for ( let id in map )
         if ( map[id] === node )
         {
            let steps = f1PhaseAllSteps( name );
            for ( let i = 0; i < steps.length; ++i )
               if ( steps[i].id == id )
                  return steps[i];
         }
      return null;
   }

   phaseSelectedStep( name )
   {
      return this.phaseStepFromNode( name, this.phaseTrees[name].currentNode );
   }

   syncPhaseButtons( name )
   {
      let tree = this.phaseTrees[name];
      let node = tree ? tree.currentNode : null;
      let index = node ? tree.childIndex( node ) : -1;
      let step = this.phaseSelectedStep( name );
      if ( this.phaseButton[name] )
         this.phaseButton[name].enabled = step && f1PhaseStepInstalled( step ) ? true : false;
      if ( this.phaseUpButton[name] )
         this.phaseUpButton[name].enabled = index > 0;
      if ( this.phaseDownButton[name] )
         this.phaseDownButton[name].enabled = index >= 0 && index < tree.numberOfChildren - 1;
      if ( this.phaseRemoveButton[name] )
         this.phaseRemoveButton[name].enabled = step && step.kind == "icon" ? true : false;
   }

   readPhaseOrder( name )
   {
      let tree = this.phaseTrees[name];
      let order = [];
      for ( let i = 0; i < tree.numberOfChildren; ++i )
      {
         let step = this.phaseStepFromNode( name, tree.child( i ) );
         if ( step )
            order.push( step.id );
      }
      f1[name].order = f1PhaseNormalizeOrder( name, order );
   }

   movePhaseStep( name, delta )
   {
      let tree = this.phaseTrees[name];
      let node = tree.currentNode;
      if ( !node )
         return;
      let from = tree.childIndex( node );
      let to = from + delta;
      if ( from < 0 || to < 0 || to >= tree.numberOfChildren )
         return;
      tree.move( from, to );
      tree.currentNode = node;
      this.readPhaseOrder( name );
      this.syncPhaseButtons( name );
   }

   addPhaseIconStep( name )
   {
      let pick = new F1IconPickDialog();
      if ( !pick.execute() || !pick.iconName )
         return;
      try
      {
         let snap = f1SnapshotFromIcon( pick.iconName );
         let id = "icon_" + name + "_" + ( new Date() ).getTime().toString( 36 );
         let step = {
            id: id,
            title: snap.title,
            kind: "icon",
            processId: snap.processId
         };
         if ( !f1[name].extra )
            f1[name].extra = [];
         f1[name].extra.push( step );
         f1[name].steps[id] = {
            on: true,
            par: {
               processId: snap.processId,
               iconName: snap.iconName,
               source: snap.source,
               title: snap.title
            }
         };
         f1[name].order = f1PhaseNormalizeOrder( name, ( f1[name].order || [] ).concat( [ id ] ) );
         this.fillPhaseTree( name );
         if ( this.phaseNodes[name][id] )
            this.phaseTrees[name].currentNode = this.phaseNodes[name][id];
         this.syncPhaseButtons( name );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   removePhaseIconStep( name )
   {
      let step = this.phaseSelectedStep( name );
      if ( !step || step.kind != "icon" )
         return;
      let next = [];
      let extra = f1[name].extra || [];
      for ( let i = 0; i < extra.length; ++i )
         if ( extra[i].id != step.id )
            next.push( extra[i] );
      f1[name].extra = next;
      delete f1[name].steps[step.id];
      let order = [];
      let old = f1[name].order || [];
      for ( let i = 0; i < old.length; ++i )
         if ( old[i] != step.id )
            order.push( old[i] );
      f1[name].order = f1PhaseNormalizeOrder( name, order );
      this.fillPhaseTree( name );
      this.syncPhaseButtons( name );
   }

   openPhaseStep( name, step )
   {
      try
      {
         let gui = new FazaSetupDialog( name, step, f1[name].steps[step.id].par );
         if ( gui.execute() && step.kind == "icon" )
         {
            step.title = f1[name].steps[step.id].par.title || step.title;
            step.processId = f1[name].steps[step.id].par.processId || step.processId;
            this.fillPhaseTree( name );
         }
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   makeSlotBlock( slot )
   {
      let block = new VerticalSizer;
      block.spacing = 6;
      block.add( this.makeViewRow( slot ) );
      let stepsRow = new HorizontalSizer;
      stepsRow.spacing = 6;
      let stepsIndent = new Label( this );
      stepsIndent.text = "";
      stepsIndent.setScaledFixedWidth( 88 );
      stepsRow.add( stepsIndent );
      stepsRow.add( this.makeStepSection( slot ), 100 );
      block.add( stepsRow );
      // Extra gap under Steps so filter groups do not stick together.
      block.addSpacing( 10 );
      return block;
   }

   makeViewRow( slot )
   {
      let list = new ViewList( this );
      list.getMainViews();
      // Keep combo readable — layout must not squash ViewList height.
      list.setScaledFixedHeight( 28 );
      list.toolTip = "<p>Empty means " + slot + " is not processed.</p>";
      list.onViewSelected = function( view )
      {
         f1.views[slot] = ( view && !view.isNull ) ? view.id : "";
      };
      this.lists[slot] = list;

      let row = new HorizontalSizer;
      row.spacing = 6;
      row.add( this.makeFixedLabel( slot ) );
      row.add( list, 100 );
      return row;
   }

   makeStepSection( slot )
   {
      let dialog = this;
      let section = new Control( this );
      section.sizer = new VerticalSizer;
      section.sizer.spacing = 8;
      section.sizer.margin = 8;

      let tree = new TreeBox( this );
      tree.numberOfColumns = 1;
      tree.headerVisible = false;
      tree.rootDecoration = false;
      tree.alternateRowColor = true;
      tree.multipleSelection = false;
      tree.nodeDragging = false;
      tree.nodeExpansion = false;
      tree.setScaledMinHeight( 220 );
      tree.toolTip = "<p>Select a process, then use the arrows to move it. "
                   + "Double-click or Settings opens its parameters.</p>";
      this.stepTrees[slot] = tree;
      this.stepNodes[slot] = {};
      this.fillStepTree( slot );

      tree.onNodeUpdated = function( node )
      {
         if ( dialog.loading )
            return;
         let step = dialog.stepFromNode( slot, node );
         if ( !step || !f1StepInstalled( step ) )
            return;
         let wasOn = f1.steps[slot][step.id].on;
         f1.steps[slot][step.id].on = node.checked ? true : false;
         dialog.syncStepButtons( slot );
         if ( node.checked && !wasOn )
            dialog.openStep( slot, step );
      };
      tree.onNodeDoubleClicked = function( node )
      {
         let step = dialog.stepFromNode( slot, node );
         if ( step )
            dialog.openStep( slot, step );
      };
      tree.onCurrentNodeUpdated = function()
      {
         dialog.syncStepButtons( slot );
      };

      let up = new ToolButton( this );
      up.setScaledFixedSize( 24, 24 );
      up.icon = this.scaledResource( ":/arrows/arrow-up.png" );
      up.toolTip = "<p>Move the selected process earlier.</p>";
      up.onClick = function()
      {
         dialog.moveSelectedStep( slot, -1 );
      };

      let down = new ToolButton( this );
      down.setScaledFixedSize( 24, 24 );
      down.icon = this.scaledResource( ":/arrows/arrow-down.png" );
      down.toolTip = "<p>Move the selected process later.</p>";
      down.onClick = function()
      {
         dialog.moveSelectedStep( slot, 1 );
      };

      let add = new PushButton( this );
      add.text = "+";
      add.toolTip = "<p>Add a process icon from the PixInsight workspace. "
                  + "Its parameters are copied into this script.</p>";
      add.onClick = function()
      {
         dialog.addIconStep( slot );
      };

      let remove = new PushButton( this );
      remove.text = "Remove";
      remove.toolTip = "<p>Remove the selected custom process icon step.</p>";
      remove.onClick = function()
      {
         dialog.removeSelectedIconStep( slot );
      };

      let setup = new PushButton( this );
      setup.text = "Settings";
      setup.toolTip = "<p>Open settings for the selected process.</p>";
      setup.onClick = function()
      {
         let step = dialog.selectedStep( slot );
         if ( step )
            dialog.openStep( slot, step );
      };
      this.stepButton[slot] = setup;
      this.stepUpButton[slot] = up;
      this.stepDownButton[slot] = down;
      this.stepAddButton[slot] = add;
      this.stepRemoveButton[slot] = remove;
      this.syncStepButtons( slot );

      let note = new Label( this );
      note.wordWrapping = true;
      note.text = "Select a process, then use the arrows to reorder. "
                + "+ copies a process icon into this filter. Order is saved per filter.";

      let buttons = new HorizontalSizer;
      buttons.spacing = 6;
      buttons.add( up );
      buttons.add( down );
      buttons.add( add );
      buttons.add( remove );
      buttons.addStretch();
      buttons.add( setup );
      section.sizer.add( note );
      section.sizer.addSpacing( 4 );
      section.sizer.add( tree, 100 );
      section.sizer.addSpacing( 4 );
      section.sizer.add( buttons );

      let bar = new SectionBar( this, "Steps" );
      bar.setSection( section );
      section.hide();
      bar.updateIcon();
      bar.onToggleSection = function( sectionBar, toggleBegin )
      {
         if ( !toggleBegin )
            dialog.adjustToContents();
      };

      let wrap = new VerticalSizer;
      wrap.spacing = 0;
      wrap.add( bar );
      wrap.add( section );
      return wrap;
   }

   fillStepTree( slot )
   {
      let tree = this.stepTrees[slot];
      tree.clear();
      this.stepNodes[slot] = {};
      let steps = f1OrderedSteps( slot );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1.steps[slot][step.id];
         let node = new TreeBoxNode( tree );
         let installed = f1StepInstalled( step );
         node.checkable = true;
         node.checked = installed && state.on ? true : false;
         node.setText( 0, f1StepLabel( step ) + ( installed ? "" : " (not installed)" ) );
         node.enabled = installed ? true : false;
         if ( !installed )
            node.setToolTip( 0, step.title + " is not installed in PixInsight. This step is skipped." );
         this.stepNodes[slot][step.id] = node;
      }
   }

   stepFromNode( slot, node )
   {
      if ( !node )
         return null;
      let map = this.stepNodes[slot];
      for ( let id in map )
         if ( map[id] === node )
         {
            let steps = f1AllSteps( slot );
            for ( let i = 0; i < steps.length; ++i )
               if ( steps[i].id == id )
                  return steps[i];
         }
      return null;
   }

   addIconStep( slot )
   {
      let pick = new F1IconPickDialog();
      if ( !pick.execute() || !pick.iconName )
         return;
      try
      {
         let snap = f1SnapshotFromIcon( pick.iconName );
         let id = f1NewIconStepId();
         let step = {
            id: id,
            title: snap.title,
            kind: "icon",
            processId: snap.processId
         };
         if ( !f1.extra[slot] )
            f1.extra[slot] = [];
         f1.extra[slot].push( step );
         f1.steps[slot][id] = {
            on: true,
            par: {
               processId: snap.processId,
               iconName: snap.iconName,
               source: snap.source,
               title: snap.title
            }
         };
         let order = f1.order[slot] ? f1.order[slot].slice( 0 ) : f1DefaultOrder( slot );
         order.push( id );
         f1.order[slot] = f1NormalizeOrder( slot, order );
         this.fillStepTree( slot );
         let node = this.stepNodes[slot][id];
         if ( node )
            this.stepTrees[slot].currentNode = node;
         this.syncStepButtons( slot );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   removeSelectedIconStep( slot )
   {
      let step = this.selectedStep( slot );
      if ( !step || step.kind != "icon" )
         return;
      let extra = f1.extra[slot] || [];
      let next = [];
      for ( let i = 0; i < extra.length; ++i )
         if ( extra[i].id != step.id )
            next.push( extra[i] );
      f1.extra[slot] = next;
      delete f1.steps[slot][step.id];
      let order = [];
      let old = f1.order[slot] || [];
      for ( let i = 0; i < old.length; ++i )
         if ( old[i] != step.id )
            order.push( old[i] );
      f1.order[slot] = f1NormalizeOrder( slot, order );
      this.fillStepTree( slot );
      this.syncStepButtons( slot );
   }

   selectedStep( slot )
   {
      return this.stepFromNode( slot, this.stepTrees[slot].currentNode );
   }

   readStepOrder( slot )
   {
      let tree = this.stepTrees[slot];
      let order = [];
      for ( let i = 0; i < tree.numberOfChildren; ++i )
      {
         let step = this.stepFromNode( slot, tree.child( i ) );
         if ( step )
            order.push( step.id );
      }
      f1.order[slot] = f1NormalizeOrder( slot, order );
   }

   moveSelectedStep( slot, delta )
   {
      let tree = this.stepTrees[slot];
      let node = tree.currentNode;
      if ( !node )
         return;
      let from = tree.childIndex( node );
      if ( from < 0 )
         return;
      let to = from + delta;
      if ( to < 0 || to >= tree.numberOfChildren )
         return;
      tree.move( from, to );
      tree.currentNode = node;
      this.readStepOrder( slot );
      this.syncStepButtons( slot );
   }

   syncStepButtons( slot )
   {
      let tree = this.stepTrees[slot];
      let node = tree ? tree.currentNode : null;
      let index = node ? tree.childIndex( node ) : -1;
      let step = this.selectedStep( slot );
      if ( this.stepButton[slot] )
         this.stepButton[slot].enabled = step && f1StepInstalled( step ) ? true : false;
      if ( this.stepUpButton[slot] )
         this.stepUpButton[slot].enabled = index > 0;
      if ( this.stepDownButton[slot] )
         this.stepDownButton[slot].enabled = index >= 0 && index < tree.numberOfChildren - 1;
      if ( this.stepRemoveButton[slot] )
         this.stepRemoveButton[slot].enabled = step && step.kind == "icon" ? true : false;
   }

   openStep( slot, step )
   {
      try
      {
         let changed = f1OpenStep( slot, step, this.selectedView( slot ) );
         if ( changed && step.kind == "icon" )
         {
            step.title = f1.steps[slot][step.id].par.title || step.title;
            step.processId = f1.steps[slot][step.id].par.processId || step.processId;
            this.fillStepTree( slot );
            let node = this.stepNodes[slot][step.id];
            if ( node )
               this.stepTrees[slot].currentNode = node;
            this.syncStepButtons( slot );
         }
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   restoreViews()
   {
      for ( let i = 0; i < F1_SLOTS.length; ++i )
      {
         let slot = F1_SLOTS[i];
         try
         {
            this.lists[slot].getMainViews();
         }
         catch ( e )
         {
         }
         let id = f1.views[slot];
         if ( !id )
         {
            try
            {
               this.lists[slot].currentView = new View;
            }
            catch ( e )
            {
            }
            continue;
         }
         try
         {
            let view = View.viewById( id );
            if ( view && !view.isNull )
               this.lists[slot].currentView = view;
            else
               this.lists[slot].currentView = new View;
         }
         catch ( e )
         {
         }
      }
   }

   selectedView( slot )
   {
      let view = this.lists[slot].currentView;
      if ( !view || view.isNull )
         return null;
      return view;
   }

   saveFromControls()
   {
      for ( let s = 0; s < F1_SLOTS.length; ++s )
      {
         let slot = F1_SLOTS[s];
         let view = this.selectedView( slot );
         f1.views[slot] = view ? view.id : "";
         this.readStepOrder( slot );
         let steps = f1AllSteps( slot );
         for ( let i = 0; i < steps.length; ++i )
         {
            let step = steps[i];
            let node = this.stepNodes[slot][step.id];
            if ( !node )
               continue;
            if ( !f1StepInstalled( step ) )
               continue;
            f1.steps[slot][step.id].on = node.checked ? true : false;
         }
      }
      let phases = [ "pre", "post" ];
      for ( let p = 0; p < phases.length; ++p )
      {
         let name = phases[p];
         this.readPhaseOrder( name );
         let steps = f1PhaseAllSteps( name );
         for ( let i = 0; i < steps.length; ++i )
         {
            let step = steps[i];
            let node = this.phaseNodes[name][step.id];
            if ( !node || !f1PhaseStepInstalled( step ) )
               continue;
            f1[name].steps[step.id].on = node.checked ? true : false;
         }
      }
      f1WriteSettings();
   }

   refreshAfterProfile()
   {
      this.loading = true;
      try
      {
         for ( let s = 0; s < F1_SLOTS.length; ++s )
         {
            let slot = F1_SLOTS[s];
            this.fillStepTree( slot );
            this.syncStepButtons( slot );
         }
         this.fillPhaseTree( "pre" );
         this.fillPhaseTree( "post" );
         this.syncPhaseButtons( "pre" );
         this.syncPhaseButtons( "post" );
         this.restoreViews();
      }
      finally
      {
         this.loading = false;
      }
   }

   collectJobs()
   {
      let jobs = [];
      let seen = {};
      for ( let i = 0; i < F1_SLOTS.length; ++i )
      {
         let slot = F1_SLOTS[i];
         // f1.views is source of truth after Pre (Compose RGB clears R/G/B there).
         let id = f1.views[slot];
         let view = id ? f1ViewById( id ) : null;
         if ( !view )
            continue;
         if ( seen[view.id] )
         {
            jobs.push( { slot: slot, view: view, duplicate: seen[view.id] } );
            continue;
         }
         seen[view.id] = slot;
         jobs.push( { slot: slot, view: view, duplicate: "" } );
      }
      return jobs;
   }

   phaseHasWork( name )
   {
      let steps = f1PhaseOrderedSteps( name );
      for ( let i = 0; i < steps.length; ++i )
      {
         let step = steps[i];
         let state = f1[name].steps[step.id];
         if ( state && state.on && f1PhaseStepInstalled( step ) )
            return true;
      }
      return false;
   }

   fillPresetCombo( selectName )
   {
      let want = f1NormalizePresetName( selectName ) || "Default";
      this.preset_Combo.clear();
      this.preset_Combo.addItem( "Default" );
      let list = f1ListPresets();
      let index = 0;
      for ( let i = 0; i < list.length; ++i )
      {
         this.preset_Combo.addItem( list[i] );
         if ( list[i].toLowerCase() == want.toLowerCase() )
            index = i + 1;
      }
      if ( want != "Default" && index == 0 )
      {
         this.preset_Combo.addItem( want );
         index = this.preset_Combo.numberOfItems - 1;
      }
      this.preset_Combo.currentItem = index;
      try
      {
         this.preset_Combo.editText = want;
      }
      catch ( e )
      {
      }
   }

   currentPresetName()
   {
      let text = "";
      try
      {
         if ( this.preset_Combo.editEnabled && this.preset_Combo.editText != null )
            text = String( this.preset_Combo.editText );
      }
      catch ( e )
      {
      }
      if ( !text.replace( /^\s+|\s+$/g, "" ).length
           && this.preset_Combo.numberOfItems > 0
           && this.preset_Combo.currentItem >= 0 )
         text = this.preset_Combo.itemText( this.preset_Combo.currentItem );
      return f1NormalizePresetName( text );
   }

   savePreset()
   {
      try
      {
         this.saveFromControls();
         let name = this.currentPresetName();
         if ( !name || name == "Default" )
         {
            f1Message( "Type a preset name in the box (not Default), then click Save." );
            return;
         }
         let exists = false;
         let list = f1ListPresets();
         for ( let i = 0; i < list.length; ++i )
            if ( list[i].toLowerCase() == name.toLowerCase() )
            {
               exists = true;
               break;
            }
         if ( exists )
         {
            let ask = new MessageBox( "Overwrite preset \"" + name + "\"?",
                                      "BatchProcessing_byHrast",
                                      StdIcon.Question, StdButton.Yes, StdButton.No );
            if ( ask.execute() != StdButton.Yes )
               return;
         }
         name = f1SaveNamedPreset( name, f1CollectProfile() );
         f1WriteSettings();
         this.fillPresetCombo( name );
         f1Message( "Preset saved: " + name, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   loadPreset()
   {
      try
      {
         let name = this.currentPresetName() || "Default";
         if ( name == "Default" )
         {
            f1ResetToDefaults();
            Settings.write( SETTINGS_PREFIX + "lastPreset", DataType.String, "Default" );
            this.refreshAfterProfile();
            f1WriteSettings();
            this.fillPresetCombo( "Default" );
            f1Message( "Restored Default settings.", true );
            return;
         }
         let profile = f1LoadNamedPreset( name );
         f1ApplyProfile( profile );
         this.refreshAfterProfile();
         f1WriteSettings();
         this.fillPresetCombo( name );
         f1Message( "Preset loaded: " + name, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   exportSettingsFile()
   {
      try
      {
         this.saveFromControls();
         let fd = new SaveFileDialog;
         fd.caption = "Export BatchProcessing_byHrast settings";
         fd.filters = [
            [ "BatchProcessing settings", "*.bpshrast" ],
            [ "JSON files", "*.json" ],
            [ "All files", "*" ]
         ];
         fd.overwritePrompt = true;
         if ( !fd.execute() )
            return;
         let path = fd.fileName;
         if ( !/\.(bpshrast|json)$/i.test( path ) )
            path += ".bpshrast";
         File.writeTextFile( path, JSON.stringify( f1CollectProfile(), null, 2 ) );
         f1Message( "Settings exported:\n" + path, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   importSettingsFile()
   {
      try
      {
         let fd = new OpenFileDialog;
         fd.caption = "Import BatchProcessing_byHrast settings";
         fd.filters = [
            [ "BatchProcessing settings", "*.bpshrast" ],
            [ "JSON files", "*.json" ],
            [ "All files", "*" ]
         ];
         if ( !fd.execute() )
            return;
         let text = File.readTextFile( fd.fileName );
         let profile = JSON.parse( text );
         f1ApplyProfile( profile );
         this.refreshAfterProfile();
         f1WriteSettings();
         f1Message( "Settings imported:\n" + fd.fileName, true );
      }
      catch ( e )
      {
         f1Message( e.message ? e.message : e.toString() );
      }
   }

   run()
   {
      this.saveFromControls();
      let hasPre = this.phaseHasWork( "pre" );
      let hasPost = this.phaseHasWork( "post" );
      let jobs = this.collectJobs();
      if ( jobs.length == 0 && !hasPre && !hasPost )
      {
         f1Message( "No image selected and Pre/Post are empty. An empty row is skipped." );
         return;
      }

      console.show();
      console.abortEnabled = true;
      this.run_Button.enabled = false;
      let done = [];
      let failed = [];
      try
      {
         if ( hasPre )
         {
            try
            {
               console.noteln( "<end><cbr><br>===== Pre =====" );
               f1RunPhase( "pre", this );
               this.restoreViews();
               done.push( "Pre" );
            }
            catch ( e )
            {
               let message = e.message ? e.message : e.toString();
               console.criticalln( "*** Pre: " + message );
               failed.push( "Pre: " + message );
               if ( /abort/i.test( message ) )
                  throw e;
            }
         }

         jobs = this.collectJobs();
         for ( let i = 0; i < jobs.length; ++i )
         {
            let job = jobs[i];
            if ( job.duplicate )
            {
               failed.push( job.slot + ": the same image is already in row " + job.duplicate );
               continue;
            }
            try
            {
               f1RunSlot( job.slot, job.view );
               done.push( job.slot );
            }
            catch ( e )
            {
               let message = e.message ? e.message : e.toString();
               console.criticalln( "*** " + job.slot + ": " + message );
               failed.push( job.slot + ": " + message );
               if ( /abort/i.test( message ) )
                  break;
            }
            CoreApplication.processEvents();
         }

         let aborted = /abort/i.test( failed.join( "\n" ) );
         if ( hasPost && !aborted )
         {
            try
            {
               console.noteln( "<end><cbr><br>===== Post =====" );
               f1RunPhase( "post", this );
               done.push( "Post" );
            }
            catch ( e )
            {
               let message = e.message ? e.message : e.toString();
               console.criticalln( "*** Post: " + message );
               failed.push( "Post: " + message );
            }
         }
      }
      catch ( e )
      {
         let message = e.message ? e.message : e.toString();
         if ( failed.indexOf( "Pre: " + message ) < 0 && /abort/i.test( message ) )
            failed.push( "Pre: " + message );
      }
      finally
      {
         this.run_Button.enabled = true;
         try
         {
            this.saveFromControls();
         }
         catch ( e )
         {
         }
      }

      if ( failed.length > 0 )
         f1Message( ( done.length > 0 ? ( "Processed: " + done.join( ", " ) + ".\n" ) : "" )
                    + "Stopped:\n" + failed.join( "\n" ) );
      else
         f1Message( "Processed: " + done.join( ", " ) + ".", true );
   }
};

// ----------------------------------------------------------------------------

function main()
{
   f1LoadSettings();
   f1LoadDatabase();
   let dialog = new BatchProcessingDialog();
   dialog.execute();
}

main();
