// ----------------------------------------------------------------------------
// BatchProcessing_byHrast — Pre / Post helpers
// ----------------------------------------------------------------------------

var F1_PRE_STEPS = [
   { id: "autoassign", title: "Auto-assign filters", kind: "autoassign" },
   { id: "composergb", title: "Compose RGB (R+G+B)", kind: "composergb" },
   { id: "composesho", title: "Compose SHO (SII+Ha+OIII)", kind: "composesho" }
];

var F1_POST_STEPS = [
   { id: "hdrmt", title: "HDRMultiscaleTransform", kind: "hdrmt" },
   { id: "lrgbcomb", title: "LRGBCombination", kind: "lrgbcomb" },
   { id: "starstretch", title: "Star Stretch", kind: "starstretch" },
   { id: "histo", title: "HistogramTransformation", kind: "histo" },
   { id: "putstars", title: "PixelMath (screen stars)", kind: "putstars" }
];

// Trunk / IC 1396. Channels are already stretched. Post only finishes the color image.
var F1_SHO_POST_STEPS = [
   { id: "nbtorgb", title: "NB to RGB Stars", kind: "nbtorgb" },
   { id: "sholrgb", title: "LRGBCombination", kind: "sholrgb" },
   { id: "shoinvert1", title: "Invert", kind: "invert" },
   { id: "shoscnr", title: "SCNR", kind: "scnr" },
   { id: "shoinvert2", title: "Invert", kind: "invert" },
   { id: "shohisto", title: "HistogramTransformation", kind: "histo" },
   { id: "sholhe", title: "LocalHistogramEqualization", kind: "lhe" },
   { id: "shocurves1", title: "CurvesTransformation (saturation)", kind: "curves" },
   { id: "shoputstars", title: "PixelMath (screen stars)", kind: "putstars" },
   { id: "shorot", title: "Rotation", kind: "rotate" },
   { id: "shoresample", title: "Resample", kind: "resample" },
   { id: "shocurves2", title: "CurvesTransformation", kind: "curves" }
];

// M16. Channels are stretched first. Stars are removed only after LRGBCombination.
var F1_SHO2_POST_STEPS = [
   { id: "sholrgb", title: "LRGBCombination", kind: "sholrgb" },
   { id: "sho2blind", title: "BlindSolver", kind: "blindsolver" },
   { id: "sho2starxsii", title: "StarXTerminator", kind: "starx" },
   { id: "sho2starxha", title: "StarXTerminator", kind: "starx" },
   { id: "sho2starxoiii", title: "StarXTerminator", kind: "starx" },
   { id: "sho2spfc", title: "SpectrophotometricFluxCalibration", kind: "spfc" },
   { id: "sho2spcc", title: "SpectrophotometricColorCalibration", kind: "spcc" },
   { id: "sho2alf", title: "AutoLinearFit", kind: "autolinear" },
   { id: "sho2blurx", title: "BlurXTerminator", kind: "blurx", mode: "sharpen" },
   { id: "sho2noisex", title: "NoiseXTerminator", kind: "noisex" },
   { id: "sho2starxsho", title: "StarXTerminator", kind: "starx" },
   { id: "shoinvert1", title: "Invert", kind: "invert" },
   { id: "shoscnr", title: "SCNR", kind: "scnr" },
   { id: "shoinvert2", title: "Invert", kind: "invert" },
   { id: "sho2stretch", title: "MultiscaleAdaptiveStretch", kind: "stretch" },
   { id: "sholhe", title: "LocalHistogramEqualization", kind: "lhe" },
   { id: "sho2scnr2", title: "SCNR", kind: "scnr" },
   { id: "sho2curves", title: "CurvesTransformation", kind: "curves" },
   { id: "nbtorgb", title: "NB to RGB Stars", kind: "nbtorgb" },
   { id: "shoputstars", title: "PixelMath (screen stars)", kind: "putstars" }
];

var F1_DEFAULT_HISTO_H = [
   // c0, m, c1, r0, r1
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.03807615, 0.50000000, 0.90581162, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ],
   [ 0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000 ]
];

function f1CloneHistoH( src )
{
   let H = src && src.length ? src : F1_DEFAULT_HISTO_H;
   let out = [];
   for ( let i = 0; i < H.length; ++i )
      out.push( H[i].slice( 0 ) );
   return out;
}

// Row order is c0, m, c1, r0, r1. The stretch sits on RGB/K, which a mono image uses.
function f1HistoCurve( c0, m, c1 )
{
   let row = [ 0, 0.5, 1, 0, 1 ];
   let H = [];
   for ( let i = 0; i < 5; ++i )
      H.push( row.slice( 0 ) );
   H[3] = [ c0, m, c1, 0, 1 ];
   return H;
}

var F1_FILTER_ALIASES = {
   L: "L", LUM: "L", LUMINANCE: "L", CLEAR: "L",
   R: "R", RED: "R",
   G: "G", GREEN: "G",
   B: "B", BLUE: "B",
   HA: "Ha", HALPHA: "Ha", "H-ALPHA": "Ha", H_ALPHA: "Ha",
   OIII: "OIII", O3: "OIII", "O-III": "OIII",
   SII: "SII", S2: "SII", "S-II": "SII",
   RGB: "RGB", OSC: "RGB", COLOR: "RGB", COLOUR: "RGB"
};

function f1ShowsOneTarget( kind )
{
   return kind == "spikeless" || kind == "blurx" || kind == "blurless" || kind == "graxpert"
       || kind == "blindsolver" || kind == "solver" || kind == "spfc" || kind == "mgc"
       || kind == "spcc" || kind == "noisex" || kind == "starx" || kind == "pm"
       || kind == "screen" || kind == "stretch" || kind == "histo" || kind == "autolinear"
       || kind == "invert" || kind == "scnr" || kind == "lhe" || kind == "curves"
       || kind == "rotate" || kind == "resample" || kind == "rename" || kind == "hdrmt"
       || kind == "starstretch" || kind == "putstars";
}

function f1PostViewName( par, key, fallback )
{
   if ( key == "input" && par && par.channel != null )
   {
      let channel = String( par.channel ).replace( /^\s+|\s+$/g, "" );
      if ( channel )
         return channel;
      let input = par.input != null ? String( par.input ).replace( /^\s+|\s+$/g, "" ) : "";
      if ( !input )
         throw new Error( "Set the channel." );
   }
   let value = par && par[key] != null ? String( par[key] ).replace( /^\s+|\s+$/g, "" ) : "";
   return value || fallback;
}

function f1ResolvePostView( preferred, fallbacks )
{
   if ( f1.views && f1.views[preferred] )
   {
      let saved = f1ViewById( f1.views[preferred] );
      if ( saved )
         return saved;
   }
   let view = f1ViewById( preferred );
   if ( view )
      return view;
   if ( !fallbacks )
      return null;
   for ( let i = 0; i < fallbacks.length; ++i )
   {
      view = f1ViewById( fallbacks[i] );
      if ( view )
      {
         console.writeln( "  using fallback view " + fallbacks[i]
                          + " (wanted " + preferred + ")" );
         return view;
      }
   }
   return null;
}

function f1MaybeRenamePostView( view, outId )
{
   outId = ( outId == null ? "" : String( outId ) ).replace( /^\s+|\s+$/g, "" );
   if ( !view || !outId || view.id == outId )
      return view;
   return f1RenameMainView( view, outId );
}

function f1PhaseDefaultParams( step )
{
   if ( step.kind == "autoassign" )
      return { preferFits: true };
   if ( step.kind == "composergb" || step.kind == "composesho" )
      return {};
   if ( step.kind == "hdrmt" )
      return {
         input: "RGB",
         output: "RGB",
         numberOfLayers: 6,
         numberOfIterations: 1,
         invertedIterations: true,
         overdrive: 0.0,
         medianTransform: false,
         toLightness: false,
         toIntensity: false,
         preserveHue: false,
         luminanceMask: true,
         deringing: false
      };
   if ( step.kind == "lrgbcomb" )
      return {
         inputL: "L",
         inputRGB: "RGB",
         output: "LRGB",
         mL: 0.5,
         mc: 0.5,
         clipHighlights: true
      };
   if ( step.kind == "starstretch" )
   {
         if ( step.id == "shostarstretch" )
         return {
            input: "SHO_stars",
            output: "SHO_stars",
            amount: 5.0,
            satAmount: 1.0,
            removeGreen: false
         };
      return {
         input: "RGB_stars",
         output: "RGB_stars",
         amount: 5.0,
         satAmount: 1.0,
         removeGreen: false
      };
   }
   if ( step.kind == "histo" )
   {
      if ( step.id == "shohisto" )
         return {
            input: "SHO",
            output: "SHO",
            H: f1HistoCurve( 0.01012658, 0.21012658, 0.91645570 )
         };
      return {
         input: "LRGB",
         output: "LRGB",
         H: f1CloneHistoH( F1_DEFAULT_HISTO_H )
      };
   }
   if ( step.kind == "putstars" )
   {
      if ( step.id == "shoputstars" )
         return {
            inputStars: "NBtoRGB_stars",
            inputTarget: "SHO",
            output: "SHO",
            expression: "combine(NBtoRGB_stars, SHO, op_screen())"
         };
      return {
         inputStars: "RGB_stars",
         inputTarget: "LRGB",
         output: "LRGB",
         expression: "combine(RGB_stars, LRGB, op_screen())"
      };
   }
   if ( step.kind == "nbtorgb" )
   {
      let sho2 = ( f1.activePreset == "SHO2_Default" );
      return {
         sii: "SII_stars",
         ha: "Ha_stars",
         oiii: "OIII_stars",
         output: "NBtoRGB_stars",
         haToOiiRatio: 0.3,
         applyStarStretch: true,
         stretchFactor: sho2 ? 1.5 : 6,
         colorBoost: sho2 ? 1.6 : 1.7
      };
   }
   if ( step.kind == "sholrgb" )
      return {
         inputR: "SII",
         inputG: "Ha",
         inputB: "OIII",
         output: "SHO",
         mL: 0.5,
         mc: 0.5,
         clipHighlights: true
      };
   if ( step.kind == "blindsolver" )
      return { input: "SHO", channel: "SHO", timeLimit: 120 };
   if ( step.kind == "lhe" )
      return { input: "SHO", radius: 256, slopeLimit: 1.5, amount: 0.5 };
   if ( step.kind == "curves" )
   {
      if ( step.id == "sho2curves" )
         return {
            input: "SHO",
            B: [ [ 0, 0 ], [ 0.49080, 0.56089 ], [ 1, 1 ] ],
            K: [ [ 0, 0 ], [ 0.02658, 0.02583 ], [ 0.44785, 0.52583 ], [ 1, 1 ] ],
            S: [ [ 0, 0 ], [ 0.41513, 0.50738 ], [ 1, 1 ] ]
         };
      if ( step.id == "shocurves2" )
         return {
            input: "SHO",
            K: [ [ 0, 0 ], [ 0.24548, 0.25323 ], [ 0.30491, 0.33850 ], [ 1, 1 ] ],
            S: [ [ 0, 0 ], [ 0.39793, 0.49871 ], [ 1, 1 ] ]
         };
      return {
         input: "SHO",
         S: [ [ 0, 0 ], [ 0.25323, 0.45478 ], [ 1, 1 ] ]
      };
   }
   if ( step.kind == "rotate" )
      return { input: "SHO", angleDeg: 180 };
   if ( step.kind == "resample" )
      return { input: "SHO", scale: 0.5 };
   if ( step.kind == "stretch" )
   {
      if ( step.id == "sho2stretch" )
         return {
            input: "SHO",
            output: "SHO",
            targetBackground: 0.15,
            aggressiveness: 0.70,
            dynamicRange: 0.40,
            contrastRecovery: true,
            scaleSeparation: 1024,
            intensity: 1.00,
            saturation: true,
            saturationAmount: 0.75,
            saturationBoost: 0.50
         };
      return {
         input: "SHO",
         output: "SHO",
         targetBackground: 0.15,
         aggressiveness: 0.70,
         dynamicRange: 0.40,
         contrastRecovery: true,
         scaleSeparation: 1024,
         intensity: 1.00,
         saturation: false,
         saturationAmount: 0.75,
         saturationBoost: 0.50
      };
   }
   if ( step.kind == "spfc" )
      return {
         input: "SHO",
         narrowband: true,
         wavelength: 656.3,
         bandwidth: 6.0,
         redWavelength: 656.3,
         redBandwidth: 6.0,
         greenWavelength: 500.7,
         greenBandwidth: 6.0,
         blueWavelength: 500.7,
         blueBandwidth: 6.0,
         generateGraphs: false,
         grayName: EC_grayFilterName,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName
      };
   if ( step.kind == "spcc" )
      return {
         input: "SHO",
         narrowband: true,
         optimizeStars: false,
         redWavelength: 656.3,
         redBandwidth: 6.0,
         greenWavelength: 500.7,
         greenBandwidth: 6.0,
         blueWavelength: 500.7,
         blueBandwidth: 6.0,
         redName: EC_redFilterName,
         greenName: EC_greenFilterName,
         blueName: EC_blueFilterName,
         sensorName: EC_deviceQECurveName,
         whiteReference: "Average Spiral Galaxy",
         applyCalibration: true,
         neutralizeBackground: true,
         backgroundLow: -2.8,
         backgroundHigh: 2.0
      };
   if ( step.kind == "blurx" )
      return {
         input: "SHO",
         correctOnly: false,
         sharpenStars: 0.20,
         starHalos: 0.00,
         sharpenNonstellar: 0.60,
         overlap: 0.20
      };
   if ( step.kind == "noisex" )
      return { input: "SHO", denoise: 0.70, detail: 0.15 };
   if ( step.kind == "starx" )
   {
      let channel = "SHO";
      let stars = false;
      if ( step.id == "sho2starxsii" )
      {
         channel = "SII";
         stars = true;
      }
      else if ( step.id == "sho2starxha" )
      {
         channel = "Ha";
         stars = true;
      }
      else if ( step.id == "sho2starxoiii" )
      {
         channel = "OIII";
         stars = true;
      }
      return {
         input: channel,
         channel: channel,
         outputStars: stars,
         unscreen: false,
         overlap: 0.20
      };
   }
   if ( step.kind == "starxmono" )
      return { overlap: 0.20, outputStars: true };
   if ( step.kind == "autolinear" )
      return { input: "SHO", referenceMethod: "Lowest mean" };
   if ( step.kind == "shocombine" )
      return {
         inputR: "SII",
         inputG: "Ha",
         inputB: "OIII",
         output: "SHO",
         mL: 0.5,
         mc: 0.5,
         clipHighlights: true
      };
   if ( step.kind == "rename" )
      return { input: "SHO", output: "SHO" };
   if ( step.kind == "invert" )
      return { input: "SHO" };
   if ( step.kind == "scnr" )
      return { input: "SHO", amount: 1.0 };
   return {};
}

function f1PhaseDefaultOn( step )
{
   let preset = f1.activePreset || "LRGB Default";
   let sho = preset == "SHO Default";
   let sho2 = preset == "SHO2_Default";
   if ( step.kind == "autoassign" )
      return true;
   if ( step.kind == "composergb" )
      return !( sho || sho2 );
   if ( step.kind == "composesho" )
      return false;
   if ( sho2 )
      return true;
   if ( step.kind == "histo" )
      return step.id == "shohisto" ? sho : !sho;
   if ( step.kind == "hdrmt" || step.kind == "lrgbcomb" )
      return !sho;
   if ( step.kind == "sholrgb" || step.kind == "lhe" || step.kind == "curves"
        || step.kind == "rotate" || step.kind == "resample" )
      return sho;
   if ( step.kind == "starstretch" || step.kind == "putstars" )
      return true;
   if ( step.kind == "nbtorgb" || step.kind == "stretch" || step.kind == "shocombine"
        || step.kind == "rename" || step.kind == "invert" || step.kind == "scnr" )
      return sho;
   return false;
}

function f1InitPhase( name, builtins )
{
   f1[name] = { steps: {}, order: [], extra: [], added: [], removed: {} };
   let order = [];
   for ( let i = 0; i < builtins.length; ++i )
   {
      let step = builtins[i];
      order.push( step.id );
      let par = f1PhaseDefaultParams( step );
      if ( f1ShowsOneTarget( step.kind ) && !par.channel && par.input )
         par.channel = par.input;
      f1[name].steps[step.id] = { on: f1PhaseDefaultOn( step ), par: par };
   }
   f1[name].order = order;
}

function f1InitPrePost()
{
   f1InitPhase( "pre", f1PhaseBuiltins( "pre" ) );
   f1InitPhase( "post", f1PhaseBuiltins( "post" ) );
}

function f1PhaseBuiltins( name )
{
   if ( name == "pre" )
      return F1_PRE_STEPS;
   if ( f1.activePreset == "SHO Default" )
      return F1_SHO_POST_STEPS;
   if ( f1.activePreset == "SHO2_Default" )
      return F1_SHO2_POST_STEPS;
   return F1_POST_STEPS;
}

function f1PhaseAllSteps( name )
{
   let list = [];
   let builtins = f1PhaseBuiltins( name );
   let removed = ( f1[name] && f1[name].removed ) ? f1[name].removed : {};
   for ( let i = 0; i < builtins.length; ++i )
      if ( !removed[builtins[i].id] )
         list.push( builtins[i] );
   let extra = ( f1[name] && f1[name].extra ) ? f1[name].extra : [];
   for ( let i = 0; i < extra.length; ++i )
      list.push( extra[i] );
   let added = ( f1[name] && f1[name].added ) ? f1[name].added : [];
   for ( let i = 0; i < added.length; ++i )
      list.push( added[i] );
   return list;
}

function f1PhaseRemovedList( name )
{
   let removed = ( f1[name] && f1[name].removed ) ? f1[name].removed : {};
   let list = [];
   for ( let id in removed )
      if ( removed[id] )
         list.push( id );
   list.sort();
   return list;
}

function f1PhaseApplyRemovedList( name, ids )
{
   if ( !f1[name] )
      return;
   f1[name].removed = {};
   if ( !ids || !Array.isArray( ids ) )
      return;
   for ( let i = 0; i < ids.length; ++i )
      if ( ids[i] )
         f1[name].removed[ids[i]] = true;
}

function f1PhaseNormalizeOrder( name, ids )
{
   let steps = f1PhaseAllSteps( name );
   let known = {};
   for ( let i = 0; i < steps.length; ++i )
      known[steps[i].id] = steps[i];
   let order = [];
   let seen = {};
   if ( ids && ids.length )
   {
      for ( let i = 0; i < ids.length; ++i )
      {
         let id = ids[i];
         if ( known[id] && !seen[id] )
         {
            order.push( id );
            seen[id] = true;
         }
      }
   }
   for ( let i = 0; i < steps.length; ++i )
   {
      let id = steps[i].id;
      if ( seen[id] )
         continue;
      let insertAt = order.length;
      let placed = false;
      for ( let p = i - 1; p >= 0; --p )
      {
         let at = order.indexOf( steps[p].id );
         if ( at >= 0 )
         {
            insertAt = at + 1;
            placed = true;
            break;
         }
      }
      if ( !placed )
      {
         for ( let n = i + 1; n < steps.length; ++n )
         {
            let at = order.indexOf( steps[n].id );
            if ( at >= 0 )
            {
               insertAt = at;
               break;
            }
         }
      }
      order.splice( insertAt, 0, id );
      seen[id] = true;
   }
   return order;
}

function f1PhaseOrderedSteps( name )
{
   let steps = f1PhaseAllSteps( name );
   let byId = {};
   for ( let i = 0; i < steps.length; ++i )
      byId[steps[i].id] = steps[i];
   let order = f1PhaseNormalizeOrder( name, f1[name].order );
   f1[name].order = order;
   let list = [];
   for ( let i = 0; i < order.length; ++i )
      if ( byId[order[i]] )
         list.push( byId[order[i]] );
   return list;
}

function f1PhaseStepInstalled( step )
{
   if ( !step )
      return false;
   if ( step.kind == "autoassign" || step.kind == "composergb" || step.kind == "composesho" || step.kind == "putstars" )
      return true;
   if ( step.kind == "starstretch" )
   {
      try
      {
         let list = f1StarStretchScriptCandidates();
         for ( let i = 0; i < list.length; ++i )
            if ( File.exists( list[i] ) )
               return true;
      }
      catch ( e )
      {
      }
      return typeof StarStretchParameters == "object";
   }
   if ( step.kind == "hdrmt" )
      return typeof HDRMultiscaleTransform == "function";
   if ( step.kind == "lrgbcomb" )
      return typeof LRGBCombination == "function";
   if ( step.kind == "histo" )
      return typeof HistogramTransformation == "function";
   if ( step.kind == "nbtorgb" )
   {
      try
      {
         let list = f1NBtoRGBScriptCandidates();
         for ( let i = 0; i < list.length; ++i )
            if ( File.exists( list[i] ) )
               return true;
      }
      catch ( e )
      {
      }
      return false;
   }
   if ( step.kind == "stretch" )
      return typeof MultiscaleAdaptiveStretch == "function";
   if ( step.kind == "spfc" )
      return typeof SpectrophotometricFluxCalibration == "function";
   if ( step.kind == "spcc" )
      return typeof SpectrophotometricColorCalibration == "function";
   if ( step.kind == "blurx" )
      return typeof BlurXTerminator == "function";
   if ( step.kind == "noisex" )
      return typeof NoiseXTerminator == "function";
   if ( step.kind == "starx" || step.kind == "starxmono" )
      return typeof StarXTerminator == "function";
   if ( step.kind == "autolinear" )
      return typeof ChannelExtraction == "function"
          && typeof LinearFit == "function"
          && typeof ChannelCombination == "function";
   if ( step.kind == "shocombine" )
      return typeof ChannelCombination == "function";
   if ( step.kind == "rename" )
      return true;
   if ( step.kind == "invert" )
      return typeof Invert == "function";
   if ( step.kind == "scnr" )
      return typeof SCNR == "function";
   if ( step.kind == "sholrgb" )
      return typeof LRGBCombination == "function";
   if ( step.kind == "lhe" )
      return typeof LocalHistogramEqualization == "function";
   if ( step.kind == "curves" )
      return typeof CurvesTransformation == "function";
   if ( step.kind == "rotate" )
      return typeof Rotation == "function";
   if ( step.kind == "resample" )
      return typeof Resample == "function";
   if ( step.kind == "blindsolver" )
      return typeof BlindSolverEngine == "function";
   if ( step.kind == "icon" )
      return f1GlobalIsFunction( step.processId );
   return false;
}

function f1ViewById( id )
{
   if ( !id )
      return null;
   try
   {
      let view = View.viewById( id );
      if ( view && !view.isNull )
         return view;
   }
   catch ( e )
   {
   }
   return null;
}

function f1MainWindows()
{
   let list = [];
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
   {
      let w = windows[i];
      if ( !w || !w.isWindow )
         continue;
      try
      {
         if ( w.mainView && !w.mainView.isNull )
            list.push( w );
      }
      catch ( e )
      {
      }
   }
   return list;
}

function f1WindowIds()
{
   let ids = {};
   let windows = f1MainWindows();
   for ( let i = 0; i < windows.length; ++i )
      ids[windows[i].mainView.id] = true;
   return ids;
}

function f1Keyword( window, name )
{
   try
   {
      let keywords = window.keywords;
      for ( let i = 0; i < keywords.length; ++i )
         if ( keywords[i].name == name )
         {
            let value = keywords[i].strippedValue;
            if ( value == null )
               value = keywords[i].value;
            return value == null ? "" : String( value ).trim();
         }
   }
   catch ( e )
   {
   }
   return "";
}

function f1NormalizeFilterToken( raw )
{
   let text = String( raw == null ? "" : raw ).trim();
   if ( !text )
      return "";
   let key = text.toUpperCase().replace( /\s+/g, "" );
   if ( F1_FILTER_ALIASES[key] )
      return F1_FILTER_ALIASES[key];
   if ( F1_FILTER_ALIASES[text.toUpperCase()] )
      return F1_FILTER_ALIASES[text.toUpperCase()];
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      if ( F1_SLOTS[s].toUpperCase() == key )
         return F1_SLOTS[s];
   // Ha3nm / OIII7nm / SII-3nm style tokens
   let stripped = key.replace( /[_-]?[0-9]+(\.[0-9]+)?NM$/i, "" ).replace( /[_-]?[0-9]+(\.[0-9]+)?$/g, "" );
   if ( stripped && stripped != key )
   {
      if ( F1_FILTER_ALIASES[stripped] )
         return F1_FILTER_ALIASES[stripped];
      for ( let s = 0; s < F1_SLOTS.length; ++s )
         if ( F1_SLOTS[s].toUpperCase() == stripped )
            return F1_SLOTS[s];
   }
   return "";
}

function f1ExactSlotFromViewId( id )
{
   let text = String( id == null ? "" : id ).trim();
   if ( !text )
      return "";
   for ( let s = 0; s < F1_SLOTS.length; ++s )
      if ( F1_SLOTS[s] == text || F1_SLOTS[s].toUpperCase() == text.toUpperCase() )
         return F1_SLOTS[s];
   return "";
}

function f1DetectFilterFromText( text )
{
   let src = String( text == null ? "" : text );
   let m = /FILTER-([A-Za-z0-9+-]+)/i.exec( src );
   if ( m )
   {
      let slot = f1NormalizeFilterToken( m[1] );
      if ( slot )
         return slot;
   }
   let upper = "_" + src.toUpperCase().replace( /[^A-Z0-9]+/g, "_" ) + "_";
   let keys = [
      "HALPHA", "H_ALPHA", "H-ALPHA", "HA",
      "OIII", "O-III", "O3",
      "SII", "S-II", "S2",
      "RGB", "OSC",
      "LUM", "LUMINANCE",
      "_L_", "_R_", "_G_", "_B_"
   ];
   for ( let i = 0; i < keys.length; ++i )
   {
      let token = keys[i];
      if ( token.charAt( 0 ) == "_" )
      {
         if ( upper.indexOf( token ) >= 0 )
            return f1NormalizeFilterToken( token.replace( /_/g, "" ) );
      }
      else if ( new RegExp( "(^|_)" + token + "(_|$)" ).test( upper ) )
      {
         let slot = f1NormalizeFilterToken( token );
         if ( slot )
            return slot;
      }
   }
   return "";
}

function f1DetectFilterForWindow( window, preferFits )
{
   let detail = f1DetectFilterDetail( window, preferFits );
   return detail.slot;
}

function f1DetectFilterDetail( window, preferFits )
{
   let view = window.mainView;
   let isColor = false;
   try
   {
      isColor = view && view.image && view.image.isColor ? true : false;
   }
   catch ( e )
   {
   }
   // Combined color masters belong in RGB, never in R/G/B.
   let exactId = f1ExactSlotFromViewId( view.id );
   if ( isColor )
      return { slot: "RGB", source: "color" };

   // Manual rename to exact slot id (Ha, R, …) wins over a stale FILTER keyword.
   if ( exactId )
      return { slot: exactId, source: "view-id" };

   let filterKw = f1Keyword( window, "FILTER" );
   if ( preferFits )
   {
      let fromFits = f1NormalizeFilterToken( filterKw );
      if ( fromFits )
         return { slot: fromFits, source: "FILTER=" + filterKw };
   }

   let id = view.id;
   let path = "";
   try { path = window.filePath || ""; } catch ( e ) {}
   let fromName = f1DetectFilterFromText( id );
   if ( fromName )
      return { slot: fromName, source: "view-name" };
   fromName = f1DetectFilterFromText( File.extractName( path ) );
   if ( fromName )
      return { slot: fromName, source: "file-name" };

   if ( !preferFits )
   {
      let fromFits = f1NormalizeFilterToken( filterKw );
      if ( fromFits )
         return { slot: fromFits, source: "FILTER=" + filterKw };
   }
   return { slot: "", source: "" };
}

function f1WithViewSyncSuppressed( fn )
{
   let prev = f1.suppressViewSync ? true : false;
   f1.suppressViewSync = true;
   try
   {
      return fn();
   }
   finally
   {
      f1.suppressViewSync = prev;
   }
}

function f1ClearDialogSlot( dialog, slot )
{
   f1.views[slot] = "";
   if ( !dialog || !dialog.lists || !dialog.lists[slot] )
      return;
   f1WithViewSyncSuppressed( function()
   {
      try
      {
         dialog.lists[slot].getMainViews();
      }
      catch ( e )
      {
      }
      try
      {
         // Empty selection so the filter chain skips this row.
         dialog.lists[slot].currentView = new View;
      }
      catch ( e )
      {
      }
   } );
}

function f1SetDialogSlot( dialog, slot, view )
{
   f1.views[slot] = view ? view.id : "";
   if ( !dialog || !dialog.lists || !dialog.lists[slot] || !view )
      return;
   f1WithViewSyncSuppressed( function()
   {
      try
      {
         dialog.lists[slot].getMainViews();
      }
      catch ( e )
      {
      }
      try
      {
         dialog.lists[slot].currentView = view;
      }
      catch ( e )
      {
      }
   } );
}

function f1RenameMainView( view, newId )
{
   if ( !view || view.isNull )
      throw new Error( "Missing view for rename." );
   if ( view.id == newId )
      return view;
   let existing = f1ViewById( newId );
   if ( existing && existing.window.mainView.id == newId && existing.window.uniqueId != view.window.uniqueId )
      throw new Error( "View id already in use: " + newId );
   view.id = newId;
   return view;
}

function f1FindNewWindow( beforeIds )
{
   let windows = f1MainWindows();
   for ( let i = 0; i < windows.length; ++i )
   {
      let id = windows[i].mainView.id;
      if ( !beforeIds[id] )
         return windows[i];
   }
   try
   {
      let active = ImageWindow.activeWindow;
      if ( active && active.isWindow && active.mainView && !beforeIds[active.mainView.id] )
         return active;
   }
   catch ( e )
   {
   }
   return null;
}

function f1AutoAssignFilters( par, dialog )
{
   let preferFits = !par || par.preferFits !== false;
   let assigned = {};
   let windows = f1MainWindows();
   console.noteln( "<end><cbr><br>* Pre: Auto-assign filters"
                   + ( preferFits ? " (Prefer FITS ON)" : " (Prefer FITS OFF)" ) );
   for ( let i = 0; i < windows.length; ++i )
   {
      let window = windows[i];
      let view = window.mainView;
      let detail = f1DetectFilterDetail( window, preferFits );
      let slot = detail.slot;
      if ( !slot )
      {
         console.writeln( "  skip (no filter): " + view.id );
         continue;
      }
      if ( assigned[slot] )
      {
         console.warningln( "  skip duplicate " + slot + ": " + view.id );
         continue;
      }
      try
      {
         let fromId = view.id;
         if ( view.id != slot )
         {
            console.writeln( "  " + fromId + " -> " + slot + "  [" + detail.source + "]" );
            f1RenameMainView( view, slot );
         }
         else
            console.writeln( "  already " + slot + "  [" + detail.source + "]" );
         // Never place a color RGB image into mono R/G/B rows.
         if ( ( slot == "R" || slot == "G" || slot == "B" ) && view.image && view.image.isColor )
         {
            console.warningln( "  skip color view for " + slot + ": " + view.id );
            continue;
         }
         f1SetDialogSlot( dialog, slot, view );
         assigned[slot] = true;
         // The same window must not stay selected in another row.
         for ( let s = 0; s < F1_SLOTS.length; ++s )
         {
            let other = F1_SLOTS[s];
            if ( other != slot && f1.views[other] == view.id )
               f1ClearDialogSlot( dialog, other );
         }
      }
      catch ( e )
      {
         console.warningln( "  " + view.id + ": " + ( e.message ? e.message : e.toString() ) );
      }
   }
}

function f1ComposeMapped( spec, dialog )
{
   f1RequireModule( "ChannelCombination", typeof ChannelCombination == "function" );
   let sources = [];
   for ( let i = 0; i < spec.sources.length; ++i )
   {
      let slot = spec.sources[i];
      let view = f1ViewById( f1.views[slot] || slot );
      if ( !view )
      {
         console.warningln( "<end><cbr>** " + spec.title + " skipped: need "
                            + spec.sources.join( ", " ) + " views." );
         return null;
      }
      sources.push( view );
   }
   console.noteln( "<end><cbr><br>* Pre: " + spec.title );
   if ( f1ViewById( spec.outId ) )
      throw new Error( "View id already in use: " + spec.outId );
   let before = f1WindowIds();
   let P = new ChannelCombination;
   P.colorSpace = ChannelCombination.RGB;
   P.channels = [
      [ true, sources[0].id ],
      [ true, sources[1].id ],
      [ true, sources[2].id ]
   ];
   f1Set( P, "inheritAstrometricSolution", true );
   if ( P.executeGlobal() === false )
      throw new Error( "ChannelCombination failed." );
   let window = f1FindNewWindow( before );
   if ( !window )
   {
      try { window = ImageWindow.activeWindow; } catch ( e ) {}
   }
   if ( !window || !window.isWindow )
      throw new Error( spec.title + " did not create a new image." );
   f1RenameMainView( window.mainView, spec.outId );
   console.writeln( "  created " + spec.outId );
   f1SetDialogSlot( dialog, spec.outId, window.mainView );
   for ( let i = 0; i < spec.clear.length; ++i )
   {
      f1ClearDialogSlot( dialog, spec.clear[i] );
      f1.views[spec.clear[i]] = "";
   }
   console.writeln( "  " + spec.outId + " row filled; "
                    + spec.clear.join( "/" ) + " rows cleared for the filter chain" );
   return window.mainView;
}

function f1ComposeRGB( par, dialog )
{
   return f1ComposeMapped( {
      title: "Compose RGB from R+G+B",
      outId: "RGB",
      sources: [ "R", "G", "B" ],
      clear: [ "R", "G", "B" ]
   }, dialog );
}

function f1ComposeSHO( par, dialog )
{
   return f1ComposeMapped( {
      title: "Compose SHO from SII+Ha+OIII",
      outId: "SHO",
      sources: [ "SII", "Ha", "OIII" ],
      clear: [ "SII", "Ha", "OIII" ]
   }, dialog );
}

function f1RenameStarXResult( slot, beforeIds )
{
   if ( typeof f1ExportsStars == "function" && !f1ExportsStars( slot ) )
      return;
   let starsId = slot + "_stars";
   let window = f1FindNewWindow( beforeIds );
   if ( !window )
   {
      // StarX may name the stars view with a predictable suffix
      let candidates = [];
      let windows = f1MainWindows();
      for ( let i = 0; i < windows.length; ++i )
      {
         let id = windows[i].mainView.id;
         if ( /stars/i.test( id ) && id != starsId )
            candidates.push( windows[i] );
      }
      if ( candidates.length == 1 )
         window = candidates[0];
      else if ( candidates.length > 1 )
      {
         for ( let i = 0; i < candidates.length; ++i )
            if ( !beforeIds[candidates[i].mainView.id] )
            {
               window = candidates[i];
               break;
            }
      }
   }
   if ( !window )
   {
      console.warningln( "  could not find StarX stars view to rename to " + starsId );
      return;
   }
   let existing = f1ViewById( starsId );
   if ( existing && existing.window.uniqueId != window.uniqueId )
      throw new Error( "View id already in use: " + starsId );
   f1RenameMainView( window.mainView, starsId );
   console.writeln( "  stars -> " + starsId );
}

function f1BuildPostKind( step, par )
{
   if ( !step )
      return null;
   if ( step.kind == "hdrmt" )
      return f1NewHDRMT( par );
   if ( step.kind == "lrgbcomb" )
      return f1NewLRGBOntoColor( par );
   if ( step.kind == "sholrgb" )
      return f1NewSHOLRGB( par );
   if ( step.kind == "invert" )
      return new Invert;
   if ( step.kind == "scnr" )
      return f1NewSCNR( par );
   if ( step.kind == "lhe" )
      return f1NewLHE( par );
   if ( step.kind == "curves" )
      return f1NewCurves( par );
   if ( step.kind == "rotate" )
      return f1NewRotation( par );
   if ( step.kind == "resample" )
      return f1NewResample( par );
   if ( step.kind == "putstars" )
      return f1NewPutStars( par );
   return null;
}

function f1NewHDRMT( par )
{
   let P = new HDRMultiscaleTransform;
   f1Need( P, "numberOfLayers", Math.round( isFinite( par.numberOfLayers ) ? par.numberOfLayers : 6 ) );
   f1Need( P, "numberOfIterations", Math.round( isFinite( par.numberOfIterations ) ? par.numberOfIterations : 1 ) );
   f1Need( P, "invertedIterations", par.invertedIterations !== false );
   f1Need( P, "overdrive", isFinite( par.overdrive ) ? par.overdrive : 0.0 );
   f1Need( P, "medianTransform", par.medianTransform ? true : false );
   f1Set( P, "scalingFunctionName", "B3 Spline (5)" );
   f1Set( P, "toIntensity", par.toIntensity ? true : false );
   f1Set( P, "toLightness", par.toLightness ? true : false );
   f1Set( P, "preserveHue", par.preserveHue ? true : false );
   f1Need( P, "luminanceMask", par.luminanceMask !== false );
   f1Set( P, "deringing", par.deringing ? true : false );
   return P;
}

function f1NewLRGBOntoColor( par )
{
   let P = new LRGBCombination;
   P.channels = [
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ true, f1PostViewName( par, "inputL", "L" ), 1.0 ]
   ];
   f1Need( P, "mL", isFinite( par.mL ) ? par.mL : 0.5 );
   f1Need( P, "mc", isFinite( par.mc ) ? par.mc : 0.5 );
   f1Set( P, "clipHighlights", par.clipHighlights !== false );
   f1Set( P, "noiseReduction", false );
   return P;
}

function f1NewSHOLRGB( par )
{
   let P = new LRGBCombination;
   P.channels = [
      [ true, f1PostViewName( par, "inputR", "SII" ), 1.0 ],
      [ true, f1PostViewName( par, "inputG", "Ha" ), 1.0 ],
      [ true, f1PostViewName( par, "inputB", "OIII" ), 1.0 ],
      [ false, "", 1.0 ]
   ];
   f1Need( P, "mL", isFinite( par.mL ) ? par.mL : 0.5 );
   f1Need( P, "mc", isFinite( par.mc ) ? par.mc : 0.5 );
   f1Set( P, "clipHighlights", par.clipHighlights !== false );
   f1Set( P, "noiseReduction", false );
   f1Set( P, "inheritAstrometricSolution", true );
   return P;
}

function f1NewSCNR( par )
{
   let P = new SCNR;
   f1Need( P, "amount", isFinite( par.amount ) ? par.amount : 1.0 );
   f1Set( P, "protectionMethod", SCNR.AverageNeutral );
   f1Set( P, "colorToRemove", SCNR.Green );
   f1Set( P, "preserveLightness", true );
   return P;
}

function f1NewLHE( par )
{
   let P = new LocalHistogramEqualization;
   f1Need( P, "radius", Math.round( isFinite( par.radius ) ? par.radius : 256 ) );
   f1Need( P, "histogramBins", LocalHistogramEqualization.Bit8 );
   f1Need( P, "slopeLimit", isFinite( par.slopeLimit ) ? par.slopeLimit : 1.5 );
   f1Need( P, "amount", isFinite( par.amount ) ? par.amount : 0.5 );
   f1Need( P, "circularKernel", true );
   return P;
}

function f1NewCurves( par )
{
   let P = new CurvesTransformation;
   f1ApplyCurve( P, "B", par.B );
   f1ApplyCurve( P, "K", par.K );
   f1ApplyCurve( P, "S", par.S );
   return P;
}

function f1NewRotation( par )
{
   let degrees = isFinite( par.angleDeg ) ? par.angleDeg : 180;
   let P = new Rotation;
   f1Need( P, "angle", degrees * Math.PI / 180 );
   f1Set( P, "optimizeFast", true );
   f1Set( P, "interpolation", Rotation.Auto );
   f1Set( P, "clampingThreshold", 0.30 );
   f1Set( P, "smoothness", 1.50 );
   f1Set( P, "noGUIMessages", true );
   return P;
}

function f1NewResample( par )
{
   let scale = isFinite( par.scale ) ? par.scale : 0.5;
   let P = new Resample;
   f1Need( P, "xSize", scale );
   f1Need( P, "ySize", scale );
   f1Need( P, "mode", Resample.RelativeDimensions );
   f1Set( P, "absoluteMode", Resample.ForceWidthAndHeight );
   f1Set( P, "interpolation", Resample.Auto );
   f1Set( P, "clampingThreshold", 0.30 );
   f1Set( P, "smoothness", 1.50 );
   f1Set( P, "noGUIMessages", true );
   return P;
}

function f1NewPutStars( par )
{
   let starsId = f1PostViewName( par, "inputStars", "RGB_stars" );
   let targetId = f1PostViewName( par, "inputTarget", "LRGB" );
   let expression = ( par && par.expression ) ? String( par.expression ).replace( /^\s+|\s+$/g, "" ) : "";
   if ( !expression.length
        || expression == "combine(RGB_stars, LRGB, op_screen())"
        || /^combine\([^,]+,\s*[^,]+,\s*op_screen\(\)\)$/.test( expression ) )
      expression = "combine(" + starsId + ", " + targetId + ", op_screen())";
   let P = new PixelMath;
   P.expression = expression;
   f1Set( P, "useSingleExpression", true );
   f1Set( P, "createNewImage", false );
   return P;
}

function f1RunHDRMT( par )
{
   f1RequireModule( "HDRMultiscaleTransform", typeof HDRMultiscaleTransform == "function" );
   let inId = f1PostViewName( par, "input", "RGB" );
   let outId = f1PostViewName( par, "output", inId );
   let view = f1ResolvePostView( inId, [ f1.views.RGB || "RGB", "RGB" ] );
   if ( !view )
   {
      console.warningln( "<end><cbr>** HDRMultiscaleTransform skipped: view not found: " + inId );
      return;
   }
   console.noteln( "<end><cbr><br>* Post: HDRMultiscaleTransform on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = new HDRMultiscaleTransform;
   f1Need( P, "numberOfLayers", Math.round( isFinite( par.numberOfLayers ) ? par.numberOfLayers : 6 ) );
   f1Need( P, "numberOfIterations", Math.round( isFinite( par.numberOfIterations ) ? par.numberOfIterations : 1 ) );
   f1Need( P, "invertedIterations", par.invertedIterations !== false );
   f1Need( P, "overdrive", isFinite( par.overdrive ) ? par.overdrive : 0.0 );
   f1Need( P, "medianTransform", par.medianTransform ? true : false );
   f1Set( P, "scalingFunctionName", "B3 Spline (5)" );
   f1Set( P, "toIntensity", par.toIntensity ? true : false );
   f1Set( P, "toLightness", par.toLightness ? true : false );
   f1Set( P, "preserveHue", par.preserveHue ? true : false );
   f1Need( P, "luminanceMask", par.luminanceMask !== false );
   f1Set( P, "deringing", par.deringing ? true : false );
   if ( P.executeOn( view ) === false )
      throw new Error( "HDRMultiscaleTransform failed." );
   f1MaybeRenamePostView( view, outId );
}

function f1RunLRGBCombination( par )
{
   f1RequireModule( "LRGBCombination", typeof LRGBCombination == "function" );
   let inL = f1PostViewName( par, "inputL", "L" );
   let inRGB = f1PostViewName( par, "inputRGB", "RGB" );
   let outId = f1PostViewName( par, "output", "LRGB" );
   let L = f1ResolvePostView( inL, [ f1.views.L || "L", "L" ] );
   let rgb = f1ResolvePostView( inRGB, [ f1.views.RGB || "RGB", "RGB" ] );
   if ( !L || !rgb )
   {
      console.warningln( "<end><cbr>** LRGBCombination skipped: need "
                         + inL + " and " + inRGB + " views." );
      return;
   }
   if ( f1ViewById( outId ) )
      throw new Error( "View id already in use: " + outId );
   console.noteln( "<end><cbr><br>* Post: LRGBCombination (" + L.id + " onto " + rgb.id
                   + ") -> " + outId );
   let clone = new ImageWindow( rgb.image.width, rgb.image.height,
                                rgb.image.numberOfChannels,
                                rgb.window.bitsPerSample,
                                rgb.window.isFloatSample,
                                true /*isColor*/,
                                outId );
   clone.mainView.beginProcess( UndoFlag.NoSwapFile );
   clone.mainView.image.assign( rgb.image );
   clone.mainView.endProcess();
   clone.show();
   let P = new LRGBCombination;
   P.channels = [
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ false, "", 1.0 ],
      [ true, L.id, 1.0 ]
   ];
   f1Need( P, "mL", par.mL );
   f1Need( P, "mc", par.mc );
   f1Set( P, "clipHighlights", par.clipHighlights !== false );
   f1Set( P, "noiseReduction", false );
   if ( P.executeOn( clone.mainView ) === false )
      throw new Error( "LRGBCombination failed." );
   f1MaybeRenamePostView( clone.mainView, outId );
   console.writeln( "  created " + clone.mainView.id );
}

var f1StarStretchApi = null;

function f1StarStretchScriptCandidates()
{
   let dir = "";
   try
   {
      dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ );
   }
   catch ( e )
   {
      dir = "";
   }
   let list = [];
   if ( dir )
   {
      list.push( dir + "/star_stretch.js" );
      list.push( dir + "/SetiAstro/star_stretch.js" );
   }
   list.push( "C:/Program Files/PixInsight/src/scripts/star_stretch.js" );
   return list;
}

function f1EnsureStarStretchLibrary()
{
   if ( f1StarStretchApi
        && f1StarStretchApi.StarStretchParameters
        && typeof f1StarStretchApi.applyPixelMath == "function" )
      return f1StarStretchApi;
   let candidates = f1StarStretchScriptCandidates();
   let path = "";
   for ( let i = 0; i < candidates.length; ++i )
      if ( File.exists( candidates[i] ) )
      {
         path = candidates[i];
         break;
      }
   if ( !path )
      throw new Error( "SetiAstro Star Stretch script not found. "
                       + "Place Franklin Marek's official star_stretch.js next to BatchProcessing_byHrast "
                       + "(or in SetiAstro/), or keep the SetiAstro install under PixInsight/src/scripts/. "
                       + "This script does not reimplement Star Stretch." );
   let text = File.readTextFile( path );
   // Load Franklin Marek's script as a library; do not run its interactive main()/dialog.
   text = text.replace( /\r\n/g, "\n" );
   // Strip PJSR preprocessor lines — they are not valid inside Function().
   text = text.replace( /^[ \t]*#[^\n]*\n/gm, "" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*$/m, "\n" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*\n/g, "\n" );
   let api = null;
   try
   {
      api = ( new Function(
         text
         + "\n; return {"
         + " StarStretchParameters: (typeof StarStretchParameters!=='undefined')?StarStretchParameters:null,"
         + " applyPixelMath: (typeof applyPixelMath==='function')?applyPixelMath:null,"
         + " applyColorSaturation: (typeof applyColorSaturation==='function')?applyColorSaturation:null,"
         + " applySCNR: (typeof applySCNR==='function')?applySCNR:null,"
         + " isGrayscale: (typeof isGrayscale==='function')?isGrayscale:null,"
         + " disableSTF: (typeof disableSTF==='function')?disableSTF:null"
         + " };"
      ) )();
   }
   catch ( e )
   {
      throw new Error( "Could not load SetiAstro Star Stretch from:\n" + path
                       + "\n" + ( e.message ? e.message : e.toString() ) );
   }
   if ( !api || !api.StarStretchParameters || typeof api.applyPixelMath != "function" )
      throw new Error( "Star Stretch loaded from " + path
                       + " but required exports are missing." );
   api.path = path;
   f1StarStretchApi = api;
   console.writeln( "Using SetiAstro Star Stretch by Franklin Marek (www.setiastro.com): " + path );
   return api;
}

function f1RunStarStretch( par )
{
   let inId = f1PostViewName( par, "input", "RGB_stars" );
   let outId = f1PostViewName( par, "output", inId );
   let view = f1ResolvePostView( inId, ( inId == "NBtoRGB_stars" || inId == "SHO_stars" ) ? [] : [ "RGB_stars" ] );
   if ( !view )
   {
      console.warningln( "<end><cbr>** Star Stretch skipped: view not found: " + inId );
      return;
   }
   let api = f1EnsureStarStretchLibrary();
   console.noteln( "<end><cbr><br>* Post: Star Stretch (SetiAstro) on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = api.StarStretchParameters;
   P.amount = isFinite( par.amount ) ? par.amount : 5.0;
   P.satAmount = isFinite( par.satAmount ) ? par.satAmount : 1.0;
   P.removeGreen = par.removeGreen ? true : false;
   P.targetView = view;
   if ( typeof P.updateSaturationLevel == "function" )
      P.updateSaturationLevel();
   api.applyPixelMath( view, P.amount );
   let gray = false;
   try
   {
      gray = api.isGrayscale ? api.isGrayscale( view ) : !( view.image && view.image.isColor );
   }
   catch ( e )
   {
      gray = !( view.image && view.image.isColor );
   }
   if ( !gray )
   {
      if ( typeof api.applyColorSaturation == "function" )
         api.applyColorSaturation( view );
      if ( P.removeGreen && typeof api.applySCNR == "function" )
         api.applySCNR( view );
   }
   if ( typeof api.disableSTF == "function" )
   {
      try { api.disableSTF( view ); } catch ( e ) {}
   }
   f1MaybeRenamePostView( view, outId );
}

function f1RunHistogramTransformation( par )
{
   f1RequireModule( "HistogramTransformation", typeof HistogramTransformation == "function" );
   let inId = f1PostViewName( par, "input", "LRGB" );
   let outId = f1PostViewName( par, "output", inId );
   let fallbacks = inId == "LRGB" ? [ "RGB" ] : ( inId == "SHO" ? [] : [ "LRGB", "RGB" ] );
   let view = f1ResolvePostView( inId, fallbacks );
   if ( !view )
   {
      console.warningln( "<end><cbr>** HistogramTransformation skipped: view not found: " + inId );
      return;
   }
   console.noteln( "<end><cbr><br>* Post: HistogramTransformation on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let P = new HistogramTransformation;
   P.H = f1CloneHistoH( par && par.H ? par.H : F1_DEFAULT_HISTO_H );
   if ( P.executeOn( view ) === false )
      throw new Error( "HistogramTransformation failed." );
   // Fallback RGB must not be renamed to LRGB — there was no L combination.
   if ( !( inId == "LRGB" && view.id == "RGB" && outId == "LRGB" ) )
      f1MaybeRenamePostView( view, outId );
}

function f1RunPutStars( par )
{
   f1RequireModule( "PixelMath", typeof PixelMath == "function" );
   let starsId = f1PostViewName( par, "inputStars", "RGB_stars" );
   let targetId = f1PostViewName( par, "inputTarget", "LRGB" );
   let outId = f1PostViewName( par, "output", targetId );
   let stars = f1ResolvePostView( starsId, ( starsId == "NBtoRGB_stars" || starsId == "SHO_stars" ) ? [] : [ "RGB_stars" ] );
   let target = f1ResolvePostView( targetId, targetId == "LRGB" ? [ "RGB" ] : ( targetId == "SHO" ? [] : [ "LRGB", "RGB" ] ) );
   if ( !stars || !target )
   {
      console.warningln( "<end><cbr>** PixelMath put stars skipped: need "
                         + starsId + " and " + targetId + "." );
      return;
   }
   let expression = ( par && par.expression ) ? String( par.expression ).replace( /^\s+|\s+$/g, "" ) : "";
   if ( !expression.length
        || expression == "combine(RGB_stars, LRGB, op_screen())"
        || /^combine\([^,]+,\s*[^,]+,\s*op_screen\(\)\)$/.test( expression ) )
      expression = "combine(" + stars.id + ", " + target.id + ", op_screen())";
   console.noteln( "<end><cbr><br>* Post: PixelMath screen " + stars.id + " onto " + target.id );
   let P = new PixelMath;
   P.expression = expression;
   f1Set( P, "useSingleExpression", true );
   f1Set( P, "createNewImage", false );
   if ( P.executeOn( target ) === false )
      throw new Error( "PixelMath put stars failed." );
   if ( !( targetId == "LRGB" && target.id == "RGB" && outId == "LRGB" ) )
      f1MaybeRenamePostView( target, outId );
}

function f1NBtoRGBScriptCandidates()
{
   let dir = "";
   try
   {
      dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ );
   }
   catch ( e )
   {
      dir = "";
   }
   let list = [];
   if ( dir )
      list.push( dir + "/NBtoRGBStars.js" );
   list.push( "C:/Program Files/PixInsight/src/scripts/NBtoRGBStars.js" );
   return list;
}

var f1NBtoRGBApi = null;

function f1EnsureNBtoRGBLibrary()
{
   if ( f1NBtoRGBApi && f1NBtoRGBApi.SHOParameters && typeof f1NBtoRGBApi.combineNBtoRGB == "function" )
      return f1NBtoRGBApi;
   let candidates = f1NBtoRGBScriptCandidates();
   let path = "";
   for ( let i = 0; i < candidates.length; ++i )
      if ( File.exists( candidates[i] ) )
      {
         path = candidates[i];
         break;
      }
   if ( !path )
      throw new Error( "SetiAstro NB to RGB Stars script not found. "
                       + "Keep NBtoRGBStars.js in PixInsight/src/scripts/." );
   let text = File.readTextFile( path );
   text = text.replace( /\r\n/g, "\n" );
   text = text.replace( /^[ \t]*#[^\n]*\n/gm, "" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*$/m, "\n" );
   text = text.replace( /\nmain\s*\(\s*\)\s*;\s*\n/g, "\n" );
   let api = null;
   try
   {
      api = ( new Function(
         text
         + "\n; return {"
         + " SHOParameters: (typeof SHOParameters!=='undefined')?SHOParameters:null,"
         + " combineNBtoRGB: (typeof combineNBtoRGB==='function')?combineNBtoRGB:null,"
         + " applyAdjustments: (typeof applyAdjustments==='function')?applyAdjustments:null"
         + " };"
      ) )();
   }
   catch ( e )
   {
      throw new Error( "Could not load SetiAstro NB to RGB Stars from:\n" + path
                       + "\n" + ( e.message ? e.message : e.toString() ) );
   }
   if ( !api || !api.SHOParameters || typeof api.combineNBtoRGB != "function" )
      throw new Error( "NB to RGB Stars loaded from " + path + " but required exports are missing." );
   api.path = path;
   f1NBtoRGBApi = api;
   console.writeln( "Using SetiAstro NB to RGB Stars by Franklin Marek (www.setiastro.com): " + path );
   return api;
}

function f1RequireNamedView( id, label )
{
   if ( f1.views && f1.views[id] )
   {
      let saved = f1ViewById( f1.views[id] );
      if ( saved )
         return saved;
   }
   let view = f1ViewById( id );
   if ( !view )
      throw new Error( label + ": view not found: " + id );
   return view;
}

function f1RunNBtoRGBStars( par )
{
   let siiId = f1PostViewName( par, "sii", "SII_stars" );
   let haId = f1PostViewName( par, "ha", "Ha_stars" );
   let oiiiId = f1PostViewName( par, "oiii", "OIII_stars" );
   let outId = f1PostViewName( par, "output", "NBtoRGB_stars" );
   let sii = f1RequireNamedView( siiId, "NB to RGB Stars" );
   let ha = f1RequireNamedView( haId, "NB to RGB Stars" );
   let oiii = f1RequireNamedView( oiiiId, "NB to RGB Stars" );
   if ( f1ViewById( "NBtoRGB_stars" ) || ( outId != "NBtoRGB_stars" && f1ViewById( outId ) ) )
      throw new Error( "View id already in use: " + ( f1ViewById( "NBtoRGB_stars" ) ? "NBtoRGB_stars" : outId ) );
   let api = f1EnsureNBtoRGBLibrary();
   console.noteln( "<end><cbr><br>* Post: NB to RGB Stars (SetiAstro) "
                   + sii.id + " + " + ha.id + " + " + oiii.id + " -> " + outId );
   let P = api.SHOParameters;
   P.HaView = ha;
   P.OIIIView = oiii;
   P.SIIView = sii;
   P.OSCView = undefined;
   P.applyStarStretch = par.applyStarStretch ? true : false;
   P.stretchFactor = isFinite( par.stretchFactor ) ? par.stretchFactor : 6;
   P.colorBoost = isFinite( par.colorBoost ) ? par.colorBoost : 1.7;
   P.haToOiiRatio = isFinite( par.haToOiiRatio ) ? par.haToOiiRatio : 0.3;
   P.showPreview = false;
   let newId = api.combineNBtoRGB();
   if ( !newId )
      throw new Error( "NB to RGB Stars did not create an image." );
   if ( typeof api.applyAdjustments == "function" )
      api.applyAdjustments( newId );
   let view = f1ViewById( newId );
   if ( !view )
      throw new Error( "NB to RGB Stars result was not found: " + newId );
   f1MaybeRenamePostView( view, outId );
}

function f1RunPostStretch( par )
{
   let inId = f1PostViewName( par, "input", "OIII" );
   let outId = f1PostViewName( par, "output", inId );
   let view = f1RequireNamedView( inId, "MultiscaleAdaptiveStretch" );
   console.noteln( "<end><cbr><br>* Post: MultiscaleAdaptiveStretch on " + view.id
                   + ( outId != view.id ? ( " -> " + outId ) : "" ) );
   let process = f1BuildStretch( par );
   if ( process.executeOn( view ) === false )
      throw new Error( "MultiscaleAdaptiveStretch failed on " + view.id + "." );
   f1ResetScreen( view );
   f1MaybeRenamePostView( view, outId );
}

function f1RunSHOCombine( par )
{
   f1RequireModule( "ChannelCombination", typeof ChannelCombination == "function" );
   let slots = [ "SII", "Ha", "OIII" ];
   let keys = [ "inputR", "inputG", "inputB" ];
   let sources = [];
   for ( let i = 0; i < slots.length; ++i )
   {
      let named = f1PostViewName( par, keys[i], slots[i] );
      let view = ( f1.views && f1.views[slots[i]] ) ? f1ViewById( f1.views[slots[i]] ) : null;
      if ( !view )
         view = f1ViewById( named ) || f1ViewById( slots[i] );
      if ( !view )
         throw new Error( "Compose SHO: view not found for " + slots[i] + "." );
      sources.push( view );
   }
   let outId = f1PostViewName( par, "output", "SHO" );
   if ( sources[0].image.width != sources[1].image.width || sources[0].image.height != sources[1].image.height
        || sources[0].image.width != sources[2].image.width || sources[0].image.height != sources[2].image.height )
      throw new Error( "Compose SHO needs SII, Ha and OIII at the same size." );
   if ( f1ViewById( outId ) )
      throw new Error( "View id already in use: " + outId );
   console.noteln( "<end><cbr><br>* Post: Compose SHO  R=" + sources[0].id
                   + " G=" + sources[1].id + " B=" + sources[2].id + " -> " + outId );
   let before = f1WindowIds();
   let P = new ChannelCombination;
   P.colorSpace = ChannelCombination.RGB;
   P.channels = [
      [ true, sources[0].id ],
      [ true, sources[1].id ],
      [ true, sources[2].id ]
   ];
   f1Set( P, "inheritAstrometricSolution", true );
   if ( P.executeGlobal() === false )
      throw new Error( "Compose SHO failed." );
   let window = f1FindNewWindow( before );
   if ( !window )
   {
      try { window = ImageWindow.activeWindow; } catch ( e ) {}
   }
   if ( !window || !window.isWindow )
      throw new Error( "Compose SHO did not create an image." );
   f1RenameMainView( window.mainView, outId );
   console.writeln( "  created " + outId + ". SII, Ha and OIII stay in their own rows." );
}

function f1RunSHOLRGB( par, dialog )
{
   f1RequireModule( "LRGBCombination", typeof LRGBCombination == "function" );
   let slots = [ "SII", "Ha", "OIII" ];
   let keys = [ "inputR", "inputG", "inputB" ];
   let sources = [];
   for ( let i = 0; i < slots.length; ++i )
   {
      let named = f1PostViewName( par, keys[i], slots[i] );
      let view = ( f1.views && f1.views[slots[i]] ) ? f1ViewById( f1.views[slots[i]] ) : null;
      if ( !view )
         view = f1ViewById( named ) || f1ViewById( slots[i] );
      if ( !view )
         throw new Error( "LRGBCombination: view not found for " + slots[i] + "." );
      sources.push( view );
   }
   let outId = f1PostViewName( par, "output", "SHO" );
   if ( f1ViewById( outId ) )
      throw new Error( "View id already in use: " + outId );
   console.noteln( "<end><cbr><br>* Post: LRGBCombination  R=" + sources[0].id
                   + " G=" + sources[1].id + " B=" + sources[2].id + " -> " + outId );
   let before = f1WindowIds();
   let P = new LRGBCombination;
   P.channels = [
      [ true, sources[0].id, 1.0 ],
      [ true, sources[1].id, 1.0 ],
      [ true, sources[2].id, 1.0 ],
      [ false, "", 1.0 ]
   ];
   f1Need( P, "mL", isFinite( par.mL ) ? par.mL : 0.5 );
   f1Need( P, "mc", isFinite( par.mc ) ? par.mc : 0.5 );
   f1Set( P, "clipHighlights", par.clipHighlights !== false );
   f1Set( P, "noiseReduction", false );
   f1Set( P, "inheritAstrometricSolution", true );
   if ( P.executeGlobal() === false )
      throw new Error( "LRGBCombination failed." );
   let window = f1FindNewWindow( before );
   if ( !window )
   {
      try { window = ImageWindow.activeWindow; } catch ( e ) {}
   }
   if ( !window || !window.isWindow )
      throw new Error( "LRGBCombination did not create an image." );
   f1RenameMainView( window.mainView, outId );
   f1SetDialogSlot( dialog, "SHO", window.mainView );
   console.writeln( "  created " + outId + ". SII, Ha and OIII stay in their rows." );
}

function f1PostTarget( par, title )
{
   let inId = f1PostViewName( par, "input", "SHO" );
   return f1RequireNamedView( inId, title );
}

function f1RunLocalHistogramEqualization( par )
{
   f1RequireModule( "LocalHistogramEqualization", typeof LocalHistogramEqualization == "function" );
   let view = f1PostTarget( par, "LocalHistogramEqualization" );
   console.noteln( "<end><cbr><br>* Post: LocalHistogramEqualization on " + view.id );
   let P = new LocalHistogramEqualization;
   f1Need( P, "radius", Math.round( isFinite( par.radius ) ? par.radius : 256 ) );
   f1Need( P, "histogramBins", LocalHistogramEqualization.Bit8 );
   f1Need( P, "slopeLimit", isFinite( par.slopeLimit ) ? par.slopeLimit : 1.5 );
   f1Need( P, "amount", isFinite( par.amount ) ? par.amount : 0.5 );
   f1Need( P, "circularKernel", true );
   if ( P.executeOn( view ) === false )
      throw new Error( "LocalHistogramEqualization failed." );
}

function f1ApplyCurve( process, name, points )
{
   if ( !points || !points.length )
      return;
   f1Need( process, name, points );
   f1Set( process, name + "t", CurvesTransformation.AkimaSubsplines );
}

function f1RunCurves( par )
{
   f1RequireModule( "CurvesTransformation", typeof CurvesTransformation == "function" );
   let view = f1PostTarget( par, "CurvesTransformation" );
   console.noteln( "<end><cbr><br>* Post: CurvesTransformation on " + view.id );
   let P = new CurvesTransformation;
   f1ApplyCurve( P, "B", par.B );
   f1ApplyCurve( P, "K", par.K );
   f1ApplyCurve( P, "S", par.S );
   if ( P.executeOn( view ) === false )
      throw new Error( "CurvesTransformation failed." );
}

function f1RunRotation( par )
{
   f1RequireModule( "Rotation", typeof Rotation == "function" );
   let view = f1PostTarget( par, "Rotation" );
   let degrees = isFinite( par.angleDeg ) ? par.angleDeg : 180;
   console.noteln( "<end><cbr><br>* Post: Rotation " + degrees + " deg on " + view.id );
   let P = new Rotation;
   f1Need( P, "angle", degrees * Math.PI / 180 );
   f1Set( P, "optimizeFast", true );
   f1Set( P, "interpolation", Rotation.Auto );
   f1Set( P, "clampingThreshold", 0.30 );
   f1Set( P, "smoothness", 1.50 );
   f1Set( P, "noGUIMessages", true );
   if ( P.executeOn( view ) === false )
      throw new Error( "Rotation failed." );
}

function f1RunResample( par )
{
   f1RequireModule( "Resample", typeof Resample == "function" );
   let view = f1PostTarget( par, "Resample" );
   let scale = isFinite( par.scale ) ? par.scale : 0.5;
   console.noteln( "<end><cbr><br>* Post: Resample x" + scale + " on " + view.id );
   let P = new Resample;
   f1Need( P, "xSize", scale );
   f1Need( P, "ySize", scale );
   f1Need( P, "mode", Resample.RelativeDimensions );
   f1Set( P, "absoluteMode", Resample.ForceWidthAndHeight );
   f1Set( P, "interpolation", Resample.Auto );
   f1Set( P, "clampingThreshold", 0.30 );
   f1Set( P, "smoothness", 1.50 );
   f1Set( P, "noGUIMessages", true );
   if ( P.executeOn( view ) === false )
      throw new Error( "Resample failed." );
}

function f1RunRenameView( par )
{
   let inId = f1PostViewName( par, "input", "SHO" );
   let outId = f1PostViewName( par, "output", "SHO" );
   let view = f1RequireNamedView( inId, "Rename" );
   console.noteln( "<end><cbr><br>* Post: rename " + view.id + " -> " + outId );
   f1MaybeRenamePostView( view, outId );
}

function f1RunInvert( par )
{
   f1RequireModule( "Invert", typeof Invert == "function" );
   let inId = f1PostViewName( par, "input", "SHO" );
   let view = f1RequireNamedView( inId, "Invert" );
   console.noteln( "<end><cbr><br>* Post: Invert on " + view.id );
   let P = new Invert;
   if ( P.executeOn( view ) === false )
      throw new Error( "Invert failed." );
}

function f1RunSCNR( par )
{
   f1RequireModule( "SCNR", typeof SCNR == "function" );
   let inId = f1PostViewName( par, "input", "SHO" );
   let view = f1RequireNamedView( inId, "SCNR" );
   console.noteln( "<end><cbr><br>* Post: SCNR remove green on " + view.id );
   let P = new SCNR;
   f1Need( P, "amount", isFinite( par.amount ) ? par.amount : 1.0 );
   f1Set( P, "protectionMethod", SCNR.AverageNeutral );
   f1Set( P, "colorToRemove", SCNR.Green );
   f1Set( P, "preserveLightness", true );
   if ( P.executeOn( view ) === false )
      throw new Error( "SCNR failed." );
}

function f1RunPhaseIcon( step, state )
{
   let process = f1BuildFromIconSource( f1EnsureIconSource( step, state.par ) );
   f1AutoWireCombineProcess( process, step.processId || state.par.processId );
   let target = f1ViewById( f1.views.RGB || "RGB" )
             || f1ViewById( f1.views.L || "L" )
             || f1ViewById( "LRGB" );
   if ( !target )
      throw new Error( step.title + ": no target view." );
   if ( process.executeOn( target ) === false )
      throw new Error( step.title + " failed." );
}

function f1AutoWireCombineProcess( process, processId )
{
   if ( !process || !processId )
      return;
   try
   {
      if ( processId == "ChannelCombination" )
      {
         let r = f1ViewById( f1.views.R || "R" );
         let g = f1ViewById( f1.views.G || "G" );
         let b = f1ViewById( f1.views.B || "B" );
         if ( r && g && b )
            process.channels = [ [ true, r.id ], [ true, g.id ], [ true, b.id ] ];
      }
      else if ( processId == "LRGBCombination" )
      {
         let L = f1ViewById( f1.views.L || "L" );
         if ( L )
            process.channels = [
               [ false, "", 1.0 ],
               [ false, "", 1.0 ],
               [ false, "", 1.0 ],
               [ true, L.id, 1.0 ]
            ];
      }
   }
   catch ( e )
   {
   }
}

function f1NarrowView( slot )
{
   let saved = ( f1.views && f1.views[slot] ) ? f1.views[slot] : "";
   return f1ViewById( saved ) || f1ViewById( slot );
}

function f1CloseViewQuiet( view )
{
   if ( !view )
      return;
   try
   {
      if ( view.window )
         view.window.forceClose();
   }
   catch ( e )
   {
   }
}

function f1LinearFitTo( view, reference )
{
   let P = new LinearFit;
   P.referenceViewId = reference.id;
   P.rejectLow = 0;
   P.rejectHigh = 0.92;
   if ( P.executeOn( view ) === false )
      throw new Error( "AutoLinearFit: LinearFit failed." );
}

function f1AutoLinearReference( method, viewR, viewG, viewB )
{
   if ( method == "Red channel" )
      return "R";
   if ( method == "Green channel" )
      return "G";
   if ( method == "Blue channel" )
      return "B";
   let r;
   let g;
   let b;
   if ( method == "Lowest noise k-sigma" )
   {
      r = viewR.image.noiseKSigma()[0];
      g = viewG.image.noiseKSigma()[0];
      b = viewB.image.noiseKSigma()[0];
   }
   else if ( method == "Lowest noise MRS" )
   {
      r = viewR.image.noiseMRS()[0];
      g = viewG.image.noiseMRS()[0];
      b = viewB.image.noiseMRS()[0];
   }
   else
   {
      r = viewR.image.mean();
      g = viewG.image.mean();
      b = viewB.image.mean();
      console.noteln( "  means  R " + r + "  G " + g + "  B " + b );
   }
   if ( b < Math.min( g, r ) )
      return "B";
   if ( g < Math.min( b, r ) )
      return "G";
   return "R";
}

function f1RunAutoLinearFit( par )
{
   f1RequireModule( "ChannelExtraction", typeof ChannelExtraction == "function" );
   f1RequireModule( "LinearFit", typeof LinearFit == "function" );
   f1RequireModule( "ChannelCombination", typeof ChannelCombination == "function" );
   let view = f1PostTarget( par, "AutoLinearFit" );
   if ( !view.image || !view.image.isColor )
      throw new Error( "AutoLinearFit needs a color image." );
   let method = ( par && par.referenceMethod ) ? par.referenceMethod : "Lowest mean";
   console.noteln( "<end><cbr><br>* Post: AutoLinearFit on " + view.id + " (" + method + ")" );
   let idR = view.id + "_temp_R";
   let idG = view.id + "_temp_G";
   let idB = view.id + "_temp_B";
   f1CloseViewQuiet( f1ViewById( idR ) );
   f1CloseViewQuiet( f1ViewById( idG ) );
   f1CloseViewQuiet( f1ViewById( idB ) );
   let extract = new ChannelExtraction;
   extract.colorSpace = ChannelExtraction.RGB;
   extract.channels = [ [ true, idR ], [ true, idG ], [ true, idB ] ];
   extract.sampleFormat = ChannelExtraction.SameAsSource;
   if ( extract.executeOn( view ) === false )
      throw new Error( "AutoLinearFit: channel extraction failed." );
   let viewR = f1ViewById( idR );
   let viewG = f1ViewById( idG );
   let viewB = f1ViewById( idB );
   try
   {
      if ( !viewR || !viewG || !viewB )
         throw new Error( "AutoLinearFit: temporary channels were not created." );
      try
      {
         viewR.window.hide();
         viewG.window.hide();
         viewB.window.hide();
      }
      catch ( e )
      {
      }
      let ref = f1AutoLinearReference( method, viewR, viewG, viewB );
      console.noteln( "  reference channel: " + ref );
      if ( ref == "B" )
      {
         f1LinearFitTo( viewR, viewB );
         f1LinearFitTo( viewG, viewB );
      }
      else if ( ref == "G" )
      {
         f1LinearFitTo( viewB, viewG );
         f1LinearFitTo( viewR, viewG );
      }
      else
      {
         f1LinearFitTo( viewG, viewR );
         f1LinearFitTo( viewB, viewR );
      }
      let combine = new ChannelCombination;
      combine.colorSpace = ChannelCombination.RGB;
      combine.channels = [ [ true, viewR.id ], [ true, viewG.id ], [ true, viewB.id ] ];
      if ( combine.executeOn( view ) === false )
         throw new Error( "AutoLinearFit: channel combination failed." );
   }
   finally
   {
      f1CloseViewQuiet( viewR );
      f1CloseViewQuiet( viewG );
      f1CloseViewQuiet( viewB );
   }
}

function f1RunPostProcess( par, title, process )
{
   let view = f1PostTarget( par, title );
   console.noteln( "<end><cbr><br>* Post: " + title + " on " + view.id );
   if ( process.executeOn( view ) === false )
      throw new Error( title + " failed." );
}

function f1RunStarXChannels( par )
{
   let slots = [ "SII", "Ha", "OIII" ];
   let overlap = ( par && isFinite( par.overlap ) ) ? par.overlap : 0.20;
   for ( let i = 0; i < slots.length; ++i )
   {
      let slot = slots[i];
      let view = f1NarrowView( slot );
      if ( !view )
         throw new Error( "StarXTerminator: view not found: " + slot );
      let before = f1WindowIds();
      console.noteln( "<end><cbr><br>* Post: StarXTerminator on " + view.id );
      let process = f1BuildStars( { outputStars: true, unscreen: false, overlap: overlap } );
      if ( process.executeOn( view ) === false )
         throw new Error( "StarXTerminator failed on " + slot );
      f1RenameStarXResult( slot, before );
   }
}

function f1RunStarXOne( channel, par )
{
   let view = f1RequireNamedView( channel, "StarXTerminator" );
   let before = f1WindowIds();
   console.noteln( "<end><cbr><br>* Post: StarXTerminator on " + view.id );
   let process = f1BuildStars( par );
   if ( process.executeOn( view ) === false )
      throw new Error( "StarXTerminator failed on " + channel );
   f1RenameStarXResult( channel, before );
}

function f1RunPhase( name, dialog, startIndex )
{
   let label = name == "pre" ? "Pre" : "Post";
   let steps = f1PhaseOrderedSteps( name );
   let begin = startIndex > 0 ? startIndex : 0;
   for ( let i = begin; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      if ( !state || !state.on )
         continue;
      if ( !f1PhaseStepInstalled( step ) )
      {
         console.warningln( "<end><cbr>** " + step.title + " is not installed. Step skipped." );
         continue;
      }
      try
      {
         if ( step.kind == "autoassign" )
            f1AutoAssignFilters( state.par, dialog );
         else if ( step.kind == "composergb" )
            f1ComposeRGB( state.par, dialog );
         else if ( step.kind == "composesho" )
         {
            if ( typeof f1SeparatesNarrowband == "function" && f1SeparatesNarrowband() )
               console.writeln( "  Compose SHO skipped. SII, Ha and OIII are processed first." );
            else
               f1ComposeSHO( state.par, dialog );
         }
         else if ( step.kind == "hdrmt" )
            f1RunHDRMT( state.par );
         else if ( step.kind == "lrgbcomb" )
            f1RunLRGBCombination( state.par );
         else if ( step.kind == "starstretch" )
         {
            if ( step.id == "shostarstretch" )
               f1RequireNamedView( f1PostViewName( state.par, "input", "SHO_stars" ), "Star Stretch" );
            f1RunStarStretch( state.par );
         }
         else if ( step.kind == "histo" )
            f1RunHistogramTransformation( state.par );
         else if ( step.kind == "putstars" )
            f1RunPutStars( state.par );
         else if ( step.kind == "nbtorgb" )
            f1RunNBtoRGBStars( state.par );
         else if ( step.kind == "stretch" )
            f1RunPostStretch( state.par );
         else if ( step.kind == "shocombine" )
            f1RunSHOCombine( state.par );
         else if ( step.kind == "sholrgb" )
            f1RunSHOLRGB( state.par, dialog );
         else if ( step.kind == "blindsolver" )
         {
            let view = f1PostTarget( state.par, "BlindSolver" );
            f1RunBlindSolve( view.window, null, state.par );
         }
         else if ( step.kind == "lhe" )
            f1RunLocalHistogramEqualization( state.par );
         else if ( step.kind == "curves" )
            f1RunCurves( state.par );
         else if ( step.kind == "rotate" )
            f1RunRotation( state.par );
         else if ( step.kind == "resample" )
            f1RunResample( state.par );
         else if ( step.kind == "rename" )
            f1RunRenameView( state.par );
         else if ( step.kind == "invert" )
            f1RunInvert( state.par );
         else if ( step.kind == "scnr" )
            f1RunSCNR( state.par );
         else if ( step.kind == "starxmono" )
            f1RunStarXChannels( state.par );
         else if ( step.kind == "spfc" )
            f1RunPostProcess( state.par, step.title, f1BuildFlux( state.par ) );
         else if ( step.kind == "spcc" )
            f1RunPostProcess( state.par, step.title, f1BuildColor( state.par ) );
         else if ( step.kind == "autolinear" )
            f1RunAutoLinearFit( state.par );
         else if ( step.kind == "blurx" )
            f1RunPostProcess( state.par, step.title, f1BuildBlurX( state.par ) );
         else if ( step.kind == "noisex" )
            f1RunPostProcess( state.par, step.title, f1BuildNoise( state.par ) );
         else if ( step.kind == "starx" )
         {
            let channel = f1PostViewName( state.par, "input", "" );
            if ( state.par.outputStars && typeof f1ExportsStars == "function" && f1ExportsStars( channel ) )
               f1RunStarXOne( channel, state.par );
            else
               f1RunPostProcess( state.par, step.title, f1BuildStars( state.par ) );
         }
         else if ( step.kind == "icon" )
            f1RunPhaseIcon( step, state );
      }
      catch ( e )
      {
         if ( f1UserAbort() )
            throw e;
         let message = f1ErrorText( e );
         console.criticalln( "*** " + label + " · " + step.title + ": " + message );
         let wrapped = new Error( label + " · " + step.title + ": " + message );
         wrapped.phaseFailure = {
            phase: name,
            stepId: step.id,
            stepTitle: step.title,
            stepIndex: i,
            message: label + " · " + step.title + ": " + message
         };
         throw wrapped;
      }
      if ( f1UserAbort() )
         throw new Error( "Aborted by user." );
      CoreApplication.processEvents();
   }
}

function f1PhaseExtraForWrite( name )
{
   let extraOut = [];
   let extra = ( f1[name] && f1[name].extra ) ? f1[name].extra : [];
   for ( let i = 0; i < extra.length; ++i )
   {
      let step = extra[i];
      let par = f1[name].steps[step.id] ? f1[name].steps[step.id].par : {};
      extraOut.push( {
         id: step.id,
         kind: "icon",
         title: step.title,
         processId: step.processId || par.processId,
         iconName: par.iconName || step.iconName || f1IconNameFromTitle( step.title ),
         source: par.source || ""
      } );
   }
   return extraOut;
}

function f1PhaseAddedForWrite( name )
{
   let out = [];
   let added = ( f1[name] && f1[name].added ) ? f1[name].added : [];
   for ( let i = 0; i < added.length; ++i )
   {
      let step = added[i];
      if ( !step || !step.id || !step.kind )
         continue;
      let item = { id: step.id, title: step.title, kind: step.kind };
      if ( step.mode )
         item.mode = step.mode;
      out.push( item );
   }
   return out;
}

function f1InstallPhaseAdded( name, list )
{
   if ( !f1[name].added )
      f1[name].added = [];
   if ( !list || !Array.isArray( list ) )
      return;
   for ( let i = 0; i < list.length; ++i )
   {
      let item = list[i];
      if ( !item || !item.id || !item.kind || item.kind == "icon" )
         continue;
      let step = { id: item.id, title: item.title || item.kind, kind: item.kind };
      if ( item.mode )
         step.mode = item.mode;
      f1[name].added.push( step );
      if ( !f1[name].steps[step.id] )
      {
         let par = f1PhaseDefaultParams( step );
         if ( f1ShowsOneTarget( step.kind ) )
         {
            par.channel = "";
            if ( par.input != null )
               par.input = "";
         }
         f1[name].steps[step.id] = { on: true, par: par };
      }
   }
}

function f1WritePhaseSettings( name )
{
   if ( !f1[name] )
      return;
   Settings.write( SETTINGS_PREFIX + name + "_order", DataType.String,
                   JSON.stringify( f1PhaseNormalizeOrder( name, f1[name].order ) ) );
   Settings.write( SETTINGS_PREFIX + name + "_extra", DataType.String,
                   JSON.stringify( f1PhaseExtraForWrite( name ) ) );
   Settings.write( SETTINGS_PREFIX + name + "_removed", DataType.String,
                   JSON.stringify( f1PhaseRemovedList( name ) ) );
   Settings.write( SETTINGS_PREFIX + name + "_added", DataType.String,
                   JSON.stringify( f1PhaseAddedForWrite( name ) ) );
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      Settings.write( SETTINGS_PREFIX + name + "_on_" + step.id, DataType.Int32, state.on ? 1 : 0 );
      Settings.write( SETTINGS_PREFIX + name + "_par_" + step.id, DataType.String, JSON.stringify( state.par ) );
   }
}

function f1LoadPhaseSettings( name )
{
   f1InitPhase( name, f1PhaseBuiltins( name ) );
   let rawExtra = f1ReadString( name + "_extra", "" );
   if ( rawExtra )
   {
      try
      {
         let list = JSON.parse( rawExtra );
         if ( Array.isArray( list ) )
         {
            for ( let i = 0; i < list.length; ++i )
            {
               let item = list[i];
               if ( !item || !item.id || item.kind != "icon" || !item.processId )
                  continue;
               let step = {
                  id: item.id,
                  title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
                  kind: "icon",
                  processId: item.processId
               };
               f1[name].extra.push( step );
               f1[name].steps[step.id] = {
                  on: true,
                  par: {
                     processId: item.processId,
                     iconName: item.iconName || "",
                     source: item.source || "",
                     title: step.title
                  }
               };
            }
         }
      }
      catch ( e )
      {
         f1[name].extra = [];
      }
   }
   let rawAdded = f1ReadString( name + "_added", "" );
   if ( rawAdded )
   {
      try
      {
         f1InstallPhaseAdded( name, JSON.parse( rawAdded ) );
      }
      catch ( e )
      {
         f1[name].added = [];
      }
   }
   let rawRemoved = f1ReadString( name + "_removed", "" );
   if ( rawRemoved )
   {
      try
      {
         f1PhaseApplyRemovedList( name, JSON.parse( rawRemoved ) );
      }
      catch ( e )
      {
         f1[name].removed = {};
      }
   }
   let rawOrder = f1ReadString( name + "_order", "" );
   if ( rawOrder )
   {
      try
      {
         let ids = JSON.parse( rawOrder );
         if ( Array.isArray( ids ) )
         {
            f1[name].order = f1PhaseNormalizeOrder( name, ids );
         }
      }
      catch ( e )
      {
      }
   }
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      let fallbackOn = f1PhaseDefaultOn( step );
      state.on = f1ReadBool( name + "_on_" + step.id, fallbackOn );
      let rawPar = f1ReadString( name + "_par_" + step.id, "" );
      if ( !rawPar )
         continue;
      try
      {
         let saved = JSON.parse( rawPar );
         if ( saved && typeof saved == "object" )
            for ( let key in saved )
               if ( saved[key] != null )
                  state.par[key] = saved[key];
      }
      catch ( e )
      {
      }
      if ( step.kind == "icon" )
      {
         step.processId = state.par.processId || step.processId;
         step.title = state.par.title || step.title;
      }
   }
}

function f1CollectPhaseProfile( name )
{
   let stepMap = {};
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      stepMap[step.id] = { on: state.on ? true : false, par: state.par || {} };
   }
   return {
      order: f1PhaseNormalizeOrder( name, f1[name].order ),
      extra: f1PhaseExtraForWrite( name ),
      removed: f1PhaseRemovedList( name ),
      added: f1PhaseAddedForWrite( name ),
      steps: stepMap
   };
}

function f1ApplyPhaseProfile( name, data )
{
   f1InitPhase( name, f1PhaseBuiltins( name ) );
   if ( !data || typeof data != "object" )
      return;
   if ( Array.isArray( data.extra ) )
   {
      for ( let i = 0; i < data.extra.length; ++i )
      {
         let item = data.extra[i];
         if ( !item || !item.id || item.kind != "icon" || !item.processId )
            continue;
         let step = {
            id: item.id,
            title: item.title || ( item.processId + " (" + ( item.iconName || "icon" ) + ")" ),
            kind: "icon",
            processId: item.processId,
            iconName: item.iconName || f1IconNameFromTitle( item.title )
         };
         f1[name].extra.push( step );
         f1[name].steps[step.id] = {
            on: true,
            par: {
               processId: item.processId,
               iconName: item.iconName || "",
               source: item.source || "",
               title: step.title
            }
         };
      }
   }
   f1PhaseApplyRemovedList( name, data.removed );
   if ( Array.isArray( data.added ) )
      f1InstallPhaseAdded( name, data.added );
   f1[name].order = f1PhaseNormalizeOrder( name, data.order );
   let stepMap = data.steps || {};
   let steps = f1PhaseAllSteps( name );
   for ( let i = 0; i < steps.length; ++i )
   {
      let step = steps[i];
      let state = f1[name].steps[step.id];
      let saved = stepMap[step.id];
      if ( !saved || typeof saved != "object" )
         continue;
      if ( saved.on != null )
         state.on = saved.on ? true : false;
      if ( saved.par && typeof saved.par == "object" )
         for ( let key in saved.par )
            if ( saved.par[key] != null )
               state.par[key] = saved.par[key];
      if ( step.kind == "icon" )
      {
         step.processId = state.par.processId || step.processId;
         step.title = state.par.title || step.title;
      }
   }
}
